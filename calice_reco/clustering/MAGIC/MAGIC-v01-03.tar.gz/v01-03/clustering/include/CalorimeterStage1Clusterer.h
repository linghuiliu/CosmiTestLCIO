#ifndef CalorimeterStage1Clusterer_h
#define CalorimeterStage1Clusterer_h 1

#include "marlin/Processor.h"
#include "lcio.h"
#include <string>


using namespace lcio ;
using namespace marlin ;



/** Based on example processor for marlin. 
 */
class CalorimeterStage1Clusterer : public Processor {
  
 public:
  
  virtual Processor*  newProcessor() { return new CalorimeterStage1Clusterer ; }
  
  
  CalorimeterStage1Clusterer() ;
  
  /** Called at the begin of the job before anything is read.
   * Use to initialize the processor, e.g. book histograms.
   */
  virtual void init() ;
  
  /** Called for every run.
   */
  virtual void processRunHeader( LCRunHeader* run ) ;
  
  /** Called for every event - the working horse.
   */
  virtual void processEvent( LCEvent * evt ) ; 
  
  
  virtual void check( LCEvent * evt ) ; 
  
  
  /** Called after data processing for clean up.
   */
  virtual void end() ;
  
  
 private:

  int firstRun;
  int lastRun;
  int firstEventInFirstRun;
  int lastEventInLastRun;
  int printAction;
  std::string detectorType;
  float iPx;
  float iPy;
  float iPz;
  int ecalLayers;
  int hcalLayers;
  int totalLayers;
  int barrelSymmetry;
  float phi_1;
  int layersToTrackBackMax_ecal;
  int layersToTrackBackMax_hcal;
  float distMax_ecal;
  float distMax_hcal;
  float proxSeedMax_ecal;
  float proxSeedMax_hcal;

 protected:

  std::string _layersToTrackBackMax_ecal;
  std::string _layersToTrackBackMax_hcal;
  std::string _distMax_ecal;
  std::string _distMax_hcal;
  std::string _proxSeedMax_ecal;
  std::string _proxSeedMax_hcal;
  int _nRun ;
  int _nEvt ;
} ;

#endif



