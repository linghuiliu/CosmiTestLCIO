#ifndef CalorimeterConfigurer_h
#define CalorimeterConfigurer_h 1

#include "marlin/Processor.h"
#include "lcio.h"
#include <string>


using namespace lcio ;
using namespace marlin ;



/** Based on example processor for marlin. 
 */
class CalorimeterConfigurer : public Processor {
  
 public:
  
  virtual Processor*  newProcessor() { return new CalorimeterConfigurer ; }
  
  
  CalorimeterConfigurer() ;
  
  /** Called at the begin of the job before anything is read.
   * Use to initialize the processor, e.g. book histograms.
   */
  virtual void init() ;
  
  /** Called for every run.
   */
  virtual void processRunHeader( LCRunHeader* run ) ;
  
  /** Called for every event - the working horse.
   */
  virtual void processEvent( LCEvent * evt ) ; 
  
  
  virtual void check( LCEvent * evt ) ; 
  
  
  /** Called after data processing for clean up.
   */
  virtual void end() ;
  
  
 private:

  StringVec geometry_detectorType;
  StringVec geometry_iPx;
  StringVec geometry_iPy;
  StringVec geometry_iPz;
  StringVec geometry_ecalLayers;
  StringVec geometry_hcalLayers;
  StringVec geometry_barrelSymmetry;
  StringVec geometry_phi_1;
  int firstRun;
  int lastRun;
  int firstEventInFirstRun;
  int lastEventInLastRun;
  int printAction;
  std::string detectorType;
  float iPx;
  float iPy;
  float iPz;
  int ecalLayers;
  int hcalLayers;
  int barrelSymmetry;
  double phi_1;
  int totalLayers;

 protected:

  std::string _detectorType;
  std::string _iPx;
  std::string _iPy;
  std::string _iPz;
  std::string _ecalLayers;
  std::string _hcalLayers;
  std::string _barrelSymmetry;
  std::string _phi_1;
  int _nRun ;
  int _nEvt ;
} ;

#endif



