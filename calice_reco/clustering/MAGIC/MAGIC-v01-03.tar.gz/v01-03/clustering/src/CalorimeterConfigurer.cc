#include "CalorimeterConfigurer.h"
#include "marlin/Global.h"

#include "IMPL/LCCollectionVec.h"
#include "EVENT/LCFloatVec.h"

using namespace lcio;
using namespace marlin;
using namespace std;


CalorimeterConfigurer aCalorimeterConfigurer;


CalorimeterConfigurer::CalorimeterConfigurer() : Processor("CalorimeterConfigurer") {
  
  // Processor description
  _description = "CalorimeterConfigurer allows user to define geometrical layout of calorimeter";
  

  // Register steering parameters: name, description, class-variable, default value  
  registerProcessorParameter("detectorType", 
			     "detector type (full => rotationally symmetric barrel plus two endcaps; prototype => single endcap with layers aligned perpendicularly to +z direction)",
			     _detectorType,
			     std::string("full")); 
  registerProcessorParameter("iPx", 
			     "x-coordinate of interaction point (in mm)",
			     _iPx,
			     std::string("0.0")); 
  registerProcessorParameter("iPy", 
			     "y-coordinate of interaction point (in mm)",
			     _iPy,
			     std::string("0.0")); 
  registerProcessorParameter("iPz", 
			     "z-coordinate of interaction point (in mm)",
			     _iPz,
			     std::string("0.0")); 
  registerProcessorParameter("ecalLayers", 
			     "number of Ecal layers",
			     _ecalLayers,
			     std::string("40")); 
  registerProcessorParameter("hcalLayers", 
  			     "number of Hcal layers",
  			     _hcalLayers,
  			     std::string("40"));
  registerProcessorParameter("barrelSymmetry", 
			     "degree of rotational symmetry of barrel (has no effect for prototype)",
			     _barrelSymmetry,
			     std::string("8"));
  registerProcessorParameter("phi_1", 
			     "phi offset of (arbitrarily designated) barrel stave 1 w.r.t. x-axis (in deg) (has no effect for prototype)",
			     _phi_1,
			     std::string("90.0"));

}


void CalorimeterConfigurer::init() { 

  // Print processor parameters
  printParameters();

  // Set number of runs and events to 0
  _nRun = 0;
  _nEvt = 0;
  
  // Get parameters from steering file
  firstRun = Global::parameters->getIntVal("firstRun");
  lastRun = Global::parameters->getIntVal("lastRun");
  firstEventInFirstRun = Global::parameters->getIntVal("firstEventInFirstRun");
  lastEventInLastRun = Global::parameters->getIntVal("lastEventInLastRun");
  printAction = Global::parameters->getIntVal("printAction");
  detectorType = parameters()->getStringVal("detectorType");
  iPx = parameters()->getFloatVal("iPx");
  iPy = parameters()->getFloatVal("iPy");
  iPz = parameters()->getFloatVal("iPz");
  ecalLayers = parameters()->getIntVal("ecalLayers");
  hcalLayers = parameters()->getIntVal("hcalLayers");
  totalLayers = ecalLayers+hcalLayers;
  barrelSymmetry = parameters()->getIntVal("barrelSymmetry");
  phi_1 = parameters()->getFloatVal("phi_1");

  // Put parameters into global scope for use in subsequent processors
  Global::parameters->add("detectorType",parameters()->getStringVals("detectorType",geometry_detectorType));
  Global::parameters->add("iPx",parameters()->getStringVals("iPx",geometry_iPx));
  Global::parameters->add("iPy",parameters()->getStringVals("iPy",geometry_iPy));
  Global::parameters->add("iPz",parameters()->getStringVals("iPz",geometry_iPz));
  Global::parameters->add("ecalLayers",parameters()->getStringVals("ecalLayers",geometry_ecalLayers));
  Global::parameters->add("hcalLayers",parameters()->getStringVals("hcalLayers",geometry_hcalLayers));
  Global::parameters->add("barrelSymmetry",parameters()->getStringVals("barrelSymmetry",geometry_barrelSymmetry));
  Global::parameters->add("phi_1",parameters()->getStringVals("phi_1",geometry_phi_1));
}

void CalorimeterConfigurer::processRunHeader( LCRunHeader* run) { 

  _nRun++;
} 

void CalorimeterConfigurer::processEvent( LCEvent * evt ) { 

  // Process events in this range
  if(!((evt->getRunNumber()<firstRun && evt->getRunNumber()>lastRun) ||
       (evt->getRunNumber()==firstRun && evt->getEventNumber()<firstEventInFirstRun) ||
       (evt->getRunNumber()==lastRun && evt->getEventNumber()>lastEventInLastRun))) {
   
  cout << "Processing run " << evt->getRunNumber() << ", event " << evt->getEventNumber() << endl;
  if(printAction) cout << "  - reading calorimeter geometry...." << endl;

  // Create collections to store:
  // - the radial distances of the active layers from the z-axis in the barrel
  LCCollectionVec* distanceToBarrelLayersVec = new LCCollectionVec(LCIO::LCFLOATVEC);
  // - the longitudinal distances of the active layers from the z=0 plane in 
  //   the endcaps 
  LCCollectionVec* distanceToEndcapLayersVec = new LCCollectionVec(LCIO::LCFLOATVEC);

  // Loop over calorimeter layers, under- and overshooting by a layer in order
  // to later set pseudolayer boundaries at mid-points between layers (e.g.
  // pseudolayer 1 is bounded from beneath by the mid-point of layer 0 and 
  // layer 1, and from above by the mid-point of layer 1 and layer 2)
  for(int l=0;l<=1+totalLayers;l++) {
    LCFloatVec* distanceToBarrelLayers = new LCFloatVec;
    LCFloatVec* distanceToEndcapLayers = new LCFloatVec;
    // For the full detector, store the layer positions of: 
    if(detectorType=="full") {
      // - the first 30 Ecal layers at a pitch of 3.9 mm
      if(l<=30) {
	distanceToBarrelLayers->push_back(1698.85+(3.9*l));
	distanceToEndcapLayers->push_back(2831.10+(3.9*l));
      }
      // - the last 10 Ecal layers at a pitch of 6.7 mm
      else if(l>30 && l<=ecalLayers) {
	distanceToBarrelLayers->push_back(1815.85+(6.7*(l-30)));
	distanceToEndcapLayers->push_back(2948.10+(6.7*(l-30))); 
      }
      // - the 40 Hcal layers at a pitch of 24.5 mm
      else if(l>ecalLayers && l<=totalLayers) {
	distanceToBarrelLayers->push_back(1931.25+(24.5*(l-41)));
	distanceToEndcapLayers->push_back(3039.25+(24.5*(l-41)));
      }
      // - the (arbitrarily-placed) 41st Hcal layer 
      else {
      	distanceToBarrelLayers->push_back(9999.);
      	distanceToEndcapLayers->push_back(9999.);
      }
    }
    // For the prototype detector, store the layer positions of:
    else if(detectorType=="prototype") {
      // - the first 10 Ecal layers at alternating pitches of 2.225 mm and 8.275 mm
      if(l<=10) {
	distanceToBarrelLayers->push_back(0.);
	distanceToEndcapLayers->push_back(((l+1)%2)*(-205.837+(10.5*l/2))+(l%2)*(-197.562+(10.5*(l-1)/2)));
      }
      // - the second 10 Ecal layers at alternating pitches of 3.625 mm and 9.675 mm
      else if(l>10 && l<=20) { 
	distanceToBarrelLayers->push_back(0.);
	distanceToEndcapLayers->push_back(((l+1)%2)*(-151.937+(13.3*(l-10)/2))+(l%2)*(-142.262+(13.3*(l-11)/2)));
      }
      // - the third 10 Ecal layers at alternating pitches of 5.025 mm and 11.075 mm
      else if(l>20 && l<=ecalLayers) {
	distanceToBarrelLayers->push_back(0.);
	distanceToEndcapLayers->push_back(((l+1)%2)*(-84.0375+(16.1*(l-20)/2))+(l%2)*(-72.9625+(16.1*(l-21)/2)));
      }
      // - the 40 Hcal layers at a pitch of 24.5 mm
      else if(l>ecalLayers && l<=1+totalLayers) {
	distanceToBarrelLayers->push_back(0.);
	distanceToEndcapLayers->push_back(0.0+(24.5*(l-ecalLayers)));
      }
    }
    // Add the layer positions to the collections
    distanceToBarrelLayersVec->push_back(distanceToBarrelLayers);
    distanceToEndcapLayersVec->push_back(distanceToEndcapLayers);
  }

  // Store the collections
  evt->addCollection(distanceToBarrelLayersVec,"distance_barrellayers");
  evt->addCollection(distanceToEndcapLayersVec,"distance_endcaplayers");

  // Don't write these to the LCIO output file
  distanceToBarrelLayersVec->setTransient();
  distanceToEndcapLayersVec->setTransient();

  if(printAction) cout << "    --> OK" << endl;
  }
  
  _nEvt ++;
}

void CalorimeterConfigurer::check( LCEvent * evt ) { 
  // nothing to check here - could be used to fill checkplots in reconstruction processor
}

void CalorimeterConfigurer::end(){ 
  
  std::cout << "CalorimeterConfigurer::end()  " << name() 
	    << " processed " << _nEvt << " events in " << _nRun << " runs "
	    << std::endl;

}

