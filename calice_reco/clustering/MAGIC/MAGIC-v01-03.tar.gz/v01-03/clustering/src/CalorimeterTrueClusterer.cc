#include "CalorimeterTrueClusterer.h"
#include "marlin/Global.h"

#include "IMPL/LCCollectionVec.h"
#include "IMPL/ClusterImpl.h"
#include "IMPL/LCFlagImpl.h"
#include "IMPL/LCRelationImpl.h"
#include "EVENT/SimCalorimeterHit.h"
#include "EVENT/MCParticle.h"
#include "EVENT/LCIntVec.h"
#include "UTIL/LCRelationNavigator.h"

using namespace lcio;
using namespace marlin;
using namespace std;


CalorimeterTrueClusterer aCalorimeterTrueClusterer;


CalorimeterTrueClusterer::CalorimeterTrueClusterer() : Processor("CalorimeterTrueClusterer") {
  
  // Processor description
  _description = "CalorimeterTrueClusterer assigns hits to true clusters, where a true cluster is considered to comprise all hits attributable to either (i) the same generator primary or any of its non-backscattered progeny or (ii) the same backscattered daughter or any of its non-backscattered progeny";
  
}


void CalorimeterTrueClusterer::init() { 

  // Set number of runs and events to 0
  _nRun = 0;
  _nEvt = 0;
  
  // Get parameters from steering file
  firstRun = Global::parameters->getIntVal("firstRun");
  lastRun = Global::parameters->getIntVal("lastRun");
  firstEventInFirstRun = Global::parameters->getIntVal("firstEventInFirstRun");
  lastEventInLastRun = Global::parameters->getIntVal("lastEventInLastRun");
  printAction = Global::parameters->getIntVal("printAction");
}

void CalorimeterTrueClusterer::processRunHeader( LCRunHeader* run) { 

  _nRun++;
} 

void CalorimeterTrueClusterer::processEvent( LCEvent * evt ) { 

  // Process events in this range
  if(!((evt->getRunNumber()<firstRun && evt->getRunNumber()>lastRun) ||
       (evt->getRunNumber()==firstRun && evt->getEventNumber()<firstEventInFirstRun) ||
       (evt->getRunNumber()==lastRun && evt->getEventNumber()>lastEventInLastRun))) {

  typedef const std::vector<std::string> NameVec;
  NameVec* strVec = evt->getCollectionNames();

  bool isSimulation=false;
  for(NameVec::const_iterator name=strVec->begin(); name!=strVec->end(); name++){
    string sss=name->c_str();
    if(sss=="CalorimeterHitRelationsToSimCalorimeterHits") {
      isSimulation=true;
    }
  }
  // Continue only if MC truth information is available
  if(isSimulation) {
  
  if(printAction) {
    cout << "  - assigning hits to true clusters...." << endl
	 << "    (a true cluster is considered to comprise all hits attributable to either:" << endl
	 << "      (i) the same generator primary or any of its non-backscattered progeny, or" << endl
	 << "     (ii) the same backscattered daughter or any of its non-backscattered progeny)" << endl;  
  }

  // Create collections to store:
  // - the true clusters
  LCCollectionVec* trueClusterVec = new LCCollectionVec(LCIO::CLUSTER);
  // - the relation between the true clusters and the MC particles (runs in parallel with trueClusterVec)
  LCCollectionVec* mCParticleRelVec = new LCCollectionVec(LCIO::LCRELATION);
  // - the (arbitrary) integer ids of the MC particles (runs in parallel with trueClusterVec)
  LCCollectionVec* mCIDOfParticleVec = new LCCollectionVec(LCIO::LCINTVEC);
  // - the (arbitrary) integer ids of the MC particles contributing to simulated hits 
  //   (runs in parallel with hitVec) 
  LCCollectionVec* mCIDsOfHitVec = new LCCollectionVec(LCIO::LCINTVEC);

  // Set the relation from and to types for the true clusters
  mCParticleRelVec->parameters().setValue( "RelationFromType",LCIO::CLUSTER);
  mCParticleRelVec->parameters().setValue( "RelationToType",LCIO::MCPARTICLE);

  // Retrieve these collections
  LCCollection* mCParticleVec=evt->getCollection(LCIO::MCPARTICLE);
  LCCollection* hitVec=evt->getCollection("CalorimeterHits");
  LCCollection* simHitRelVec=evt->getCollection("CalorimeterHitRelationsToSimCalorimeterHits");
  LCRelationNavigator simHitRel(simHitRelVec); 

  int i, j, k, p, u;
  float contribution;

  // Loop over MC particles
  for(i=0;i<mCParticleVec->getNumberOfElements();i++) {
    MCParticle* mCParticle1 = dynamic_cast<MCParticle*>(mCParticleVec->getElementAt(i));
    LCIntVec* mCIDOfParticle1 = new LCIntVec;
    // Create a new MC id if the particle is a generator primary or a backscattered daughter
    if(mCParticle1->getGeneratorStatus()==1 || mCParticle1->isBackscatter()) {
      mCIDOfParticle1->push_back(i+1);    
    }
    // Copy the existing MC id of the most recent backscattered parent, else of the original generator 
    // primary if the particle is a non-backscattered daughter
    else {
      for(j=0;j<i;j++){
	MCParticle* mCParticle2 = dynamic_cast<MCParticle*>(mCParticleVec->getElementAt(j));
	LCIntVec* mCIDOfParticle2 = dynamic_cast<LCIntVec*>(mCIDOfParticleVec->getElementAt(j));
	if(mCParticle1->getParents()[0]==mCParticle2) {
	  mCIDOfParticle1->push_back(*mCIDOfParticle2->begin());
	}
      }
    }
    // Add the MC id of the particle to the collection
    mCIDOfParticleVec->push_back(mCIDOfParticle1);
  }

  // Loop over the hits
  for(i=0;i<hitVec->getNumberOfElements();i++) {
    CalorimeterHit* hit = dynamic_cast<CalorimeterHit*>(hitVec->getElementAt(i));
    SimCalorimeterHit* simHit = dynamic_cast<SimCalorimeterHit*>(simHitRel.getRelatedToObjects(hit)[0]);
    LCIntVec* mCIDsOfHit = new LCIntVec;
    // Loop over the subhits contributing to the i^th hit
    for(k=0;k<simHit->getNMCContributions();k++) {
      // Loop over MC particles
      for(j=0;j<mCParticleVec->getNumberOfElements();j++){
	MCParticle* mCParticle = dynamic_cast<MCParticle*>(mCParticleVec->getElementAt(j));
	LCIntVec* mCIDOfParticle = dynamic_cast<LCIntVec*>(mCIDOfParticleVec->getElementAt(j));
	// Find which MC particle is responsible for the k^th subhit of the i^th hit and store the
	// MC id of this particle for this hit
	if(simHit->getParticleCont(k)==mCParticle) {
	  mCIDsOfHit->push_back(*mCIDOfParticle->begin());
	}
      }
    }
    // Add the MC ids of the hit to the collection
    mCIDsOfHitVec->push_back(mCIDsOfHit);
  }

  // Loop over MC particles
  for(p=0;p<mCParticleVec->getNumberOfElements();p++) {
    // Create a new true cluster
    ClusterImpl* trueCluster = new ClusterImpl;
    // Loop over the hits...
    for(i=0;i<hitVec->getNumberOfElements();i++) {
      CalorimeterHit* hit = dynamic_cast<CalorimeterHit*>(hitVec->getElementAt(i));
      SimCalorimeterHit* simHit = dynamic_cast<SimCalorimeterHit*>(simHitRel.getRelatedToObjects(hit)[0]);
      LCIntVec* mCIDsOfHit = dynamic_cast<LCIntVec*>(mCIDsOfHitVec->getElementAt(i));
      contribution=0.;
      // ...and the subhits contributing to the hit 
      for(u=0;u<simHit->getNMCContributions();u++) {
	// Accumulate the energy contribution to the hit from the current MC particle
	if(*(mCIDsOfHit->begin()+u)==p+1) {
	  contribution+=simHit->getEnergyCont(u);
	}
      }
      // If the hit has a contribution from the MC particle, add the hit together with its
      // energy contribution to the true cluster
      if(contribution>0.) {
	trueCluster->addHit(hit,contribution);
      }
    }
    // If the MC particle contributes to at least one calorimeter hit, add the true cluster to
    // the collection; also add a pointer from this true cluster to the MC particle itself
    if(trueCluster->getCalorimeterHits().size()>0) {
      MCParticle* mCParticle = dynamic_cast<MCParticle*>(mCParticleVec->getElementAt(p));
      mCParticleRelVec->addElement(new LCRelationImpl(trueCluster,mCParticle));
      trueClusterVec->push_back(trueCluster);
    }
  }

  // Save the cluster hits when the true clusters are written to the LCIO output file
  LCFlagImpl chflag(0);
  chflag.setBit(LCIO::CLBIT_HITS);
  trueClusterVec->setFlag(chflag.getFlag());

  // Store the collections
  evt->addCollection(trueClusterVec,"CalorimeterTrueClusters");
  evt->addCollection(mCParticleRelVec,"CalorimeterTrueClusterRelationsToMCParticles");

  if(printAction) cout << "    --> OK" << endl;
  }
  }
  
  _nEvt ++;
}



void CalorimeterTrueClusterer::check( LCEvent * evt ) { 
  // nothing to check here - could be used to fill checkplots in reconstruction processor
}


void CalorimeterTrueClusterer::end(){ 
  
  std::cout << "CalorimeterTrueClusterer::end()  " << name() 
	    << " processed " << _nEvt << " events in " << _nRun << " runs "
	    << std::endl;

}

