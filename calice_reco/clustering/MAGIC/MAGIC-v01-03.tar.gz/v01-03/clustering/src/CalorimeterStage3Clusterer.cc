#include "CalorimeterStage3Clusterer.h"
#include "marlin/Global.h"
#include <math.h>

#include "IMPL/LCCollectionVec.h"
#include "IMPL/ClusterImpl.h"
#include "IMPL/LCFlagImpl.h"
#include "EVENT/LCIntVec.h"

using namespace lcio;
using namespace marlin;
using namespace std;


CalorimeterStage3Clusterer aCalorimeterStage3Clusterer;


CalorimeterStage3Clusterer::CalorimeterStage3Clusterer() : Processor("CalorimeterStage3Clusterer") {
  
  // Processor description
  _description = "CalorimeterStage3Clusterer recovers backward-spiralling track-like cluster-fragments";
  

  // Register steering parameters: name, description, class-variable, default value

  registerProcessorParameter("proxMergeMax_ecal", 
			     "proximity cut for cluster merging in Ecal (in mm)",
			     _proxMergeMax_ecal,
			     std::string("20.0")); 
  registerProcessorParameter("proxMergeMax_hcal", 
			     "proximity cut for cluster merging in Hcal (in mm)",
			     _proxMergeMax_hcal,
			     std::string("30.0")); 
  registerProcessorParameter("cosGammaMax", 
			     "angular cut for cluster merging (effective range [-1.0,+1.0])",
			     _cosGammaMax,
			     std::string("0.5"));

}


void CalorimeterStage3Clusterer::init() { 

  // Print processor parameters
  printParameters();

  // Set number of runs and events to 0
  _nRun = 0;
  _nEvt = 0;
  
  // Get parameters from steering file
  firstRun = Global::parameters->getIntVal("firstRun");
  lastRun = Global::parameters->getIntVal("lastRun");
  firstEventInFirstRun = Global::parameters->getIntVal("firstEventInFirstRun");
  lastEventInLastRun = Global::parameters->getIntVal("lastEventInLastRun");
  printAction = Global::parameters->getIntVal("printAction");
  ecalLayers = Global::parameters->getIntVal("ecalLayers");
  hcalLayers = Global::parameters->getIntVal("hcalLayers");
  totalLayers = ecalLayers+hcalLayers;
  proxMergeMax_ecal = parameters()->getFloatVal("proxMergeMax_ecal");
  proxMergeMax_hcal = parameters()->getFloatVal("proxMergeMax_hcal");
  cosGammaMax = parameters()->getFloatVal("cosGammaMax");

}

void CalorimeterStage3Clusterer::processRunHeader( LCRunHeader* run) { 

  _nRun++;
} 

void CalorimeterStage3Clusterer::processEvent( LCEvent * evt ) { 

  // Process events in this range
  if(!((evt->getRunNumber()<firstRun && evt->getRunNumber()>lastRun) ||
       (evt->getRunNumber()==firstRun && evt->getEventNumber()<firstEventInFirstRun) ||
       (evt->getRunNumber()==lastRun && evt->getEventNumber()>lastEventInLastRun))) {

  if(printAction) cout << "  - recovering backward-spiralling track-like cluster-fragments...." << endl;
    
  // Create collections to store:
  // - the stage 3 clusters
  LCCollectionVec* cluster3Vec = new LCCollectionVec(LCIO::CLUSTER);
  // - additional attributes of the stage 3 clusters (runs in parallel with cluster3Vec)
  LCCollectionVec* cluster3XtraVec = new LCCollectionVec(LCIO::CLUSTER);
  // - the seed pseudolayer of stage 3 clusters (runs in parallel with cluster3Vec)
  LCCollectionVec* seedPseudolayerOfCluster3Vec = new LCCollectionVec(LCIO::LCINTVEC);

  // Retrieve these collections
  LCCollection* cluster2Vec=evt->getCollection("CalorimeterStage2Clusters");
  LCCollection* cluster2XtraVec=evt->getCollection("CalorimeterStage2ClustersXtra");
  LCCollection* seedPseudolayerOfCluster2Vec=evt->getCollection("CalorimeterStage2ClusterSeedPseudolayers");
  LCCollection* lastPseudolayerOfCluster2Vec=evt->getCollection("CalorimeterStage2ClusterLastPseudolayers");

  int i, j, l, p, u;
  float prox_merge, proxMergeMax;
  float wmax;
  float cos_gamma;
  int merging_cluster;
  int earliestSeedLayer;
  int count_merged=0;

  // Loop over pseudolayers in reverse order
  for(l=totalLayers;l>=1;l--) {
    if(l<=ecalLayers) proxMergeMax=proxMergeMax_ecal;
    else proxMergeMax=proxMergeMax_hcal;
    // Loop over clusters...
    for(i=0;i<cluster2Vec->getNumberOfElements();i++) {
      Cluster* cluster2 = dynamic_cast<Cluster*>(cluster2Vec->getElementAt(i));
      Cluster* cluster2Xtra = dynamic_cast<Cluster*>(cluster2XtraVec->getElementAt(i));
      LCIntVec* lastPseudolayerOfCluster2 = dynamic_cast<LCIntVec*>(lastPseudolayerOfCluster2Vec->getElementAt(i));
      // ...that terminate in the current pseudolayer (if more than one cluster terminates in the pseudolayer, 
      // the cluster with the earlier/earliest seed pseudolayer is treated first (by construction))
      if(*lastPseudolayerOfCluster2->begin()==l) {
	LCIntVec* seedPseudolayerOfCluster2 = dynamic_cast<LCIntVec*>(seedPseudolayerOfCluster2Vec->getElementAt(i));
	int seedPseudolayer1=*seedPseudolayerOfCluster2->begin();
	merging_cluster=0;
	earliestSeedLayer=1+totalLayers;
	wmax=0.;
	// Loop over the hits... 
	for(j=0;j<int(cluster2->getCalorimeterHits().size());j++) {
	  const float* pos1=cluster2->getCalorimeterHits()[j]->getPosition();
	  const float* dir1=cluster2Xtra->getCalorimeterHits()[j]->getPosition();
	  float contribution=cluster2Xtra->getHitContributions()[j];
	  int pseudolayer1=1+cluster2->getCalorimeterHits()[j]->getCellID1()/16777216;
	  // ...in the terminating pseudolayer of this cluster
	  if(pseudolayer1==l) {
	    // Loop over clusters that terminate in later pseudolayers (by contruction)...
	    for(p=0;p<cluster3Vec->getNumberOfElements();p++) {
	      Cluster* cluster3 = dynamic_cast<Cluster*>(cluster3Vec->getElementAt(p));
	      Cluster* cluster3Xtra = dynamic_cast<Cluster*>(cluster3XtraVec->getElementAt(p));
	      LCIntVec* seedPseudolayerOfCluster3 = dynamic_cast<LCIntVec*>(seedPseudolayerOfCluster3Vec->getElementAt(p));
	      int seedPseudolayer2=*seedPseudolayerOfCluster3->begin();
	      // ...and that are seeded in pseudolayers earlier than the current earliest seed pseudolayer of any cluster
	      // with which merging is possible, or the same pseudolayer as that cluster if the current hit in the 
	      // terminating cluster has a higher weight than the hit in the terminating cluster which resulted in that 
	      // possible merging 
	      if((seedPseudolayer2 < earliestSeedLayer) || 
		 (seedPseudolayer2==earliestSeedLayer && contribution>wmax)) {
		// Loop over the hits... 
		for(u=0;u<int(cluster3->getCalorimeterHits().size());u++) {  
		  const float* pos2=cluster3->getCalorimeterHits()[u]->getPosition();
		  const float* dir2=cluster3Xtra->getCalorimeterHits()[u]->getPosition();
		  int pseudolayer2=1+cluster3->getCalorimeterHits()[u]->getCellID1()/16777216;
		  // ...in the current pseudolayer of this cluster
		  if(pseudolayer2==l) {
		    // Calculate the proximity of the hit in the terminating pseudolayer of the terminating cluster 
		    // to the hit in the same pseudolayer of the later-terminating cluster
		    prox_merge=fabs(sqrt(pow(pos1[0]-pos2[0],2)+
					 pow(pos1[1]-pos2[1],2)+
					 pow(pos1[2]-pos2[2],2)));
		    // If this is smaller than the minimum impermissible proximity...
		    if(prox_merge<proxMergeMax) {
		      // ...calculate the cosine of the angle, gamma, between the direction cosines of these hits
		      cos_gamma=((dir1[0]*dir2[0])+
				 (dir1[1]*dir2[1])+
				 (dir1[2]*dir2[2]))/
			fabs(sqrt((pow(dir1[0],2)+pow(dir1[1],2)+pow(dir1[2],2))*
				  (pow(dir2[0],2)+pow(dir2[1],2)+pow(dir2[2],2))));
		      // If the proximity is sufficiently small and gamma is sufficiently large, flag the later-terminating
		      // cluster that contains this hit as the cluster with which the terminating cluster will be merged,
		      // unless an earlier-seeded cluster can be found that satisfies the merging criteria
		      if(cos_gamma<cosGammaMax) {
			merging_cluster=p+1;
			earliestSeedLayer=seedPseudolayer2;
			wmax=contribution;
		      }
		    }
		  }
		}
	      }
	    }
	  }
	}
	// If the merging criteria are not satisfied, create a new stage 3 cluster and new instances of other 
	// stage 3 cluster attributes and add each to their respective collections
	if(merging_cluster==0) {
	  ClusterImpl* cluster3 = new ClusterImpl;
	  ClusterImpl* cluster3Xtra = new ClusterImpl;
	  LCIntVec* seedPseudolayerOfCluster3 = new LCIntVec;
	  cluster3Vec->push_back(cluster3);
	  cluster3XtraVec->push_back(cluster3Xtra);
	  seedPseudolayerOfCluster3Vec->push_back(seedPseudolayerOfCluster3);
	  // Loop over the hits in the original cluster; add the hits together with their energies to the new 
	  // cluster, and add their direction cosines together with their weight to the cluster attributes
	  for(u=0;u<int(cluster2->getCalorimeterHits().size());u++) {
	    cluster3->addHit(cluster2->getCalorimeterHits()[u],cluster2->getCalorimeterHits()[u]->getEnergy());
	    cluster3Xtra->addHit(cluster2Xtra->getCalorimeterHits()[u],cluster2Xtra->getHitContributions()[u]);
	  }
	  // Add a pointer to the copied stage 2 cluster 
	  cluster3->addCluster(cluster2);
	  // Set the cluster's seed pseudolayer to that of the corresponding stage 2 cluster
	  seedPseudolayerOfCluster3->push_back(seedPseudolayer1);
	}	
	// If the merging criteria are satisfied, invoke the merging stage 3 cluster and instances of other
	// merging stage 3 cluster attributes
	else {
	  ClusterImpl* cluster3 = dynamic_cast<ClusterImpl*>(cluster3Vec->getElementAt(merging_cluster-1));
	  ClusterImpl* cluster3Xtra = dynamic_cast<ClusterImpl*>(cluster3XtraVec->getElementAt(merging_cluster-1));
	  LCIntVec* seedPseudolayerOfCluster3 = dynamic_cast<LCIntVec*>(seedPseudolayerOfCluster3Vec->getElementAt(merging_cluster-1));
	  // Loop over the hits in the original cluster; add the hits together with their energies to the merging 
	  // cluster, and add their direction cosines together with their weights to the cluster attributes
	  for(u=0;u<int(cluster2->getCalorimeterHits().size());u++) {
	    cluster3->addHit(cluster2->getCalorimeterHits()[u],cluster2->getCalorimeterHits()[u]->getEnergy());
	    cluster3Xtra->addHit(cluster2Xtra->getCalorimeterHits()[u],cluster2Xtra->getHitContributions()[u]);
	  }
	  // Add a pointer to the contributing stage 2 cluster 
	  cluster3->addCluster(cluster2);
	  int seedPseudolayer2=*seedPseudolayerOfCluster3->begin();
	  // If the contributing stage 2 cluster's seed pseudolayer is before that of the merging cluster,
	  // update the stage 3 cluster seed pseudolayer
	  if(seedPseudolayer1 < seedPseudolayer2) {
	    seedPseudolayerOfCluster3->pop_back();
	    seedPseudolayerOfCluster3->push_back(seedPseudolayer1);
	  }
	  count_merged++;
	}
      }
    }
  }
  
  // Store the cluster hits when the clusters collection is written to the LCIO output file
  LCFlagImpl chflag(0);
  chflag.setBit(LCIO::CLBIT_HITS);
  cluster3Vec->setFlag(chflag.getFlag());

  // Store the collections
  evt->addCollection(cluster3Vec,"CalorimeterStage3Clusters");
  evt->addCollection(cluster3XtraVec,"CalorimeterStage3ClustersXtra");
  evt->addCollection(seedPseudolayerOfCluster3Vec,"CalorimeterStage3ClusterSeedPseudolayers");

  // Don't write these to the LCIO output file
  cluster3XtraVec->setTransient();
  seedPseudolayerOfCluster3Vec->setTransient();

  if(printAction) {
    cout << "    --> OK (" << count_merged;
    count_merged==1 ? cout << " cluster recovered)" : cout << " clusters recovered)";
    cout << endl;
  }
  }
  
  _nEvt ++;
}

void CalorimeterStage3Clusterer::check( LCEvent * evt ) { 
  // nothing to check here - could be used to fill checkplots in reconstruction processor
}

void CalorimeterStage3Clusterer::end(){ 
  
  std::cout << "CalorimeterStage3Clusterer::end()  " << name() 
	    << " processed " << _nEvt << " events in " << _nRun << " runs "
	    << std::endl;

}

