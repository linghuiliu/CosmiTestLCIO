#include "CalorimeterStage4Clusterer.h"
#include "marlin/Global.h"
#include <math.h>

#include "IMPL/LCCollectionVec.h"
#include "IMPL/ClusterImpl.h"
#include "IMPL/LCFlagImpl.h"
#include "EVENT/LCIntVec.h"

using namespace lcio;
using namespace marlin;
using namespace std;


CalorimeterStage4Clusterer aCalorimeterStage4Clusterer;


CalorimeterStage4Clusterer::CalorimeterStage4Clusterer() : Processor("CalorimeterStage4Clusterer") {
  
  // Processor description
  _description = "CalorimeterStage4Clusterer recovers low-multiplicity cluster-fragments";
  

  // Register steering parameters: name, description, class-variable, default value

  registerProcessorParameter("clusterSizeMin", 
			     "minimum cluster size to avert potential cluster merging",
			     _clusterSizeMin,
			     std::string("10"));
  registerProcessorParameter("layersToTrackBackMax_ecal", 
			     "number of layers to track back for cluster merging in Ecal (effective range [1,ecalLayers-1])",
			     _layersToTrackBackMax_ecal,
			     std::string("39")); 
  registerProcessorParameter("layersToTrackBackMax_hcal", 
			     "number of layers to track back for cluster merging in Hcal (effective range [1,ecalLayers+hcalLayers-1])",
			     _layersToTrackBackMax_hcal,
			     std::string("79")); 
  registerProcessorParameter("tanBetaMax", 
			     "angular cut for cluster merging",
			     _tanBetaMax,
			     std::string("6.0"));
  registerProcessorParameter("proxMergeMax_ecal", 
			     "proximity cut for cluster merging in Ecal (in mm)",
			     _proxMergeMax_ecal,
			     std::string("400.0"));
  registerProcessorParameter("proxMergeMax_hcal", 
			     "proximity cut for cluster merging in Hcal (in mm)",
			     _proxMergeMax_hcal,
			     std::string("400.0"));

}


void CalorimeterStage4Clusterer::init() { 

  // Print processor parameters
  printParameters();

  // Set number of runs and events to 0
  _nRun = 0;
  _nEvt = 0;
  
  // Get parameters from steering file
  firstRun = Global::parameters->getIntVal("firstRun");
  lastRun = Global::parameters->getIntVal("lastRun");
  firstEventInFirstRun = Global::parameters->getIntVal("firstEventInFirstRun");
  lastEventInLastRun = Global::parameters->getIntVal("lastEventInLastRun");
  printAction = Global::parameters->getIntVal("printAction");
  detectorType = Global::parameters->getStringVal("detectorType");
  ecalLayers = Global::parameters->getIntVal("ecalLayers");
  hcalLayers = Global::parameters->getIntVal("hcalLayers");
  totalLayers = ecalLayers+hcalLayers;
  barrelSymmetry = Global::parameters->getIntVal("barrelSymmetry");
  phi_1 = (Global::parameters->getFloatVal("phi_1"))*acos(-1.)/180.;
  clusterSizeMin = parameters()->getIntVal("clusterSizeMin");
  layersToTrackBackMax_ecal = parameters()->getIntVal("layersToTrackBackMax_ecal");
  layersToTrackBackMax_hcal = parameters()->getIntVal("layersToTrackBackMax_hcal");
  tanBetaMax = parameters()->getFloatVal("tanBetaMax");
  proxMergeMax_ecal = parameters()->getFloatVal("proxMergeMax_ecal");
  proxMergeMax_hcal = parameters()->getFloatVal("proxMergeMax_hcal");
}

void CalorimeterStage4Clusterer::processRunHeader( LCRunHeader* run) { 

  _nRun++;
} 

void CalorimeterStage4Clusterer::processEvent( LCEvent * evt ) { 

  // Process events in this range
  if(!((evt->getRunNumber()<firstRun && evt->getRunNumber()>lastRun) ||
       (evt->getRunNumber()==firstRun && evt->getEventNumber()<firstEventInFirstRun) ||
       (evt->getRunNumber()==lastRun && evt->getEventNumber()>lastEventInLastRun))) {

  if(printAction) cout << "  - recovering low multiplicity cluster fragments...." << endl;

  // Create collections to store:
  // - the stage 4 clusters
  LCCollectionVec* cluster4Vec = new LCCollectionVec(LCIO::CLUSTER);
  // - additional attributes of the stage 4 clusters
  LCCollectionVec* cluster4XtraVec = new LCCollectionVec(LCIO::CLUSTER);

  // Retrieve these collections
  LCCollection* cluster3Vec=evt->getCollection("CalorimeterStage3Clusters");
  LCCollection* cluster3XtraVec=evt->getCollection("CalorimeterStage3ClustersXtra");
  LCCollection* seedPseudolayerOfCluster3Vec=evt->getCollection("CalorimeterStage3ClusterSeedPseudolayers");

  int i, j, k, l, p, q, u;
  double pi=acos(-1.);
  int merging_cluster;
  int count_merged=0;
  int layersToTrackBackMax;
  bool OK;
  float delta_r_perp=0.;
  float dir_cos_perp=0.;
  float prox_merge, prox_merge_min, proxMergeMax;
  float tan_beta, tan_beta_min;
  float wmax;
  float cos_stavecentreangle[3+barrelSymmetry];
  float sin_stavecentreangle[3+barrelSymmetry];

  // Set up some geometrical parameters for use later
  for(p=1;p<=2+barrelSymmetry;p++) {
    cos_stavecentreangle[p]=cos(((p-1)*2*pi/barrelSymmetry)+phi_1);
    sin_stavecentreangle[p]=sin(((p-1)*2*pi/barrelSymmetry)+phi_1);
  }

  // Loop over pseudolayers
  for(l=1;l<=totalLayers;l++) {
    if(l<=ecalLayers) {
      layersToTrackBackMax=layersToTrackBackMax_ecal;
      proxMergeMax=proxMergeMax_ecal;
    }
    else {
      layersToTrackBackMax=layersToTrackBackMax_hcal;
      proxMergeMax=proxMergeMax_hcal;
    }
    // Loop over clusters...
    for(k=0;k<cluster3Vec->getNumberOfElements();k++) {
      Cluster* cluster3 = dynamic_cast<Cluster*>(cluster3Vec->getElementAt(k));
      Cluster* cluster3Xtra = dynamic_cast<Cluster*>(cluster3XtraVec->getElementAt(k));
      LCIntVec* seedPseudolayerOfCluster3 = dynamic_cast<LCIntVec*>(seedPseudolayerOfCluster3Vec->getElementAt(k));
      // ...seeded in the current pseudolayer 
      if(*seedPseudolayerOfCluster3->begin()==l) { 
	merging_cluster=0;
	// Initialise the minimum cone angle to the minimum impermissible cone angle
	tan_beta_min=tanBetaMax;
	// Of these clusters, consider those with multiplicities below the threshold size 
	if(int(cluster3->getCalorimeterHits().size())<clusterSizeMin) {
	  // If the cluster has yet to be merged with a cluster continuing from a previous pseudolayer,
	  // loop over the hits in the seed pseudolayer in weight order (by construction)...
	  for(i=0;i<int(cluster3->getCalorimeterHits().size());i++) {
	    const float* pos1=cluster3->getCalorimeterHits()[i]->getPosition();
	    int pseudolayer1=1+cluster3->getCalorimeterHits()[i]->getCellID1()/16777216;
	    if(merging_cluster!=0) break;
	    else if(pseudolayer1==l) {
	      // Loop over previous pseudolayers in reverse order...
	      for(q=1;q<=layersToTrackBackMax && q<=l-1;q++) {
		// ...unless the seed hit has been assigned to a cluster continuing from a previous pseudolayer
		if(merging_cluster!=0) break;
		else {
		  wmax=0.;
		  // Loop over clusters with earlier seed pseudolayers (by construction)
		  for(p=0;p<cluster4Vec->getNumberOfElements();p++) {
		    Cluster* cluster4 = dynamic_cast<Cluster*>(cluster4Vec->getElementAt(p));
		    Cluster* cluster4Xtra = dynamic_cast<Cluster*>(cluster4XtraVec->getElementAt(p));
		    // and consider the hits...
		    for(u=0;u<int(cluster4->getCalorimeterHits().size());u++) {
		      const float* pos2=cluster4->getCalorimeterHits()[u]->getPosition();
		      const float* dir2=cluster4Xtra->getCalorimeterHits()[u]->getPosition();
		      int pseudolayer2=1+cluster4->getCalorimeterHits()[u]->getCellID1()/16777216;
		      // ...in the current particular previous pseudolayer
		      if(pseudolayer2==l-q) {
			OK=false;
			// Here for the full detector comprising barrel and endcaps
			if(detectorType=="full") {
			  int pseudostave1=1+(cluster3->getCalorimeterHits()[i]->getCellID1()%16777216)/8;
			  int pseudostave2=1+(cluster4->getCalorimeterHits()[u]->getCellID1()%16777216)/8;
			  // Create geometrical constructs if the hit in the previous pseudolayer:
			  // - is in the pseudobarrel (links permitted only to hits in pseudoendcaps and adjacent 
			  //   pseudobarrel pseudostaves)
			  if(pseudostave2<=barrelSymmetry && (pseudostave1>barrelSymmetry || 
						    (pseudostave1<=barrelSymmetry && 
						     (abs(pseudostave2-pseudostave1)<=1 || 
						      abs(pseudostave2-pseudostave1)==barrelSymmetry-1)))) {
			    dir_cos_perp=dir2[0]*cos_stavecentreangle[pseudostave2] + dir2[1]*sin_stavecentreangle[pseudostave2];
			    if(dir_cos_perp>0.) {
			      OK=true;
			      delta_r_perp=(pos1[0]-pos2[0])*cos_stavecentreangle[pseudostave2]+
				(pos1[1]-pos2[1])*sin_stavecentreangle[pseudostave2];
			    }
			  }
			  // - is in the LH pseudoendcap (z<0) (links permitted to all pseudostaves except the
			  //   RH pseudoendcap)
			  else if(pseudostave2==barrelSymmetry+1 && pseudostave1!=barrelSymmetry+2) {
			    dir_cos_perp=-dir2[2];
			    if(dir_cos_perp>0.) {
			      OK=true;
			      delta_r_perp=-pos1[2]+pos2[2];
			    }
			  }
			  // - is in the RH pseudoendcap (z>0) (links permitted to all pseudostaves except the
			  //   LH pseudoendcap)
			  else if(pseudostave2==barrelSymmetry+2 && pseudostave1!=barrelSymmetry+1) {
			    dir_cos_perp=+dir2[2];
			    if(dir_cos_perp>0.) {
			      OK=true;
			      delta_r_perp=+pos1[2]-pos2[2];
			    }
			  }
			}
			// Here for a prototype comprising a single endcap with layers aligned perpendicularly to 
			// the +z direction
			else if(detectorType=="prototype") {
			  // Create geometrical constructs
			  dir_cos_perp=+dir2[2];
			  if(dir_cos_perp>0.) {
			    OK=true;
			    delta_r_perp=+pos1[2]-pos2[2];
			  }
			}
			// Accept only forward propagation through pseudolayers
			if(OK && delta_r_perp > 0.) {
			  // Calculate the tangent of the cone angle...
			  tan_beta=
			    fabs(sqrt(pow(((pos1[0]-pos2[0])/delta_r_perp)-(dir2[0]/(dir_cos_perp)),2)+
				      pow(((pos1[1]-pos2[1])/delta_r_perp)-(dir2[1]/(dir_cos_perp)),2)+
				      pow(((pos1[2]-pos2[2])/delta_r_perp)-(dir2[2]/(dir_cos_perp)),2)));
			  // ...and minimise w.r.t all hits in the previous pseudolayer, subject to
			  // tan(beta) < tan(beta_max); flag the cluster that contains this hit as the cluster
			  // with which the low-multiplicity cluster will be merged (in the event of a tie, 
			  // flag as the cluster containing the linking hit of higher/highest weight)
			  if(tan_beta<tanBetaMax && (tan_beta<tan_beta_min || 
						     (tan_beta==tan_beta_min && cluster4Xtra->getHitContributions()[u]>wmax))) {
			    tan_beta_min=tan_beta;
			    wmax=cluster4Xtra->getHitContributions()[u];
			    merging_cluster=p+1;
			  }
			}
		      }
		    }
		  }  
		}
	      }
	    }
	  }
	  // If the low-multiplicity cluster cannot be matched onto a cluster continuing from a previous pseudolayer, 
	  // try to merge it onto a cluster in the seed pseudolayer (possibly another low-multiplicity cluster)  
	  if(merging_cluster==0) {
	    prox_merge_min=proxMergeMax;
	    wmax=0.;
	    // Loop over the hits in the seed pseudolayer in weight order (by construction)
	    for(u=0;u<int(cluster3->getCalorimeterHits().size());u++) {
	      const float* pos1=cluster3->getCalorimeterHits()[u]->getPosition();
	      int pseudolayer1=1+cluster3->getCalorimeterHits()[u]->getCellID1()/16777216;
	      if(pseudolayer1==l) {
		// Loop over clusters seeded in earlier pseudolayers (by contruction)
		for(p=0;p<cluster4Vec->getNumberOfElements();p++) {
		  Cluster* cluster4 = dynamic_cast<Cluster*>(cluster4Vec->getElementAt(p));
		  Cluster* cluster4Xtra = dynamic_cast<Cluster*>(cluster4XtraVec->getElementAt(p));
		  // Loop over the hits in the current pseudolayer of this cluster
		  for(j=0;j<int(cluster4->getCalorimeterHits().size());j++) {
		    const float* pos2=cluster4->getCalorimeterHits()[j]->getPosition();
		    int pseudolayer2=1+cluster4->getCalorimeterHits()[j]->getCellID1()/16777216;
		    if(pseudolayer2==l) {
		      // Calculate the proximity of the hit in the seed pseudolayer of the low-multiplicity cluster to 
		      // the hit in the same pseudolayer of the earlier-seeded cluster...
		      prox_merge=fabs(sqrt(pow(pos1[0]-pos2[0],2)+
					   pow(pos1[1]-pos2[1],2)+
					   pow(pos1[2]-pos2[2],2)));
		      // ...and minimise this w.r.t all hits in this pseudolayer in earlier-seeded clusters, subject to
		      // prox_merge < proxMergeMax; flag the cluster that contains this hit as the cluster with which
		      // the low-multiplicity cluster will be merged (in the event of a tie, flag as the cluster 
		      // containing the linking hit of higher/highest weight)
		      if(prox_merge<proxMergeMax && (prox_merge<prox_merge_min || 
						     (prox_merge==prox_merge_min && cluster4Xtra->getHitContributions()[j]>wmax))) {
			merging_cluster=p+1;
			prox_merge_min=prox_merge;				
			wmax=cluster4Xtra->getHitContributions()[j];
		      }
		    }
		  }
		}
	      }
	    }		
	  }
	}
	// If the merging criteria are not satisfied, create a new stage 4 cluster and new instances of other 
	// stage 4 cluster attributes and add each to their respective collections
	if(merging_cluster==0) {
	  ClusterImpl* cluster4 = new ClusterImpl;
	  ClusterImpl* cluster4Xtra = new ClusterImpl;
	  cluster4Vec->push_back(cluster4);
	  cluster4XtraVec->push_back(cluster4Xtra);
	  // Loop over the hits in the original cluster; add the hits together with their energies to the new
	  // cluster, and add their direction cosines together with their weight to the cluster attributes
	  for(u=0;u<int(cluster3->getCalorimeterHits().size());u++) {
	    cluster4->addHit(cluster3->getCalorimeterHits()[u],cluster3->getCalorimeterHits()[u]->getEnergy());
	    cluster4Xtra->addHit(cluster3Xtra->getCalorimeterHits()[u],cluster3Xtra->getHitContributions()[u]);
	  }
	  // Add a pointer to the copied stage 3 cluster
	  cluster4->addCluster(cluster3);
	}
	// If the merging criteria are satisfied, invoke the merging stage 4 cluster and instances of other
	// merging stage 4 cluster attributes
	else {
	  ClusterImpl* cluster4 = dynamic_cast<ClusterImpl*>(cluster4Vec->getElementAt(merging_cluster-1));
	  ClusterImpl* cluster4Xtra = dynamic_cast<ClusterImpl*>(cluster4XtraVec->getElementAt(merging_cluster-1));
	  // Loop over the hits in the original cluster; add the hits together with their energies to the merging
	  // cluster, and add their direction cosines together with their weights to the cluster attributes
	  for(u=0;u<int(cluster3->getCalorimeterHits().size());u++) {
	    cluster4->addHit(cluster3->getCalorimeterHits()[u],cluster3->getCalorimeterHits()[u]->getEnergy());
	    cluster4Xtra->addHit(cluster3Xtra->getCalorimeterHits()[u],cluster3Xtra->getHitContributions()[u]);
	  }
	  // Add a pointer to the contributing stage 3 cluster
	  cluster4->addCluster(cluster3);
	  count_merged++;
	}
      }
    }
  }

  // Store the cluster hits when the clusters collection is written to the LCIO output file
  LCFlagImpl chflag(0);
  chflag.setBit(LCIO::CLBIT_HITS);
  cluster4Vec->setFlag(chflag.getFlag());

  // Store the collections
  evt->addCollection(cluster4Vec,"CalorimeterStage4Clusters");

  if(printAction) {
    cout << "    --> OK (" << count_merged;
    count_merged==1 ? cout << " cluster recovered)" : cout << " clusters recovered)";
    cout << endl;
  }
  }
  
  _nEvt ++;
}

void CalorimeterStage4Clusterer::check( LCEvent * evt ) { 
  // nothing to check here - could be used to fill checkplots in reconstruction processor
}

void CalorimeterStage4Clusterer::end(){ 
  
  std::cout << "CalorimeterStage4Clusterer::end()  " << name() 
	    << " processed " << _nEvt << " events in " << _nRun << " runs "
	    << std::endl;

}

