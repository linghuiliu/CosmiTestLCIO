#include "CalorimeterHitSetter.h"
#include "marlin/Global.h"
#include <math.h>
#include <iomanip>

#include "IMPL/LCCollectionVec.h"
#include "IMPL/CalorimeterHitImpl.h"
#include "IMPL/LCFlagImpl.h"
#include "IMPL/LCRelationImpl.h"
#include "EVENT/SimCalorimeterHit.h"
#include "EVENT/LCFloatVec.h"

using namespace lcio;
using namespace marlin;
using namespace std;


CalorimeterHitSetter aCalorimeterHitSetter;


CalorimeterHitSetter::CalorimeterHitSetter() : Processor("CalorimeterHitSetter") {
  
  // Processor description
  _description = "CalorimeterHitSetter applies hit-energy threshold and adds pseudolayer and pseudostave indices to hit collection (encoded in CellID1 akin to encoding of layer and stave indices in CellID0) as well as hit-density weights ";
  

  // Register steering parameters: name, description, class-variable, default value
  registerProcessorParameter("ecalMip", 
			     "Ecal MIP energy (in GeV)",
			     _ecalMip,
			     std::string("0.000150"));
  registerProcessorParameter("hcalMip", 
			     "Hcal MIP energy (in GeV)",
			     _hcalMip,
			     std::string("0.0000004"));
  registerProcessorParameter("ecalMipThreshold", 
			     "Ecal threshold (in MIP units)",
			     _ecalMipThreshold,
			     std::string("0.33333333333333"));
  registerProcessorParameter("hcalMipThreshold", 
			     "Hcal threshold (in MIP units)",
			     _hcalMipThreshold,
			     std::string("0.33333333333333"));

}


void CalorimeterHitSetter::init() { 

  // Print processor parameters
  printParameters();

  // Set number of runs and events to 0
  _nRun = 0;
  _nEvt = 0;
  
  // Get parameters from steering file
  firstRun = Global::parameters->getIntVal("firstRun");
  lastRun = Global::parameters->getIntVal("lastRun");
  firstEventInFirstRun = Global::parameters->getIntVal("firstEventInFirstRun");
  lastEventInLastRun = Global::parameters->getIntVal("lastEventInLastRun");
  printAction = Global::parameters->getIntVal("printAction");
  inputCollections = Global::parameters->getStringVals("inputCollections",inputCollections);
  detectorType = Global::parameters->getStringVal("detectorType");
  ecalLayers = Global::parameters->getIntVal("ecalLayers");
  hcalLayers = Global::parameters->getIntVal("hcalLayers");
  totalLayers = ecalLayers+hcalLayers;
  barrelSymmetry = Global::parameters->getIntVal("barrelSymmetry");
  phi_1 = (Global::parameters->getFloatVal("phi_1"))*acos(-1.)/180.;
  ecalEnergyThreshold = (parameters()->getFloatVal("ecalMipThreshold"))*(parameters()->getFloatVal("ecalMip"));    
  hcalEnergyThreshold = (parameters()->getFloatVal("hcalMipThreshold"))*(parameters()->getFloatVal("hcalMip"));

}

void CalorimeterHitSetter::processRunHeader( LCRunHeader* run) { 

  _nRun++;
} 

void CalorimeterHitSetter::processEvent( LCEvent * evt ) { 

  // Process events in this range
  if(!((evt->getRunNumber()<firstRun && evt->getRunNumber()>lastRun) ||
       (evt->getRunNumber()==firstRun && evt->getEventNumber()<firstEventInFirstRun) ||
       (evt->getRunNumber()==lastRun && evt->getEventNumber()>lastEventInLastRun))) {

  if(printAction) cout << "  - applying hit-energy threshold, evaluating pseudolayer and pseudostave indices and calculating hit-densities...." << endl;

  // Create collections to store:
  // - the hits above the cell-energy threshold
  LCCollectionVec* hitVec = new LCCollectionVec(LCIO::CALORIMETERHIT);
  // - the relation between the hits and the truth information if simulation (runs in parallel with hitVec)
  LCCollectionVec* simHitRelVec = new LCCollectionVec(LCIO::LCRELATION);
  // - the weight assigned to a hit for clustering (runs in parallel with hitVec)
  LCCollectionVec* weightOfHitVec = new LCCollectionVec(LCIO::LCFLOATVEC); 

  // Set some parameters for the hits collection
  StringVec hitTypeNames;
  hitTypeNames.resize(2);
  hitTypeNames[0]="Ecal hit";
  hitTypeNames[1]="Hcal hit";
  hitVec->parameters().setValues("CalorimeterHitTypeNames",hitTypeNames);
  StringVec mipEnergyNames;
  mipEnergyNames.resize(2);
  mipEnergyNames[0]="Ecal Mip energy";
  mipEnergyNames[1]="Hcal Mip energy";
  hitVec->parameters().setValues("CalorimeterMipEnergyNames",mipEnergyNames);
  FloatVec mipEnergyValues;
  mipEnergyValues.resize(2);
  mipEnergyValues[0]=parameters()->getFloatVal("ecalMip");
  mipEnergyValues[1]=parameters()->getFloatVal("hcalMip");
  hitVec->parameters().setValues("CalorimeterMipEnergyValues",mipEnergyValues);
  hitVec->parameters().setValue("CalorimeterBarrelSymmetry",barrelSymmetry);
  hitVec->parameters().setValue("CalorimeterPhi_1",Global::parameters->getFloatVal("phi_1"));
  hitVec->parameters().setValue("CalorimeterDetectorType",detectorType);

  // Set the relation from and to types for the hits
  simHitRelVec->parameters().setValue( "RelationFromType",LCIO::CALORIMETERHIT);
  simHitRelVec->parameters().setValue( "RelationToType",LCIO::SIMCALORIMETERHIT);

  // Retrieve these collections
  LCCollection* distanceToBarrelLayersVec=evt->getCollection("distance_barrellayers");
  LCCollection* distanceToEndcapLayersVec=evt->getCollection("distance_endcaplayers");

  typedef const std::vector<std::string> NameVec;
  NameVec* strVec = evt->getCollectionNames();

  int i, j, k, l;
  double pi=acos(-1.);
  bool OK, isSimulation=false;
  std::string hitType;
  float radius,azimuth1,azimuth2,barrel_endcap;
  float weight=0.;
  float R_layer[2+totalLayers];
  float Z_layer[2+totalLayers];
  float gradient_outside[1+totalLayers];
  float intercept_outside[1+totalLayers];
  float cos_stavecentreangle[3+barrelSymmetry];
  float sin_stavecentreangle[3+barrelSymmetry];
  float cos_staveleadingedgeangle[3+barrelSymmetry];
  float sin_staveleadingedgeangle[3+barrelSymmetry];
  float cos_stavetrailingedgeangle[3+barrelSymmetry];
  float sin_stavetrailingedgeangle[3+barrelSymmetry];

  // Copy the layer positions into local arrays
  for(l=0;l<=1+totalLayers;l++) {
    LCFloatVec* distanceToBarrelLayers = dynamic_cast<LCFloatVec*>(distanceToBarrelLayersVec->getElementAt(l));
    LCFloatVec* distanceToEndcapLayers = dynamic_cast<LCFloatVec*>(distanceToEndcapLayersVec->getElementAt(l));
    R_layer[l]=*distanceToBarrelLayers->begin();
    Z_layer[l]=*distanceToEndcapLayers->begin();
  }

  // Set up some geometrical parameters for use later
  for(k=1;k<=2+barrelSymmetry;k++) {
    cos_stavecentreangle[k]=cos(((k-1)*2*pi/barrelSymmetry)+phi_1);
    sin_stavecentreangle[k]=sin(((k-1)*2*pi/barrelSymmetry)+phi_1);
    cos_staveleadingedgeangle[k]=cos(((2*k-1)*pi/barrelSymmetry)+phi_1);
    sin_staveleadingedgeangle[k]=sin(((2*k-1)*pi/barrelSymmetry)+phi_1);
    cos_stavetrailingedgeangle[k]=cos(((2*k-3)*pi/barrelSymmetry)+phi_1);
    sin_stavetrailingedgeangle[k]=sin(((2*k-3)*pi/barrelSymmetry)+phi_1);
  }
  for(l=0;l<=totalLayers;l++) {
    gradient_outside[l]=(R_layer[l+1]-R_layer[l])/(Z_layer[l+1]-Z_layer[l]);
    intercept_outside[l]=(R_layer[l]*Z_layer[l+1]-Z_layer[l]*R_layer[l+1])/(Z_layer[l+1]-Z_layer[l]);
  }

  // Loop over collections
  for(NameVec::const_iterator name=strVec->begin(); name!=strVec->end(); name++){
    LCCollection* inputHitVec=evt->getCollection(*name);
    string sss=name->c_str();
    // Select those which contain (maybe simulated) calorimeter hits
    if(inputHitVec->getTypeName()==LCIO::SIMCALORIMETERHIT || inputHitVec->getTypeName()==LCIO::CALORIMETERHIT) {
      for(j=0;j<int(inputCollections.size());j++) { 
	if(sss==*(inputCollections.begin()+j)) {
	  // Find out whether they represent Ecal or Hcal hits
	  for(i=0;i<int(sss.size())-3;i++) {
	    if((sss[i]=='e' || sss[i]=='E') &&
	       (sss[i+1]=='c' || sss[i+1]=='C') &&
	       (sss[i+2]=='a' || sss[i+2]=='A') &&
	       (sss[i+3]=='l' || sss[i+3]=='L')) {
	      hitType="ecal";
	      break;
	    }
	    else if((sss[i]=='h' || sss[i]=='H') &&
		    (sss[i+1]=='c' || sss[i+1]=='C') &&
		    (sss[i+2]=='a' || sss[i+2]=='A') &&
		    (sss[i+3]=='l' || sss[i+3]=='L')) {
	      hitType="hcal";
	      break;
	    }
	  }
	  // Temporarily hard-code the DESY prototype model as comprising Ecal hits only 
	  // (will handle this better in a later version of the code)  
	  if(detectorType=="prototype" && sss=="ProtoDesy0205_ProtoSD03") hitType="ecal";
	  // Loop over the hits in this collection...
	  for(i=0;i<inputHitVec->getNumberOfElements();i++) {
	    float energy;
	    const float* pos;
	    int id0;
	    // ...and read in their attributes
	    if(inputHitVec->getTypeName()==LCIO::SIMCALORIMETERHIT) {
	      isSimulation=true;
	      SimCalorimeterHit* inputHit = dynamic_cast<SimCalorimeterHit*>(inputHitVec->getElementAt(i));
	      energy=inputHit->getEnergy();
	      pos=inputHit->getPosition();
	      id0=inputHit->getCellID0();
	    }
	    else {
	      isSimulation=false;
	      CalorimeterHit* inputHit = dynamic_cast<CalorimeterHit*>(inputHitVec->getElementAt(i));
	      energy=inputHit->getEnergy();
	      pos=inputHit->getPosition();
	      id0=inputHit->getCellID0();
	    }
	    // Check whether the energy of the hit is above the appropriate threshold
	    if((hitType=="ecal" && energy>ecalEnergyThreshold) || 
	       (hitType=="hcal" && energy>hcalEnergyThreshold)) {
	      // Create a new hit if so and add it to the new above-threshold hits collection
	      CalorimeterHitImpl* hit = new CalorimeterHitImpl;
	      hitVec->push_back(hit);
	      // Set the hit's position, energy, cellID0 and type
	      hit->setPosition(pos);
	      hit->setEnergy(energy);
	      hit->setCellID0(id0);
	      if(hitType=="ecal") {
		hit->setType(0);
	      }
	      else if(hitType=="hcal") {
		hit->setType(1);
	      }
	      // Add a pointer to the truth information for the hit if this is simulation
	      if(isSimulation) {
		SimCalorimeterHit* inputHit = dynamic_cast<SimCalorimeterHit*>(inputHitVec->getElementAt(i));
		simHitRelVec->addElement(new LCRelationImpl(hit,inputHit));
	      }
	      // Now determine the pseudolayer and pseudostave indices of the hit
	      int pseudolayer=0;
	      int pseudostave=0;
	      // Loop over calorimeter layers
	      for(l=1;l<=totalLayers;l++) {
		// Here for a full detector comprising barrel and endcaps
		if(detectorType=="full") {
		  // Determine whether the z-coordinate permits the hit to be in pseudolayer l 
		  if(fabs(pos[2]) < 0.5*(Z_layer[l]+Z_layer[l+1])) {
		    OK=true;
		    // Loop over barrel pseudostaves
		    for(k=1;k<=barrelSymmetry;k++) {
		      // Determine whether the x- and y-coordinates preclude the hit from being
		      // in pseudolayer l
		      if(OK && 
			 pos[0]*cos_stavecentreangle[k] + pos[1]*sin_stavecentreangle[k] >= 
			 0.5*(R_layer[l]+R_layer[l+1])) {
			OK=false;
		      }
		    }
		    // If the coordinates are within the radial and longitudinal pseudolayer 
		    // boundaries, set the hit's pseudolayer index as the current pseudolayer
		    if(OK) {
		      pseudolayer=l;
		      // Loop over barrel pseudostaves
		      for(k=1;k<=barrelSymmetry;k++) {
			// Formulate equations for leading and trailing azimuthal bounding planes of barrel 
			// pseudostave k 
			azimuth1 = pos[0]*sin_staveleadingedgeangle[k] - pos[1]*cos_staveleadingedgeangle[k];
			if(azimuth1 >= 0) {
			  azimuth2 = pos[0]*sin_stavetrailingedgeangle[k] - pos[1]*cos_stavetrailingedgeangle[k];
			  // Tentatively set the hit's pseudostave index to the current barrel pseudostave
			  // if it lies between these planes (it may be reassigned below if it's actually
			  // in one or other pseudoendcap)
			  if(azimuth2 < 0) {
			    pseudostave=k;
			    // Determine the perpendicular distance of the plane parallel to the radial pseudolayer
			    // that contains the hit 
			    radius = pos[0]*cos_stavecentreangle[k] + pos[1]*sin_stavecentreangle[k];
			    // If this plane or the longitudinal plane containing the hit lies outside layer l, 
			    // formulate the equation for the barrel-endcap overlap region based on the 
			    // locations of layers l and l+1 
			    if(radius >= R_layer[l] || fabs(pos[2]) >= Z_layer[l]) {
			      barrel_endcap = gradient_outside[l]*fabs(pos[2]) + intercept_outside[l];
			    }
			    // Else if this plane or the longitudinal plane containing the hit lies inside layer l, 
			    // formulate the equation for the barrel-endcap overlap region based on the 
			    // locations of layers l-1 and l 
			    else {
			      barrel_endcap = gradient_outside[l-1]*fabs(pos[2]) + intercept_outside[l-1];
			    }
			    // Reset hit's pseudostave index if it's really in the LH pseudoendcap
			    if(pos[2] < 0. && radius <= barrel_endcap) {
			      pseudostave=barrelSymmetry+1;
			    }
			    // Reset hit's pseudostave index if it's really in the RH pseudoendcap
			    if(pos[2] > 0. && radius <= barrel_endcap) {
			      pseudostave=barrelSymmetry+2;
			    }
			    // Set the hit's CellID1, with the pseudolayer and pseudostave indices encoded in the 
			    // same way as the layer and stave indices are encoded in CellID0, then step out of 
			    // the barrel pseudostave loop since the pseudostave index has been assigned
			    hit->setCellID1(16777216*(pseudolayer-1)+8*(pseudostave-1));
			    break;
			  }
			}
		      }
		      // Step out of the pseudolayer loop since the pseudolayer index has been assigned
		      break;
		    }
		  }
		}
		// Here for a prototype comprising a single endcap with layers aligned perpendicularly to 
		// the +z direction
		else if(detectorType=="prototype") {
		  // Determine whether the z-coordinate permits the hit to be in pseudolayer l 
		  if(pos[2] < 0.5*(Z_layer[l]+Z_layer[l+1])) {
		    // Set the hit's pseudolayer index to the current pseudolayer and the pseudostave index
		    // to 1 (since it's the only pseudostave!)
		    pseudolayer=l;
		    pseudostave=1;
		    // Set the hit's CellID1, with the pseudolayer and pseudostave indices encoded in the 
		    // same way as the layer and stave indices are encoded in CellID0, then step out of 
		    // the barrel pseudolayer loop since the pseudolayer index has been assigned
		    hit->setCellID1(16777216*(pseudolayer-1)+8*(pseudostave-1));
		    break;
		  }
		}
		// Print a warning message if any hits have not been assigned a pseudolayer and pseudostave index 
		// (happens if hit falls outside bounds of calorimeters as specified in CalorimeterConfigurer.cc)
		if(l==totalLayers && pseudolayer==0) {
		  cout << "    ## WARNING: hit at ("
		       <<  setiosflags(ios::fixed) << setprecision(2) << pos[0] << ","
		       <<  setiosflags(ios::fixed) << setprecision(2) << pos[1] << ","
		       <<  setiosflags(ios::fixed) << setprecision(2) << pos[2]
		       << ") mm beyond outermost layer specified in CalorimeterConfigurer.cc! ##" << endl;
		}
	      }
	    }
	  }
	}
      }
    }
  }

  // Loop over the hits above threshold
  for(i=0;i<hitVec->getNumberOfElements();i++){
    CalorimeterHit* hit1 = dynamic_cast<CalorimeterHit*>(hitVec->getElementAt(i));
    int pseudolayer1=hit1->getCellID1()/16777216;
    const float* pos1=hit1->getPosition();
    // Calculate the hit's weight as the hit density, where density = gravitational-like potential 
    // to other hits with the same pseudolayer index, or zero if it's the only hit in the pseudolayer
    weight=0.;
    for(k=0;k<hitVec->getNumberOfElements();k++){
      CalorimeterHit* hit2 = dynamic_cast<CalorimeterHit*>(hitVec->getElementAt(k));
      int pseudolayer2=hit2->getCellID1()/16777216;
      const float* pos2=hit2->getPosition();
      if(pseudolayer1==pseudolayer2 && i!=k) {
	weight+=1./fabs(sqrt((pow(pos1[0]-pos2[0],2))+
			     (pow(pos1[1]-pos2[1],2))+
			     (pow(pos1[2]-pos2[2],2))));
      }
    }
    // Set the hit's weight and add it to the collection
    LCFloatVec* weightOfHit = new LCFloatVec;
    weightOfHit->push_back(weight);
    weightOfHitVec->push_back(weightOfHit);
  }

  // Store the hit positions and cellID1s when the hits collection is written to the LCIO output file
  LCFlagImpl rchflag(0);
  rchflag.setBit(LCIO::RCHBIT_LONG);
  rchflag.setBit(LCIO::RCHBIT_ID1);
  hitVec->setFlag(rchflag.getFlag());

  // Store the collections
  evt->addCollection(hitVec,"CalorimeterHits");
  if(isSimulation) {
    evt->addCollection(simHitRelVec,"CalorimeterHitRelationsToSimCalorimeterHits");
  }
  evt->addCollection(weightOfHitVec,"CalorimeterHitWeights");

  // Don't write these to the LCIO output file
  weightOfHitVec->setTransient();

  if(printAction) {
    if(hitVec->getNumberOfElements()==0) {
      cout << "    --> No cells found above energy threshold!" << endl;
      cout << "        Check threshold cuts in steering file" << endl;
      cout << "        (e.g. are these set in GeV, not MeV, etc.)" << endl;
    }
    else cout << "    --> OK" << endl;
  }
  }
  
  _nEvt ++;
}

void CalorimeterHitSetter::check( LCEvent * evt ) { 
  // nothing to check here - could be used to fill checkplots in reconstruction processor
}

void CalorimeterHitSetter::end(){ 
  
  std::cout << "CalorimeterHitSetter::end()  " << name() 
	    << " processed " << _nEvt << " events in " << _nRun << " runs "
	    << std::endl;

}

