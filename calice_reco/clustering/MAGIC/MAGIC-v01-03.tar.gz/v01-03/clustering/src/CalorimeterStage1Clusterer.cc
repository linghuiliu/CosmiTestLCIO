#include "CalorimeterStage1Clusterer.h"
#include "marlin/Global.h"
#include <math.h>

#include "IMPL/LCCollectionVec.h"
#include "IMPL/CalorimeterHitImpl.h"
#include "IMPL/ClusterImpl.h"
#include "IMPL/LCFlagImpl.h"
#include "EVENT/LCIntVec.h"
#include "EVENT/LCFloatVec.h"

using namespace lcio;
using namespace marlin;
using namespace std;


CalorimeterStage1Clusterer aCalorimeterStage1Clusterer;


CalorimeterStage1Clusterer::CalorimeterStage1Clusterer() : Processor("CalorimeterStage1Clusterer") {
  
  // Processor description
  _description = "CalorimeterStage1Clusterer performs coarse cluster reconstruction";
  

  // Register steering parameters: name, description, class-variable, default value
  registerProcessorParameter("layersToTrackBackMax_ecal", 
			     "number of layers to track back for cluster continuation in Ecal (effective range [1,ecalLayers-1])",
			     _layersToTrackBackMax_ecal,
			     std::string("3")); 
  registerProcessorParameter("layersToTrackBackMax_hcal", 
			     "number of layers to track back for cluster continuation in Hcal (effective range [1,ecalLayers+hcalLayers]-1)",
			     _layersToTrackBackMax_hcal,
			     std::string("3")); 
  registerProcessorParameter("distMax_ecal", 
			     "distance cut in Ecal (in mm)",
			     _distMax_ecal,
			     std::string("20.0")); 
  registerProcessorParameter("distMax_hcal", 
			     "distance cut in Hcal (in mm)",
			     _distMax_hcal,
			     std::string("30.0")); 
  registerProcessorParameter("proxSeedMax_ecal", 
			     "maximum cluster-seed radius in Ecal (in mm)",
			     _proxSeedMax_ecal,
			     std::string("14.0"));
  registerProcessorParameter("proxSeedMax_hcal", 
			     "maximum cluster-seed radius in Hcal (in mm)",
			     _proxSeedMax_hcal,
			     std::string("50.0"));

}


void CalorimeterStage1Clusterer::init() { 

  // Print processor parameters
  printParameters();

  // Set number of runs and events to 0
  _nRun = 0;
  _nEvt = 0;
  
  // Get parameters from steering file
  firstRun = Global::parameters->getIntVal("firstRun");
  lastRun = Global::parameters->getIntVal("lastRun");
  firstEventInFirstRun = Global::parameters->getIntVal("firstEventInFirstRun");
  lastEventInLastRun = Global::parameters->getIntVal("lastEventInLastRun");
  printAction = Global::parameters->getIntVal("printAction");
  detectorType = Global::parameters->getStringVal("detectorType");
  iPx = Global::parameters->getFloatVal("iPx");
  iPy = Global::parameters->getFloatVal("iPy");
  iPz = Global::parameters->getFloatVal("iPz");
  ecalLayers = Global::parameters->getIntVal("ecalLayers");
  hcalLayers = Global::parameters->getIntVal("hcalLayers");
  totalLayers = ecalLayers+hcalLayers;
  barrelSymmetry = Global::parameters->getIntVal("barrelSymmetry");
  phi_1 = (Global::parameters->getFloatVal("phi_1"))*acos(-1.)/180.;
  layersToTrackBackMax_ecal = parameters()->getIntVal("layersToTrackBackMax_ecal");
  layersToTrackBackMax_hcal = parameters()->getIntVal("layersToTrackBackMax_hcal");
  distMax_ecal = parameters()->getFloatVal("distMax_ecal");
  distMax_hcal = parameters()->getFloatVal("distMax_hcal");
  proxSeedMax_ecal = parameters()->getFloatVal("proxSeedMax_ecal");
  proxSeedMax_hcal = parameters()->getFloatVal("proxSeedMax_hcal");

}

void CalorimeterStage1Clusterer::processRunHeader( LCRunHeader* run) { 

  _nRun++;
} 

void CalorimeterStage1Clusterer::processEvent( LCEvent * evt ) { 

  // Process events in this range
  if(!((evt->getRunNumber()<firstRun && evt->getRunNumber()>lastRun) ||
       (evt->getRunNumber()==firstRun && evt->getEventNumber()<firstEventInFirstRun) ||
       (evt->getRunNumber()==lastRun && evt->getEventNumber()>lastEventInLastRun))) {

  if(printAction) cout << "  - performing coarse cluster reconstruction...." << endl;

  // Create collections to store:
  // - the stage 1 clusters
  LCCollectionVec* cluster1Vec = new LCCollectionVec(LCIO::CLUSTER);
  // - additional attributes of the stage 1 clusters (runs in parallel with cluster1Vec)
  LCCollectionVec* cluster1XtraVec = new LCCollectionVec(LCIO::CLUSTER);
  // - the seed coordinates of stage 1 clusters (runs in parallel with cluster1Vec)
  LCCollectionVec* seedCoordsOfCluster1Vec = new LCCollectionVec(LCIO::LCFLOATVEC);
  // - the seed pseudolayer of stage 1 clusters (runs in parallel with cluster1Vec)
  LCCollectionVec* seedPseudolayerOfCluster1Vec = new LCCollectionVec(LCIO::LCINTVEC);
  // - the terminating pseudolayer of stage 1 clusters (runs in parallel with cluster1Vec)
  LCCollectionVec* lastPseudolayerOfCluster1Vec = new LCCollectionVec(LCIO::LCINTVEC);
  // - the direction cosines of a stage 1 cluster at the site of a hit (runs in parallel with hitVec)
  LCCollectionVec* dirCosOfHitVec = new LCCollectionVec(LCIO::CALORIMETERHIT);
  // - the weight-ordered hit ids in stage 1 cluster seeds
  LCCollectionVec* seedHitVec = new LCCollectionVec(LCIO::LCINTVEC);

  // Retrieve these collections
  LCCollection* distanceToBarrelLayersVec=evt->getCollection("distance_barrellayers");
  LCCollection* distanceToEndcapLayersVec=evt->getCollection("distance_endcaplayers");
  LCCollection* hitVec=evt->getCollection("CalorimeterHits");
  LCCollection* weightOfHitVec=evt->getCollection("CalorimeterHitWeights");

  int i, j, k, l, p, q, u;
  double pi=acos(-1.);
  float pos[3],dir[3];
  int pseudolayer_firststore=1+totalLayers;
  float delta_r_perp=0.;
  float dir_cos_perp=0.;
  float sum_wx, sum_wy, sum_wz, sum_w;
  float whit, wmax;
  int seedHit_count;
  bool cluster_presence, OK;
  float xcow, ycow, zcow;
  int layersToTrackBackMax;
  float proxSeedMax;
  float dist, dist_min, dist_max;
  float R_layer[2+totalLayers];
  float Z_layer[2+totalLayers];
  float cos_stavecentreangle[3+barrelSymmetry];
  float sin_stavecentreangle[3+barrelSymmetry];
  int nCalHits=hitVec->getNumberOfElements();
  int merging_cluster[nCalHits];
  int seedHit_use[nCalHits];

  // Copy the layer positions into local arrays and create a new vector to hold seed hits for each pseudolayer
  for(l=0;l<=1+totalLayers;l++) {
    LCFloatVec* distanceToBarrelLayers = dynamic_cast<LCFloatVec*>(distanceToBarrelLayersVec->getElementAt(l));
    LCFloatVec* distanceToEndcapLayers = dynamic_cast<LCFloatVec*>(distanceToEndcapLayersVec->getElementAt(l));
    R_layer[l]=*distanceToBarrelLayers->begin();
    Z_layer[l]=*distanceToEndcapLayers->begin();
    LCIntVec* seedHit = new LCIntVec;
    seedHitVec->push_back(seedHit);
  }

  // Set up some geometrical parameters for use later
  for(p=1;p<=2+barrelSymmetry;p++) {
    cos_stavecentreangle[p]=cos(((p-1)*2*pi/barrelSymmetry)+phi_1);
    sin_stavecentreangle[p]=sin(((p-1)*2*pi/barrelSymmetry)+phi_1);
  }

  // Loop over the hits
  for(i=0;i<hitVec->getNumberOfElements();i++){
    // Create a new vector to hold the direction cosines of each hit in parallel with the hits collection
     CalorimeterHitImpl* dirCosOfHit = new CalorimeterHitImpl;
     dirCosOfHitVec->push_back(dirCosOfHit);
  }

  // Find the first pseudolayer containing a hit
  for(l=1;l<=totalLayers;l++) {
    for(i=0;i<hitVec->getNumberOfElements();i++){
      CalorimeterHit* hit = dynamic_cast<CalorimeterHit*>(hitVec->getElementAt(i));
      int pseudolayer=1+hit->getCellID1()/16777216;
      if(l==pseudolayer && l<pseudolayer_firststore) {
	pseudolayer_firststore=l;
      }
    }
  }

  // Loop over pseudolayers
  for(l=pseudolayer_firststore;l<=totalLayers;l++) {
    if(l<=ecalLayers) {
      layersToTrackBackMax=layersToTrackBackMax_ecal;
    }
    else {
      layersToTrackBackMax=layersToTrackBackMax_hcal;
    }
    // Loop over the hits...
    for(i=0;i<hitVec->getNumberOfElements();i++) {
      CalorimeterHit* hit1 = dynamic_cast<CalorimeterHit*>(hitVec->getElementAt(i));
      int pseudolayer1=1+hit1->getCellID1()/16777216;
      // ...in the current pseudolayer
      if(pseudolayer1==l) {
	merging_cluster[i]=0;
	if(hit1->getType()==0) {
	  dist_max=distMax_ecal;
	}
	else {
	  dist_max=distMax_hcal;
	}
	// Initialise the minimum projected distance to the minimum impermissible distance
	dist_min=dist_max;
	const float* pos1=hit1->getPosition();
	// Initialise the direction cosines of the hit to its displacement from the IP
	float dir1[3]={hit1->getPosition()[0]-iPx,
		       hit1->getPosition()[1]-iPy,
		       hit1->getPosition()[2]-iPz};
	// Loop over previous pseudolayers in reverse order...
	for(q=1;q<=layersToTrackBackMax && q<=l-pseudolayer_firststore;q++) {
	  // ...until the hit has been assigned to a cluster continuing from a previous pseudolayer
	  if(merging_cluster[i]!=0) break;
	  else {
	    wmax=0.;
	    // Loop over clusters of hits from the earlier pseudolayer...
	    for(j=0;j<cluster1Vec->getNumberOfElements();j++) {
	      Cluster* cluster1 = dynamic_cast<Cluster*>(cluster1Vec->getElementAt(j));
	      Cluster* cluster1Xtra = dynamic_cast<Cluster*>(cluster1XtraVec->getElementAt(j));
	      //...and consider hits...
	      for(u=0;u<int(cluster1->getCalorimeterHits().size());u++) {
		const float* pos2=cluster1->getCalorimeterHits()[u]->getPosition();
		const float* dir2=cluster1Xtra->getCalorimeterHits()[u]->getPosition();
		int pseudolayer2=1+cluster1->getCalorimeterHits()[u]->getCellID1()/16777216;
		// ...in the current particular previous pseudolayer
		if(pseudolayer2==l-q) {
		  OK=false;
		  // Here for the full detector comprising barrel and endcaps
		  if(detectorType=="full") {
		    int pseudostave1=1+(hit1->getCellID1()%16777216)/8;
		    int pseudostave2=1+(cluster1->getCalorimeterHits()[u]->getCellID1()%16777216)/8;
		    // Create geometrical constructs if the hit in the previous pseudolayer:
		    // - is in the pseudobarrel (links permitted only to hits in pseudoendcaps and adjacent 
		    //   pseudobarrel pseudostaves)
		    if(pseudostave2<=barrelSymmetry && (pseudostave1>barrelSymmetry || 
					      (pseudostave1<=barrelSymmetry && 
					       (abs(pseudostave2-pseudostave1)<=1 || 
						abs(pseudostave2-pseudostave1)==barrelSymmetry-1)))) {
		      dir_cos_perp=dir2[0]*cos_stavecentreangle[pseudostave2] + dir2[1]*sin_stavecentreangle[pseudostave2];
		      if(dir_cos_perp>0.) {
			OK=true;
			delta_r_perp=(pos1[0]-pos2[0])*cos_stavecentreangle[pseudostave2]+
			  (pos1[1]-pos2[1])*sin_stavecentreangle[pseudostave2];
		      }
		    }
		    // - is in the LH pseudoendcap (z<0) (links permitted to all pseudostaves except the
		    //   RH pseudoendcap)
		    else if(pseudostave2==barrelSymmetry+1 && pseudostave1!=barrelSymmetry+2) {
		      dir_cos_perp=-dir2[2];
		      if(dir_cos_perp>0.) {
			OK=true;
			delta_r_perp=-pos1[2]+pos2[2];
		      }
		    }
		    // - is in the RH pseudoendcap (z>0) (links permitted to all pseudostaves except the
		    //   LH pseudoendcap)
		    else if(pseudostave2==barrelSymmetry+2 && pseudostave1!=barrelSymmetry+1) {
		      dir_cos_perp=+dir2[2];
		      if(dir_cos_perp>0.) {
			OK=true;
			delta_r_perp=+pos1[2]-pos2[2];
		      }
		    }
		  }
		  // Here for a prototype comprising a single endcap with layers aligned perpendicularly to 
		  // the +z direction
		  else if(detectorType=="prototype") {
		    // Create geometrical constructs
		    dir_cos_perp=+dir2[2];
		    if(dir_cos_perp>0.) {
		      OK=true;
		      delta_r_perp=+pos1[2]-pos2[2];
		    }
		  }
		  // Accept only forward propagation through pseudolayers
		  if(OK && delta_r_perp > 0.) {
		    // Calculate the expected distance between the hit in the current pseudolayer and the projected point
		    // of intersection of the clustered hit from the previous pseudolayer...
		    dist=
		      fabs(sqrt(pow(((pos1[0]-pos2[0]))-(dir2[0]*delta_r_perp/(dir_cos_perp)),2)+
				pow(((pos1[1]-pos2[1]))-(dir2[1]*delta_r_perp/(dir_cos_perp)),2)+
				pow(((pos1[2]-pos2[2]))-(dir2[2]*delta_r_perp/(dir_cos_perp)),2)));
		    // ...and minimise w.r.t. all hits in the previous pseudolayer, subject to dist < dist_max; assign 
		    // the hit in the current pseudolayer to the cluster to which the hit in the previous pseudolayer
		    // that results in the minimum already belongs (in the event of a tie, assign it to the cluster
		    // containing the linking hit of higher/highest weight) 
		    if(dist<dist_max && (dist<dist_min || (dist==dist_min && cluster1Xtra->getHitContributions()[u]>wmax))) {
		      dist_min=dist;
		      wmax=cluster1Xtra->getHitContributions()[u];
		      merging_cluster[i]=j+1;
		      // If it's in the pseudoHcal, calculate the direction cosines of the clustered hit as its displacement from
		      // the hit to which it is linked
		      if(l>ecalLayers) {
			dir1[0] = pos1[0]-pos2[0];
			dir1[1] = pos1[1]-pos2[1];
			dir1[2] = pos1[2]-pos2[2];
		      }
		    }
		  }
		}
	      }
	    }
	  }
	}
	// If it's in the pseudoHcal, set the hit's direction cosines
	if(l>ecalLayers) {
	  CalorimeterHitImpl* dirCosOfHit1 = dynamic_cast<CalorimeterHitImpl*>(dirCosOfHitVec->getElementAt(i));
	  dirCosOfHit1->setPosition(dir1);
	}
	// If the hit has been associated to a cluster continuing from an earlier pseudolayer, add the hit together with 
	// its energy to this cluster, and add the direction cosines of the hit together with its weight to the cluster
	// attributes
	if(merging_cluster[i]>0) {
	  ClusterImpl* cluster1 = dynamic_cast<ClusterImpl*>(cluster1Vec->getElementAt(merging_cluster[i]-1));
	  ClusterImpl* cluster1Xtra = dynamic_cast<ClusterImpl*>(cluster1XtraVec->getElementAt(merging_cluster[i]-1));
	  cluster1->addHit(hit1,hit1->getEnergy());
	  CalorimeterHitImpl* dirCosOfHit1 = dynamic_cast<CalorimeterHitImpl*>(dirCosOfHitVec->getElementAt(i));
	  LCFloatVec* weightOfHit1 = dynamic_cast<LCFloatVec*>(weightOfHitVec->getElementAt(i));
	  cluster1Xtra->addHit(dirCosOfHit1,*weightOfHit1->begin());
	}
      }
    } 
    
    // Loop over the hits..
    LCIntVec* seedHit = dynamic_cast<LCIntVec*>(seedHitVec->getElementAt(l));
    seedHit_count=0;
    wmax=-1.;
    for(i=0;i<hitVec->getNumberOfElements();i++) {
      CalorimeterHit* hit = dynamic_cast<CalorimeterHit*>(hitVec->getElementAt(i));
      // ...in the current pseudolayer... 
      int pseudolayer=1+hit->getCellID1()/16777216;
      if(pseudolayer==l) {
	seedHit_use[i]=0;
	LCFloatVec* weightOfHit = dynamic_cast<LCFloatVec*>(weightOfHitVec->getElementAt(i));
	whit=*weightOfHit->begin();
	// ...that haven't been assigned to a cluster continuing from a previous pseudolayer...
	if(merging_cluster[i]==0) {
	  seedHit_count++;
	  // ...and of these find the weight of the hit with the highest weight
	  if(whit > wmax) {
	    wmax=whit;
	  }
	}
      }
    }
    // Loop over the hits..
    for(i=0;i<hitVec->getNumberOfElements();i++) {
      CalorimeterHit* hit = dynamic_cast<CalorimeterHit*>(hitVec->getElementAt(i));
      // ...in the current pseudolayer...
      int pseudolayer=1+hit->getCellID1()/16777216;
      if(pseudolayer==l) {
	LCFloatVec* weightOfHit = dynamic_cast<LCFloatVec*>(weightOfHitVec->getElementAt(i));
	whit=*weightOfHit->begin();
	// ...that that haven't been assigned to a cluster continuing from a previous pseudolayer, and
	// record the hit id of the hit(s) of highest weight 
	if(merging_cluster[i]==0 && whit==wmax) {
	  seedHit->push_back(i);
	  seedHit_use[i]=1;
	}
      }
    }
    // Repeat to rank by weight all hits in the current pseudolayer that haven't been assigned to a 
    // cluster continuing from a previous pseudolayer
    do {
      wmax=-1.;
      for(i=0;i<hitVec->getNumberOfElements();i++) {
	CalorimeterHit* hit = dynamic_cast<CalorimeterHit*>(hitVec->getElementAt(i));
	int pseudolayer=1+hit->getCellID1()/16777216;
	if(pseudolayer==l) {
	  LCFloatVec* weightOfHit = dynamic_cast<LCFloatVec*>(weightOfHitVec->getElementAt(i));
	  whit=*weightOfHit->begin();
	  if(merging_cluster[i]==0 && seedHit_use[i]==0) {
	    if(whit > wmax) {
	      wmax=whit;
	    }
	  }
	}
      }
      for(i=0;i<hitVec->getNumberOfElements();i++) {
	CalorimeterHit* hit = dynamic_cast<CalorimeterHit*>(hitVec->getElementAt(i));
	int pseudolayer=1+hit->getCellID1()/16777216;
	if(pseudolayer==l) {
	  LCFloatVec* weightOfHit = dynamic_cast<LCFloatVec*>(weightOfHitVec->getElementAt(i));
	  whit=*weightOfHit->begin();
	  if(merging_cluster[i]==0 && seedHit_use[i]==0 && whit==wmax) {
	    seedHit->push_back(i);
	    seedHit_use[i]=1;
	  }
	}
      }
    }
    while(int(seedHit->size())<seedHit_count);
  
    // Loop over the hits in the current pseudolayer that haven't yet been assigned to a cluster 
    // in weight order (starting with the hit of highest weight)
    for(i=0;i<int(seedHit->size());i++) {
      if(merging_cluster[*(seedHit->begin()+i)]==0) {
	CalorimeterHit* hit1 = dynamic_cast<CalorimeterHit*>(hitVec->getElementAt(*(seedHit->begin()+i)));
	const float* pos1=hit1->getPosition();
	if(hit1->getType()==0) {
	  proxSeedMax=proxSeedMax_ecal;
	}
	else {
	  proxSeedMax=proxSeedMax_hcal;
	}
	// Create a new cluster and new instances of other cluster attributes and add each to 
	// their respective collections
	ClusterImpl* cluster1 = new ClusterImpl;
	ClusterImpl* cluster1Xtra = new ClusterImpl;
	LCFloatVec* seedCoordsOfCluster1 = new LCFloatVec;
	LCIntVec* seedPseudolayerOfCluster = new LCIntVec;
	LCIntVec* lastPseudolayerOfCluster = new LCIntVec;
	cluster1Vec->push_back(cluster1);
	cluster1XtraVec->push_back(cluster1Xtra);
	seedCoordsOfCluster1Vec->push_back(seedCoordsOfCluster1);
	seedPseudolayerOfCluster1Vec->push_back(seedPseudolayerOfCluster);
	lastPseudolayerOfCluster1Vec->push_back(lastPseudolayerOfCluster);
	// Set the pseudolayer of the cluster seed to the current pseudolayer
	seedPseudolayerOfCluster->push_back(l);
	// Initialise the terminating pseudolayer of the cluster to zero
	lastPseudolayerOfCluster->push_back(0);
	// Loop over the hits in the current pseudolayer of equal or lower weight that haven't yet been assigned to a
	// cluster in weight order (starting with the hit of highest weight)
	for(j=i;j<int(seedHit->size());j++) {
	  if(merging_cluster[*(seedHit->begin()+j)]==0) {
	    CalorimeterHit* hit2 = dynamic_cast<CalorimeterHit*>(hitVec->getElementAt(*(seedHit->begin()+j)));
	    const float* pos2=hit2->getPosition();
	    // Group those lying within the proximity cut, proxSeedMax, of the highest-weighted, yet-to-be-assigned
	    // hit into the same cluster seed
	    if(1+hit2->getCellID1()/16777216==l &&
	       fabs(sqrt(pow(pos1[0]-pos2[0],2)+
			 pow(pos1[1]-pos2[1],2)+
			 pow(pos1[2]-pos2[2],2))) < proxSeedMax) {
	      // If the hit has been associated to this cluster seed, add the hit together with its energy to this 
	      // cluster, and add the direction cosines of the hit together with its weight to the cluster attributes
	      cluster1->addHit(hit2,hit2->getEnergy());
	      CalorimeterHit* dirCosOfHit2 = dynamic_cast<CalorimeterHit*>(dirCosOfHitVec->getElementAt(*(seedHit->begin()+j)));
	      LCFloatVec* weightOfHit2 = dynamic_cast<LCFloatVec*>(weightOfHitVec->getElementAt(*(seedHit->begin()+j)));
	      cluster1Xtra->addHit(dirCosOfHit2,*weightOfHit2->begin());
	      merging_cluster[*(seedHit->begin()+j)]=cluster1Vec->getNumberOfElements();
	    }
	  }
	}
      }
    }
    // With all hits in the current pseudolayer now assigned to clusters, loop over the clusters
    for(k=1;k<=cluster1Vec->getNumberOfElements();k++) {
      Cluster* cluster1 = dynamic_cast<Cluster*>(cluster1Vec->getElementAt(k-1));
      ClusterImpl* cluster1Xtra = dynamic_cast<ClusterImpl*>(cluster1XtraVec->getElementAt(k-1));
      LCFloatVec* seedCoordsOfCluster1 = dynamic_cast<LCFloatVec*>(seedCoordsOfCluster1Vec->getElementAt(k-1));
      LCIntVec* seedPseudolayerOfCluster = dynamic_cast<LCIntVec*>(seedPseudolayerOfCluster1Vec->getElementAt(k-1));
      LCIntVec* lastPseudolayerOfCluster = dynamic_cast<LCIntVec*>(lastPseudolayerOfCluster1Vec->getElementAt(k-1));
      sum_wx=0;
      sum_wy=0;
      sum_wz=0;
      sum_w=0;
      cluster_presence=false;
      // Loop over the hits...
      for(i=0;i<int(cluster1->getCalorimeterHits().size());i++) {
	const float* pos=cluster1->getCalorimeterHits()[i]->getPosition();
	float weight=cluster1Xtra->getHitContributions()[i];
	int pseudolayer=1+cluster1->getCalorimeterHits()[i]->getCellID1()/16777216;
	// ...in the current pseudolayer that belong to the current cluster
	if(pseudolayer==l) {
	  // Accumulate the weighted sum of coordinates of these hits
	  if(cluster1Xtra->getHitContributions()[i]==0.) {
	    sum_wx=pos[0];
	    sum_wy=pos[1];
	    sum_wz=pos[2];
	    sum_w=1;
	  }
	  else {
	    sum_wx+=weight*pos[0];
	    sum_wy+=weight*pos[1];
	    sum_wz+=weight*pos[2];
	    sum_w+=weight;
	  }
	  cluster_presence=true;
	}
      }
      // If the current cluster contains hits in the current pseudolayer and that pseudolayer is in pseudoEcal,
      // calculate the coordinates of the weighted centre of these hits 
      if(cluster_presence && l<=ecalLayers) {
	xcow=sum_wx/sum_w;
	ycow=sum_wy/sum_w;
	zcow=sum_wz/sum_w;
	OK=true;
	// Loop over the hits..
	for(i=0;i<hitVec->getNumberOfElements();i++) {
	  if(merging_cluster[i]==k) {
	    CalorimeterHit* hit = dynamic_cast<CalorimeterHit*>(hitVec->getElementAt(i));
	    // ...in the current pseudolayer that belong to the current cluster 
	    int pseudolayer=1+hit->getCellID1()/16777216;
	    if(pseudolayer==l) {
	      // If the cluster is continuing from a previous pseudolayer, calculate direction cosines for this 
	      // pseudoEcal hit as the displacement of its cluster's weighted centre in the current pseudolayer 
	      // from its cluster's weighted centre in the seed pseudolayer
	      if(*seedPseudolayerOfCluster->begin()<l) {
		dir[0] = xcow-(*(seedCoordsOfCluster1->begin()+0));
		dir[1] = ycow-(*(seedCoordsOfCluster1->begin()+1));
		dir[2] = zcow-(*(seedCoordsOfCluster1->begin()+2));
	      }
	      // Else, if the cluster is seeded in this pseudolayer, calculate direction cosines for this pseudoEcal
	      // hit as the displacement of its cluster's weighted centre in the current pseudolayer from the IP
	      else {
		dir[0] = xcow-iPx;
		dir[1] = ycow-iPy;
		dir[2] = zcow-iPz;
		if(OK) {
		  // Set the weighted centre of the pseudoEcal-seeded cluster
		  pos[0]=xcow;
		  pos[1]=ycow;
		  pos[2]=zcow;
		  for(j=0;j<=2;j++) {
		    seedCoordsOfCluster1->push_back(pos[j]);
		  }
		  OK=false;
		}
	      }	 
	      // Set the pseudoEcal hit's direction cosines    
	      CalorimeterHitImpl* dirCosOfHit = dynamic_cast<CalorimeterHitImpl*>(dirCosOfHitVec->getElementAt(i));
	      dirCosOfHit->setPosition(dir);
	    }
	  }
	}
      }
      // If the current cluster contains hits in the current pseudolayer, update its terminating pseudolayer to 
      // the current pseudolayer
      if(cluster_presence) {
	lastPseudolayerOfCluster->pop_back();
	lastPseudolayerOfCluster->push_back(l);
      }
    }
  }

  // Store the cluster hits when the clusters collection is written to the LCIO output file
  LCFlagImpl chflag(0);
  chflag.setBit(LCIO::CLBIT_HITS);
  cluster1Vec->setFlag(chflag.getFlag());

  //  Store the collections
  evt->addCollection(cluster1Vec,"CalorimeterStage1Clusters");
  evt->addCollection(cluster1XtraVec,"CalorimeterStage1ClustersXtra");
  evt->addCollection(seedPseudolayerOfCluster1Vec,"CalorimeterStage1ClusterSeedPseudolayers");
  evt->addCollection(lastPseudolayerOfCluster1Vec,"CalorimeterStage1ClusterLastPseudolayers");

  // Don't write these to the LCIO output file
  cluster1XtraVec->setTransient();
  seedPseudolayerOfCluster1Vec->setTransient();
  lastPseudolayerOfCluster1Vec->setTransient();

  if(printAction) cout << "    --> OK" << endl;
  }
  
  _nEvt ++;
}

void CalorimeterStage1Clusterer::check( LCEvent * evt ) { 
  // nothing to check here - could be used to fill checkplots in reconstruction processor
}

void CalorimeterStage1Clusterer::end(){ 
  
  std::cout << "CalorimeterStage1Clusterer::end()  " << name() 
	    << " processed " << _nEvt << " events in " << _nRun << " runs "
	    << std::endl;

}

