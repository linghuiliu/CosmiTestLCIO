#include "CalorimeterStage2Clusterer.h"
#include "marlin/Global.h"
#include <math.h>

#include "IMPL/LCCollectionVec.h"
#include "IMPL/ClusterImpl.h"
#include "IMPL/LCFlagImpl.h"
#include "EVENT/LCIntVec.h"
#include "EVENT/LCFloatVec.h"

using namespace lcio;
using namespace marlin;
using namespace std;


CalorimeterStage2Clusterer aCalorimeterStage2Clusterer;


CalorimeterStage2Clusterer::CalorimeterStage2Clusterer() : Processor("CalorimeterStage2Clusterer") {
  
  // Processor description
  _description = "CalorimeterStage2Clusterer recovers broken mip tracks";
  

  // Register steering parameters: name, description, class-variable, default value

  registerProcessorParameter("clusterSizeMin", 
			     "minimum cluster size for consideration as a mip track",
			     _clusterSizeMin,
			     std::string("5"));
  registerProcessorParameter("hitsPerLayerMax", 
			     "maximum number of hits per layer for consideration as a mip track",
			     _hitsPerLayerMax,
			     std::string("2.0"));
  registerProcessorParameter("layersToTrackBackMax_ecal", 
			     "proximity cut for cluster merging in Ecal (in mm)",
			     _layersToTrackBackMax_ecal,
			     std::string("5")); 
  registerProcessorParameter("layersToTrackBackMax_hcal", 
			     "proximity cut for cluster merging in Hcal (in mm)",
			     _layersToTrackBackMax_hcal,
			     std::string("5")); 
  registerProcessorParameter("distMax_ecal", 
			     "distance cut for cluster merging in Ecal (in mm)",
			     _distMax_ecal,
			     std::string("30.0"));
  registerProcessorParameter("distMax_hcal", 
			     "distance cut for cluster merging in Hcal (in mm)",
			     _distMax_hcal,
			     std::string("150.0"));

}


void CalorimeterStage2Clusterer::init() { 

  // Print processor parameters
  printParameters();

  // Set number of runs and events to 0
  _nRun = 0;
  _nEvt = 0;
  
  // Get parameters from steering file
  firstRun = Global::parameters->getIntVal("firstRun");
  lastRun = Global::parameters->getIntVal("lastRun");
  firstEventInFirstRun = Global::parameters->getIntVal("firstEventInFirstRun");
  lastEventInLastRun = Global::parameters->getIntVal("lastEventInLastRun");
  printAction = Global::parameters->getIntVal("printAction");
  detectorType = Global::parameters->getStringVal("detectorType");
  ecalLayers = Global::parameters->getIntVal("ecalLayers");
  hcalLayers = Global::parameters->getIntVal("hcalLayers");
  totalLayers = ecalLayers+hcalLayers;
  barrelSymmetry = Global::parameters->getIntVal("barrelSymmetry");
  phi_1 = (Global::parameters->getFloatVal("phi_1"))*acos(-1.)/180.;
  clusterSizeMin = parameters()->getIntVal("clusterSizeMin");
  hitsPerLayerMax = parameters()->getFloatVal("hitsPerLayerMax");
  layersToTrackBackMax_ecal = parameters()->getIntVal("layersToTrackBackMax_ecal");
  layersToTrackBackMax_hcal = parameters()->getIntVal("layersToTrackBackMax_hcal");
  distMax_ecal = parameters()->getFloatVal("distMax_ecal");
  distMax_hcal = parameters()->getFloatVal("distMax_hcal");

}

void CalorimeterStage2Clusterer::processRunHeader( LCRunHeader* run) { 

  _nRun++;
} 

void CalorimeterStage2Clusterer::processEvent( LCEvent * evt ) { 

  // Process events in this range
  if(!((evt->getRunNumber()<firstRun && evt->getRunNumber()>lastRun) ||
       (evt->getRunNumber()==firstRun && evt->getEventNumber()<firstEventInFirstRun) ||
       (evt->getRunNumber()==lastRun && evt->getEventNumber()>lastEventInLastRun))) {

  if(printAction) cout << "  - recovering broken mip tracks...." << endl;
    
  // Create collections to store:
  // - the hits per pseudolayer of the stage 1 clusters
  LCCollectionVec* hitsPerPseudolayerOfCluster1Vec = new LCCollectionVec(LCIO::LCFLOATVEC);
  // - the stage 2 clusters
  LCCollectionVec* cluster2Vec = new LCCollectionVec(LCIO::CLUSTER);
  // - additional attributes of the stage 2 clusters (runs in parallel with cluster2Vec)
  LCCollectionVec* cluster2XtraVec = new LCCollectionVec(LCIO::CLUSTER);
  // - the seed pseudolayer of stage 2 clusters (runs in parallel with cluster2Vec)
  LCCollectionVec* seedPseudolayerOfCluster2Vec = new LCCollectionVec(LCIO::LCINTVEC);
  // - the terminating pseudolayer of stage 2 clusters (runs in parallel with cluster2Vec)
  LCCollectionVec* lastPseudolayerOfCluster2Vec = new LCCollectionVec(LCIO::LCINTVEC);

  // Retrieve these collections
  LCCollection* cluster1Vec=evt->getCollection("CalorimeterStage1Clusters");
  LCCollection* cluster1XtraVec=evt->getCollection("CalorimeterStage1ClustersXtra");
  LCCollection* seedPseudolayerOfCluster1Vec=evt->getCollection("CalorimeterStage1ClusterSeedPseudolayers");
  LCCollection* lastPseudolayerOfCluster1Vec=evt->getCollection("CalorimeterStage1ClusterLastPseudolayers");

  int i, j, l, p, q, u;
  double pi=acos(-1.);
  int merging_cluster;
  int earliestSeedLayer;
  int count_merged=0;
  int layersToTrackBackMax;
  bool OK,isAssociated;
  float delta_r_perp=0.;
  float dir_cos_perp=0.;
  float dist, dist_min, dist_max;
  float wmax;
  float hits_per_pseudolayer;
  float cos_stavecentreangle[3+barrelSymmetry];
  float sin_stavecentreangle[3+barrelSymmetry];

  // Set up some geometrical parameters for use later
  for(p=1;p<=2+barrelSymmetry;p++) {
    cos_stavecentreangle[p]=cos(((p-1)*2*pi/barrelSymmetry)+phi_1);
    sin_stavecentreangle[p]=sin(((p-1)*2*pi/barrelSymmetry)+phi_1);
  }

  // Loop over clusters...
  for(i=0;i<cluster1Vec->getNumberOfElements();i++) {
    Cluster* cluster1 = dynamic_cast<Cluster*>(cluster1Vec->getElementAt(i));
    LCIntVec* seedPseudolayerOfCluster1 = dynamic_cast<LCIntVec*>(seedPseudolayerOfCluster1Vec->getElementAt(i));
    LCIntVec* lastPseudolayerOfCluster1 = dynamic_cast<LCIntVec*>(lastPseudolayerOfCluster1Vec->getElementAt(i));
    // ...and calculate the average number of hits per pseudolayer
    hits_per_pseudolayer=float(cluster1->getCalorimeterHits().size())/(1+(*lastPseudolayerOfCluster1->begin())-(*seedPseudolayerOfCluster1->begin()));
    LCFloatVec* hitsPerPseudolayerOfCluster1 = new LCFloatVec;
    hitsPerPseudolayerOfCluster1->push_back(hits_per_pseudolayer);
    hitsPerPseudolayerOfCluster1Vec->push_back(hitsPerPseudolayerOfCluster1);
  }

  // Loop over pseudolayers in reverse order
  for(l=totalLayers;l>=1;l--) {
    if(l<=ecalLayers) layersToTrackBackMax=layersToTrackBackMax_ecal;
    else layersToTrackBackMax=layersToTrackBackMax_hcal; 
    // Loop over clusters...
    for(i=0;i<cluster1Vec->getNumberOfElements();i++) {
      Cluster* cluster1 = dynamic_cast<Cluster*>(cluster1Vec->getElementAt(i));
      Cluster* cluster1Xtra = dynamic_cast<Cluster*>(cluster1XtraVec->getElementAt(i));
      LCIntVec* seedPseudolayerOfCluster1 = dynamic_cast<LCIntVec*>(seedPseudolayerOfCluster1Vec->getElementAt(i));
      LCIntVec* lastPseudolayerOfCluster1 = dynamic_cast<LCIntVec*>(lastPseudolayerOfCluster1Vec->getElementAt(i));
      LCFloatVec* hitsPerPseudolayerOfCluster1 = dynamic_cast<LCFloatVec*>(hitsPerPseudolayerOfCluster1Vec->getElementAt(i));
      // ...which terminate in the current pseudolayer...
      if(*lastPseudolayerOfCluster1->begin()==l) {
 	int seedPseudolayer1=*seedPseudolayerOfCluster1->begin();
	int lastPseudolayer1=*lastPseudolayerOfCluster1->begin();
	merging_cluster=0;
	// ...and which look like mip tracks, but terminate inside the calorimeters
	if(int(cluster1->getCalorimeterHits().size())>=clusterSizeMin && *hitsPerPseudolayerOfCluster1->begin()<hitsPerLayerMax && lastPseudolayer1<totalLayers) {
	  // Initialise the minimum distance to the minimum impermissible distance and the weight of the highest weighted hit to zero
	  earliestSeedLayer=1+totalLayers;
	  dist_min=distMax_ecal+distMax_hcal;
	  wmax=0.;
	  // Loop over clusters... 
	  for(p=0;p<cluster2Vec->getNumberOfElements();p++) {
	    Cluster* cluster2 = dynamic_cast<Cluster*>(cluster2Vec->getElementAt(p));
	    Cluster* cluster2Xtra = dynamic_cast<Cluster*>(cluster2XtraVec->getElementAt(p));
	    LCIntVec* seedPseudolayerOfCluster2 = dynamic_cast<LCIntVec*>(seedPseudolayerOfCluster2Vec->getElementAt(p));
	    int seedPseudolayer2=*seedPseudolayerOfCluster2->begin();
	    // ...of sufficiently high multiplicity, that are seeded later than, or within layersToTrackBackMax pseudolayers of, 
	    // the terminating pseudolayer, giving greater preference to a cluster with an earlier seed
	    if(int(cluster2->getCalorimeterHits().size())>=clusterSizeMin && seedPseudolayer2>lastPseudolayer1-layersToTrackBackMax && seedPseudolayer2<=earliestSeedLayer) {
	      // Loop over the hits... 
	      for(u=0;u<int(cluster2->getCalorimeterHits().size());u++) {  
		const float* pos2=cluster2->getCalorimeterHits()[u]->getPosition();
		int pseudolayer2=1+cluster2->getCalorimeterHits()[u]->getCellID1()/16777216;
		// ...in the seed pseudolayer of this cluster
		if(pseudolayer2==seedPseudolayer2) {
		  if(pseudolayer2<=ecalLayers) dist_max=distMax_ecal;
		  else dist_max=distMax_hcal;
		  isAssociated=false;
		  // Loop over pseudolayers of the terminating cluster in reverse order...
		  for(q=0;q<layersToTrackBackMax && q<=l-1;q++) {
		    if(seedPseudolayer2>lastPseudolayer1-q) {
		      // ...unless an association has already been made between the terminating cluster's hit and the cluster seed hit
		      if(isAssociated) break;
		      // Loop over the hits... 
		      for(j=0;j<int(cluster1->getCalorimeterHits().size());j++) {
			const float* pos1=cluster1->getCalorimeterHits()[j]->getPosition();
			const float* dir1=cluster1Xtra->getCalorimeterHits()[j]->getPosition();
			int pseudolayer1=1+cluster1->getCalorimeterHits()[j]->getCellID1()/16777216;
			// ...in the current pseudolayer of the terminating cluster
			if(pseudolayer1==lastPseudolayer1-q) {
			  OK=false;
			  // Here for the full detector comprising barrel and endcaps
			  if(detectorType=="full") {
			    int pseudostave1=1+(cluster1->getCalorimeterHits()[j]->getCellID1()%16777216)/8;
			    int pseudostave2=1+(cluster2->getCalorimeterHits()[u]->getCellID1()%16777216)/8;
			    // Create geometrical constructs if the hit in the terminating cluster's terminating pseudolayer:
			    // - is in the pseudobarrel (links permitted only to hits in pseudoendcaps and adjacent 
			    //   pseudobarrel pseudostaves)
			    if(pseudostave1<=barrelSymmetry && (pseudostave2>barrelSymmetry || 
								(pseudostave2<=barrelSymmetry && 
								 (abs(pseudostave1-pseudostave2)<=1 || 
								  abs(pseudostave1-pseudostave2)==barrelSymmetry-1)))) {
			      dir_cos_perp=dir1[0]*cos_stavecentreangle[pseudostave1] + dir1[1]*sin_stavecentreangle[pseudostave1];
			      if(dir_cos_perp>0.) {
				OK=true;
				delta_r_perp=(pos2[0]-pos1[0])*cos_stavecentreangle[pseudostave1]+
				  (pos2[1]-pos1[1])*sin_stavecentreangle[pseudostave1];
			      }
			    }
			    // - is in the LH pseudoendcap (z<0) (links permitted to all pseudostaves except the
			    //   RH pseudoendcap)
			    else if(pseudostave1==barrelSymmetry+1 && pseudostave2!=barrelSymmetry+2) {
			      dir_cos_perp=-dir1[2];
			      if(dir_cos_perp>0.) {
				OK=true;
				delta_r_perp=-pos2[2]+pos1[2];
			      }
			    }
			    // - is in the RH pseudoendcap (z>0) (links permitted to all pseudostaves except the
			    //   LH pseudoendcap)
			    else if(pseudostave1==barrelSymmetry+2 && pseudostave2!=barrelSymmetry+1) {
			      dir_cos_perp=+dir1[2];
			      if(dir_cos_perp>0.) {
				OK=true;
				delta_r_perp=+pos2[2]-pos1[2];
			      }
			    }
			  }
			  // Here for a prototype comprising a single endcap with layers aligned perpendicularly to 
			  // the +z direction
			  else if(detectorType=="prototype") {
			    // Create geometrical constructs
			    dir_cos_perp=+dir1[2];
			    if(dir_cos_perp>0.) {
			      OK=true;
			      delta_r_perp=+pos2[2]-pos1[2];
			    }
			  }
			  // Accept only forward propagation through pseudolayers
			  if(OK && delta_r_perp > 0.) {
			    // Calculate the expected distance between the hit in the seed pseudolayer of the later-seeded cluster
			    // and the projected point of intersection of the hit in the previous pseudolayer of the terminating
			    // cluster...
			    dist=
			      fabs(sqrt(pow(((pos2[0]-pos1[0]))-(dir1[0]*delta_r_perp/(dir_cos_perp)),2)+
					pow(((pos2[1]-pos1[1]))-(dir1[1]*delta_r_perp/(dir_cos_perp)),2)+
					pow(((pos2[2]-pos1[2]))-(dir1[2]*delta_r_perp/(dir_cos_perp)),2)));
			    // ...and minimise w.r.t all hits in the previous pseudolayer, subject to
			    // dist < dist_max; flag the cluster that contains this hit as the cluster
			    // with which the mip-track-like cluster will be merged (in the event of a tie, 
			    // flag as the cluster with the earliest pseudolayer, then, if still a tie, as 
			    // that which contains the highest weighted seed hit)
			    if(dist<dist_max && (dist<dist_min ||
						(dist==dist_min && seedPseudolayer2<earliestSeedLayer) ||
						(dist==dist_min && seedPseudolayer2==earliestSeedLayer && 
						 cluster2Xtra->getHitContributions()[u]>wmax))) {
			      dist_min=dist;
			      wmax=cluster2Xtra->getHitContributions()[u];
			      merging_cluster=p+1;
			      earliestSeedLayer=seedPseudolayer2;
			      isAssociated=true;
			    }
			  }
			}
		      }
		    }
		  }
		}
	      }
	    }
	  }
	}
	// If the merging criteria are not satisfied, create a new stage 2 cluster and new instances of other 
	// stage 2 cluster attributes and add each to their respective collections
	if(merging_cluster==0) {
	  ClusterImpl* cluster2 = new ClusterImpl;
	  ClusterImpl* cluster2Xtra = new ClusterImpl;
	  LCIntVec* seedPseudolayerOfCluster2 = new LCIntVec;
	  LCIntVec* lastPseudolayerOfCluster2 = new LCIntVec;
	  cluster2Vec->push_back(cluster2);
	  cluster2XtraVec->push_back(cluster2Xtra);
	  seedPseudolayerOfCluster2Vec->push_back(seedPseudolayerOfCluster2);
	  lastPseudolayerOfCluster2Vec->push_back(lastPseudolayerOfCluster2);
	  // Loop over the hits in the original cluster; add the hits together with their energies to the new 
	  // cluster, and add their direction cosines together with their weight to the cluster attributes
	  for(u=0;u<int(cluster1->getCalorimeterHits().size());u++) {
	    cluster2->addHit(cluster1->getCalorimeterHits()[u],cluster1->getCalorimeterHits()[u]->getEnergy());
	    cluster2Xtra->addHit(cluster1Xtra->getCalorimeterHits()[u],cluster1Xtra->getHitContributions()[u]);
	  }
	  // Add a pointer to the copied stage 1 cluster 
	  cluster2->addCluster(cluster1);
	  // Set the cluster's seed and terminating pseudolayers to those of the corresponding stage 1 cluster
	  seedPseudolayerOfCluster2->push_back(seedPseudolayer1);
	  lastPseudolayerOfCluster2->push_back(lastPseudolayer1);
	}	
	// If the merging criteria are satisfied, invoke the merging stage 2 cluster and instances of other
	// merging stage 2 cluster attributes
	else {
	  ClusterImpl* cluster2 = dynamic_cast<ClusterImpl*>(cluster2Vec->getElementAt(merging_cluster-1));
	  ClusterImpl* cluster2Xtra = dynamic_cast<ClusterImpl*>(cluster2XtraVec->getElementAt(merging_cluster-1));
	  LCIntVec* seedPseudolayerOfCluster2 = dynamic_cast<LCIntVec*>(seedPseudolayerOfCluster2Vec->getElementAt(merging_cluster-1));
	  // Loop over the hits in the original cluster; add the hits together with their energies to the merging 
	  // cluster, and add their direction cosines together with their weights to the cluster attributes
	  for(u=0;u<int(cluster1->getCalorimeterHits().size());u++) {
	    cluster2->addHit(cluster1->getCalorimeterHits()[u],cluster1->getCalorimeterHits()[u]->getEnergy());
	    cluster2Xtra->addHit(cluster1Xtra->getCalorimeterHits()[u],cluster1Xtra->getHitContributions()[u]);
	  }
	  // Add a pointer to the contributing stage 1 cluster 
	  cluster2->addCluster(cluster1);
	  // Update the stage 2 cluster seed pseudolayer
	  seedPseudolayerOfCluster2->pop_back();
	  seedPseudolayerOfCluster2->push_back(seedPseudolayer1);
	  count_merged++;
	}
      }
    }
  } 
  
  // Store the cluster hits when the clusters collection is written to the LCIO output file
  LCFlagImpl chflag(0);
  chflag.setBit(LCIO::CLBIT_HITS);
  cluster2Vec->setFlag(chflag.getFlag());

  // Store the collections
  evt->addCollection(cluster2Vec,"CalorimeterStage2Clusters");
  evt->addCollection(cluster2XtraVec,"CalorimeterStage2ClustersXtra");
  evt->addCollection(seedPseudolayerOfCluster2Vec,"CalorimeterStage2ClusterSeedPseudolayers");
  evt->addCollection(lastPseudolayerOfCluster2Vec,"CalorimeterStage2ClusterLastPseudolayers");

  // Don't write these to the LCIO output file
  cluster2XtraVec->setTransient();
  seedPseudolayerOfCluster2Vec->setTransient();
  lastPseudolayerOfCluster2Vec->setTransient();

  if(printAction) {
    cout << "    --> OK (" << count_merged;
    count_merged==1 ? cout << " cluster recovered)" : cout << " clusters recovered)";
    cout << endl;
  }
  }
  
  _nEvt ++;
}

void CalorimeterStage2Clusterer::check( LCEvent * evt ) { 
  // nothing to check here - could be used to fill checkplots in reconstruction processor
}

void CalorimeterStage2Clusterer::end(){ 
  
  std::cout << "CalorimeterStage2Clusterer::end()  " << name() 
	    << " processed " << _nEvt << " events in " << _nRun << " runs "
	    << std::endl;

}

