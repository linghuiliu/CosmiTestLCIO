#ifndef CalorimeterClusterCalibrator_h
#define CalorimeterClusterCalibrator_h 1

#include "marlin/Processor.h"
#include "lcio.h"
#include <string>


using namespace lcio ;
using namespace marlin ;



/** Based on example processor for marlin. 
 */
class CalorimeterClusterCalibrator : public Processor {
  
 public:
  
  virtual Processor*  newProcessor() { return new CalorimeterClusterCalibrator ; }
  
  
  CalorimeterClusterCalibrator() ;
  
  /** Called at the begin of the job before anything is read.
   * Use to initialize the processor, e.g. book histograms.
   */
  virtual void init() ;
  
  /** Called for every run.
   */
  virtual void processRunHeader( LCRunHeader* run ) ;
  
  /** Called for every event - the working horse.
   */
  virtual void processEvent( LCEvent * evt ) ; 
  
  virtual void check( LCEvent * evt ) ; 
  
  
  /** Called after data processing for clean up.
   */
  virtual void end() ;
  
  
 private:

  int firstRun;
  int lastRun;
  int firstEventInFirstRun;
  int lastEventInLastRun;
  int printAction;
  std::string mode;
  float normalisation;
  int ecalLayerRange1;
  int ecalLayerRange2;
  int ecalLayerRange3;
  float c_ecal1;
  float c_ecal2;
  float c_ecal3;
  float c_hcal;

 protected:

  int _nRun ;
  int _nEvt ;
} ;

#endif



