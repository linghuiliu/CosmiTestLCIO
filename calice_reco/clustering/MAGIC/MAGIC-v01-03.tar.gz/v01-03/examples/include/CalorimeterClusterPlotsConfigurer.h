#ifndef CalorimeterClusterPlotsConfigurer_h
#define CalorimeterClusterPlotsConfigurer_h 1

#include "marlin/Processor.h"
#include "lcio.h"
#include <string>


using namespace lcio ;
using namespace marlin ;



/** Based on example processor for marlin. 
 */
class CalorimeterClusterPlotsConfigurer : public Processor {
  
 public:
  
  virtual Processor*  newProcessor() { return new CalorimeterClusterPlotsConfigurer ; }
  
  
  CalorimeterClusterPlotsConfigurer() ;
  
  /** Called at the begin of the job before anything is read.
   * Use to initialize the processor, e.g. book histograms.
   */
  virtual void init() ;
  
  /** Called for every run.
   */
  virtual void processRunHeader( LCRunHeader* run ) ;
  
  /** Called for every event - the working horse.
   */
  virtual void processEvent( LCEvent * evt ) ; 
  
  
  virtual void check( LCEvent * evt ) ; 
  
  
  /** Called after data processing for clean up.
   */
  virtual void end() ;
  
  
 private:

  StringVec config_ROOTOutputFile;
  StringVec config_plotPseudostave;
  StringVec config_xmin;
  StringVec config_xmax;
  StringVec config_ymin;
  StringVec config_ymax;
  StringVec config_zmin;
  StringVec config_zmax;
  std::string ROOTOutputFile;
  int plotPseudostave;
  float xmin;
  float xmax;
  float ymin;
  float ymax;
  float zmin;
  float zmax;

 protected:

  std::string _ROOTOutputFile;
  std::string _plotPseudostave;
  std::string _xmin;
  std::string _xmax;
  std::string _ymin;
  std::string _ymax;
  std::string _zmin;
  std::string _zmax;
  int _nRun ;
  int _nEvt ;
} ;

#endif



