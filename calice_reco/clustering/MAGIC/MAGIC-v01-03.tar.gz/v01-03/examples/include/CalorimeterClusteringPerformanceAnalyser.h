#ifndef CalorimeterClusteringPerformanceAnalyser_h
#define CalorimeterClusteringPerformanceAnalyser_h 1

#include "marlin/Processor.h"
#include "lcio.h"
#include <string>
#include <stdio.h>


using namespace lcio ;
using namespace marlin ;



/** Based on example processor for marlin. 
 */
class CalorimeterClusteringPerformanceAnalyser : public Processor {
  
 public:
  
  virtual Processor*  newProcessor() { return new CalorimeterClusteringPerformanceAnalyser ; }
  
  
  CalorimeterClusteringPerformanceAnalyser() ;
  
  /** Called at the begin of the job before anything is read.
   * Use to initialize the processor, e.g. book histograms.
   */
  virtual void init() ;
  
  /** Called for every run.
   */
  virtual void processRunHeader( LCRunHeader* run ) ;
  
  /** Called for every event - the working horse.
   */
  virtual void processEvent( LCEvent * evt ) ; 
  
  
  virtual void check( LCEvent * evt ) ; 
  
  
  /** Called after data processing for clean up.
   */
  virtual void end() ;
  
  
 private:

  int firstRun;
  int lastRun;
  int firstEventInFirstRun;
  int lastEventInLastRun;
  int printAction;
  int writeQuality;
  std::string QualityFile;
  FILE* out;

 protected:

  std::string _QualityFile;
  std::string _writeQuality;

  int _nRun ;
  int _nEvt ;
} ;

#endif



