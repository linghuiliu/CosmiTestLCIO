#ifndef CalorimeterCalibrationConfigurer_h
#define CalorimeterCalibrationConfigurer_h 1

#include "marlin/Processor.h"
#include "lcio.h"
#include <string>


using namespace lcio ;
using namespace marlin ;



/** Based on example processor for marlin. 
 */
class CalorimeterCalibrationConfigurer : public Processor {
  
 public:
  
  virtual Processor*  newProcessor() { return new CalorimeterCalibrationConfigurer ; }
  
  
  CalorimeterCalibrationConfigurer() ;
  
  /** Called at the begin of the job before anything is read.
   * Use to initialize the processor, e.g. book histograms.
   */
  virtual void init() ;
  
  /** Called for every run.
   */
  virtual void processRunHeader( LCRunHeader* run ) ;
  
  /** Called for every event - the working horse.
   */
  virtual void processEvent( LCEvent * evt ) ; 
  
  
  virtual void check( LCEvent * evt ) ; 
  
  
  /** Called after data processing for clean up.
   */
  virtual void end() ;
  
  
 private:

  StringVec calibration_mode;
  StringVec calibration_normalisation;
  StringVec calibration_ecalLayerRange1;
  StringVec calibration_ecalLayerRange2;
  StringVec calibration_ecalLayerRange3;
  StringVec calibration_c_ecal1;
  StringVec calibration_c_ecal2;
  StringVec calibration_c_ecal3;
  StringVec calibration_c_hcal;

  int firstRun;
  int lastRun;
  int firstEventInFirstRun;
  int lastEventInLastRun;
  std::string mode;
  float normalisation;
  int ecalLayerRange1;
  int ecalLayerRange2;
  int ecalLayerRange3;
  float c_ecal1;
  float c_ecal2;
  float c_ecal3;
  float c_hcal;

 protected:

  std::string _mode;
  std::string _normalisation;
  std::string _ecalLayerRange1;
  std::string _ecalLayerRange2;
  std::string _ecalLayerRange3;
  std::string _c_ecal1;
  std::string _c_ecal2;
  std::string _c_ecal3;
  std::string _c_hcal;

  int _nRun ;
  int _nEvt ;
} ;

#endif



