#include <iostream>
#include <fstream>
#include <iomanip>
#include <math.h>
#include <string>

using namespace std;

int main() {

  std::string fileName;

  // Ask for the file to process
  cout << "Enter filename: ";
  getline(cin,fileName);

  int runNumber,eventNumber;
  double quality;
  int nevents=0;
  double sum=0.;
  double sum2=0.;

  ifstream in;
  // Read the quality for each event from the file; accumulate the sum and the
  // sum of squares and the number of events processed
  in.open(fileName.c_str());
  while(in >> runNumber >> eventNumber >> quality) {
    sum+=quality;
    sum2+=quality*quality;
    nevents++;
  }
  in.close();
  
  // Calculate the mean quality and its error for these events...
  double mean = sum/nevents;
  double error = (1./sqrt(nevents*(nevents-1.)))
    *sqrt(sum2 - nevents*mean*mean);

  // ...and append this to the file
  ofstream out;
  out.open(fileName.c_str(),ios::app);
  out << endl;
  out << "Mean quality (";
  nevents==1 ? out << "1 event) = " : out << nevents << " events) = ";
  out << setiosflags(ios::fixed) << setprecision(2) 
      << 100.*mean << " +/- "
      << setiosflags(ios::fixed) << setprecision(2) 
      << 100.*error << " %" << endl;
  out.close();
 
  return 0;
// EOF
}

