#include "CalorimeterCalibrationConfigurer.h"
#include "marlin/Global.h"

using namespace lcio;
using namespace marlin;
using namespace std;


CalorimeterCalibrationConfigurer aCalorimeterCalibrationConfigurer;


CalorimeterCalibrationConfigurer::CalorimeterCalibrationConfigurer() : Processor("CalorimeterCalibrationConfigurer") {
  
  // Processor description
  _description = "CalorimeterCalibrationConfigurer allows user to define energy-calibration constants";
  

  // Register steering parameters: name, description, class-variable, default value 
  registerProcessorParameter("mode", 
			     "calibration mode (a/a => analogue Ecal + analogue Hcal; a/d => analogue Ecal + digital Hcal; d/a => digital Ecal + analogue Hcal; d/d => digital Ecal + digital Hcal)",
			     _mode,
			     std::string("a/d"));
  registerProcessorParameter("normalisation", 
			     "overall normalisation factor",
			     _normalisation,
			     std::string("187.")); 
  registerProcessorParameter("ecalLayerRange1", 
			     "upper limit on first range of layers",
			     _ecalLayerRange1,
			     std::string("30")); 
  registerProcessorParameter("ecalLayerRange2", 
			     "upper limit on second range of layers",
			     _ecalLayerRange2,
			     std::string("40")); 
  registerProcessorParameter("ecalLayerRange3", 
			     "upper limit on third range of layers",
			     _ecalLayerRange3,
			     std::string("999")); 
  registerProcessorParameter("c_ecal1", 
			     "weight for Ecal hits in first range of layers",
			     _c_ecal1,
			     std::string("1.")); 
  registerProcessorParameter("c_ecal2", 
			     "weight for Ecal hits in second range of layers",
			     _c_ecal2,
			     std::string("3.")); 
  registerProcessorParameter("c_ecal3", 
			     "weight for Ecal hits in third range of layers",
			     _c_ecal3,
			     std::string("0.")); 
  registerProcessorParameter("c_hcal", 
			     "weight for Hcal hits",
			     _c_hcal,
			     std::string("20."));

} 


void CalorimeterCalibrationConfigurer::init() { 

  // Print processor parameters
  printParameters();

  // Set number of runs and events to 0
  _nRun = 0;
  _nEvt = 0;
  
  // Get parameters from steering file
  firstRun = Global::parameters->getIntVal("firstRun");
  lastRun = Global::parameters->getIntVal("lastRun");
  firstEventInFirstRun = Global::parameters->getIntVal("firstEventInFirstRun");
  lastEventInLastRun = Global::parameters->getIntVal("lastEventInLastRun");
  mode = parameters()->getStringVal("mode");
  normalisation = parameters()->getFloatVal("normalisation");
  ecalLayerRange1 = parameters()->getIntVal("ecalLayerRange1");
  ecalLayerRange2 = parameters()->getIntVal("ecalLayerRange2");
  ecalLayerRange3 = parameters()->getIntVal("ecalLayerRange3");
  c_ecal1 = parameters()->getFloatVal("c_ecal1");
  c_ecal2 = parameters()->getFloatVal("c_ecal2");
  c_ecal3 = parameters()->getFloatVal("c_ecal3");
  c_hcal = parameters()->getFloatVal("c_hcal");

  // Put parameters into global scope for use in subsequent processors
  Global::parameters->add("mode",parameters()->getStringVals("mode",calibration_mode));
  Global::parameters->add("normalisation",parameters()->getStringVals("normalisation",calibration_normalisation));
  Global::parameters->add("ecalLayerRange1",parameters()->getStringVals("ecalLayerRange1",calibration_ecalLayerRange1));
  Global::parameters->add("ecalLayerRange2",parameters()->getStringVals("ecalLayerRange2",calibration_ecalLayerRange2));
  Global::parameters->add("ecalLayerRange3",parameters()->getStringVals("ecalLayerRange3",calibration_ecalLayerRange3));
  Global::parameters->add("c_ecal1",parameters()->getStringVals("c_ecal1",calibration_c_ecal1));
  Global::parameters->add("c_ecal2",parameters()->getStringVals("c_ecal2",calibration_c_ecal2));
  Global::parameters->add("c_ecal3",parameters()->getStringVals("c_ecal3",calibration_c_ecal3));
  Global::parameters->add("c_hcal",parameters()->getStringVals("c_hcal",calibration_c_hcal));
}

void CalorimeterCalibrationConfigurer::processRunHeader( LCRunHeader* run) { 

  _nRun++;
} 

void CalorimeterCalibrationConfigurer::processEvent( LCEvent * evt ) { 

  // Process events in this range
  if(!((evt->getRunNumber()<firstRun && evt->getRunNumber()>lastRun) ||
       (evt->getRunNumber()==firstRun && evt->getEventNumber()<firstEventInFirstRun) ||
       (evt->getRunNumber()==lastRun && evt->getEventNumber()>lastEventInLastRun))) {
    
  cout << "Processing run " << evt->getRunNumber() << ", event " << evt->getEventNumber() << endl;
  }

  _nEvt ++;
}


void CalorimeterCalibrationConfigurer::check( LCEvent * evt ) { 
  // nothing to check here - could be used to fill checkplots in reconstruction processor
}


void CalorimeterCalibrationConfigurer::end(){ 
  
  std::cout << "CalorimeterCalibrationConfigurer::end()  " << name() 
	    << " processed " << _nEvt << " events in " << _nRun << " runs "
	    << std::endl;

}

