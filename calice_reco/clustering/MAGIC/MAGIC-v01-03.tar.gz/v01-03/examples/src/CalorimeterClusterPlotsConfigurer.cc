#include "CalorimeterClusterPlotsConfigurer.h"
#include "marlin/Global.h"

using namespace lcio;
using namespace marlin;
using namespace std;


CalorimeterClusterPlotsConfigurer aCalorimeterClusterPlotsConfigurer;


CalorimeterClusterPlotsConfigurer::CalorimeterClusterPlotsConfigurer() : Processor("CalorimeterClusterPlotsConfigurer") {
  
  // Processor description
  _description = "CalorimeterClusterPlotsConfigurer allows user to define histogramming requirements";
  

  // Register steering parameters: name, description, class-variable, default value

  registerProcessorParameter("ROOTOutputFile", 
			     "output file for histograms",
			     _ROOTOutputFile,
			     std::string("./histos/MyROOTOutput.out")); 
  registerProcessorParameter("plotPseudostave", 
			     "pseudostave to plot (effective range [1,barrelSymmetry]; 0 = all)",
			     _plotPseudostave,
			     std::string("0")); 
  registerProcessorParameter("xmin", 
			     "minimum x in view (in m)",
			     _xmin,
			     std::string("-4.00"));
  registerProcessorParameter("xmax", 
			     "maximum x in view (in m)",
			     _xmax,
			     std::string("+4.00"));
  registerProcessorParameter("ymin", 
			     "minimum y in view (in m)",
			     _ymin,
			     std::string("-4.00"));
  registerProcessorParameter("ymax", 
			     "maximum y in view (in m)",
			     _ymax,
			     std::string("+4.00"));
  registerProcessorParameter("zmin", 
			     "minimum z in view (in m)",
			     _zmin,
			     std::string("-4.00"));
  registerProcessorParameter("zmax", 
			     "maximum z in view (in m)",
			     _zmax,
			     std::string("+4.00"));

}


void CalorimeterClusterPlotsConfigurer::init() { 

  // Print processor parameters
  printParameters();

  // Set number of runs and events to 0
  _nRun = 0;
  _nEvt = 0;

  // Get parameters from steering file
  ROOTOutputFile = parameters()->getStringVal("ROOTOutputFile");
  plotPseudostave = parameters()->getIntVal("plotPseudostave");
  xmin = parameters()->getFloatVal("xmin");
  xmax = parameters()->getFloatVal("xmax");
  ymin = parameters()->getFloatVal("ymin");
  ymax = parameters()->getFloatVal("ymax");
  zmin = parameters()->getFloatVal("zmin");
  zmax = parameters()->getFloatVal("zmax");

  // Put parameters into global scope for use in subsequent processors
  Global::parameters->add("ROOTOutputFile",parameters()->getStringVals("ROOTOutputFile",config_ROOTOutputFile));
  Global::parameters->add("plotPseudostave",parameters()->getStringVals("plotPseudostave",config_plotPseudostave));
  Global::parameters->add("xmin",parameters()->getStringVals("xmin",config_xmin));
  Global::parameters->add("xmax",parameters()->getStringVals("xmax",config_xmax));
  Global::parameters->add("ymin",parameters()->getStringVals("ymin",config_ymin));
  Global::parameters->add("ymax",parameters()->getStringVals("ymax",config_ymax));
  Global::parameters->add("zmin",parameters()->getStringVals("zmin",config_zmin));
  Global::parameters->add("zmax",parameters()->getStringVals("zmax",config_zmax));
}

void CalorimeterClusterPlotsConfigurer::processRunHeader( LCRunHeader* run) { 

  _nRun++;
} 

void CalorimeterClusterPlotsConfigurer::processEvent( LCEvent * evt ) { 

  _nEvt ++;
}


void CalorimeterClusterPlotsConfigurer::check( LCEvent * evt ) { 
  // nothing to check here - could be used to fill checkplots in reconstruction processor
}


void CalorimeterClusterPlotsConfigurer::end(){ 
  
  std::cout << "CalorimeterClusterPlotsConfigurer::end()  " << name() 
	    << " processed " << _nEvt << " events in " << _nRun << " runs "
	    << std::endl;


}

