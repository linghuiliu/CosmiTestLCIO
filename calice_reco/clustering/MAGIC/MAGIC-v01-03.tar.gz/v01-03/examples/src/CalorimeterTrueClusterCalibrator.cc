#include "CalorimeterTrueClusterCalibrator.h"
#include "marlin/Global.h"

#include "IMPL/LCCollectionVec.h"
#include "IMPL/ClusterImpl.h"
#include "IMPL/LCFlagImpl.h"
#include "IMPL/LCRelationImpl.h"
#include "EVENT/MCParticle.h"
#include "UTIL/LCRelationNavigator.h"

using namespace lcio;
using namespace marlin;
using namespace std;


CalorimeterTrueClusterCalibrator aCalorimeterTrueClusterCalibrator;


CalorimeterTrueClusterCalibrator::CalorimeterTrueClusterCalibrator() : Processor("CalorimeterTrueClusterCalibrator") {
  
  // Processor description
  _description = "CalorimeterTrueClusterCalibrator adds calibrated energies to the true clusters";
  
}


void CalorimeterTrueClusterCalibrator::init() { 

  // Set number of runs and events to 0
  _nRun = 0;
  _nEvt = 0;
  
  // Get parameters from steering file
  firstRun = Global::parameters->getIntVal("firstRun");
  lastRun = Global::parameters->getIntVal("lastRun");
  firstEventInFirstRun = Global::parameters->getIntVal("firstEventInFirstRun");
  lastEventInLastRun = Global::parameters->getIntVal("lastEventInLastRun");
  printAction = Global::parameters->getIntVal("printAction");
  mode = Global::parameters->getStringVal("mode");
  normalisation = Global::parameters->getFloatVal("normalisation");
  ecalLayerRange1 = Global::parameters->getIntVal("ecalLayerRange1");
  ecalLayerRange2 = Global::parameters->getIntVal("ecalLayerRange2");
  ecalLayerRange3 = Global::parameters->getIntVal("ecalLayerRange3");
  c_ecal1 = Global::parameters->getFloatVal("c_ecal1");
  c_ecal2 = Global::parameters->getFloatVal("c_ecal2");
  c_ecal3 = Global::parameters->getFloatVal("c_ecal3");
  c_hcal = Global::parameters->getFloatVal("c_hcal");
}

void CalorimeterTrueClusterCalibrator::processRunHeader( LCRunHeader* run) { 

  _nRun++;
} 

void CalorimeterTrueClusterCalibrator::processEvent( LCEvent * evt ) { 

  // Process events in this range
  if(!((evt->getRunNumber()<firstRun && evt->getRunNumber()>lastRun) ||
       (evt->getRunNumber()==firstRun && evt->getEventNumber()<firstEventInFirstRun) ||
       (evt->getRunNumber()==lastRun && evt->getEventNumber()>lastEventInLastRun))) {

  if(printAction) cout << "  - adding calibrated energies to true clusters...." << endl;

  typedef const std::vector<std::string> NameVec;
  NameVec* strVec = evt->getCollectionNames();

  bool trueClustersAreStored=false;
  for(NameVec::const_iterator name=strVec->begin(); name!=strVec->end(); name++){
    string sss=name->c_str();
     if(sss=="CalorimeterTrueClusters") {
      trueClustersAreStored=true;
    }
  }
  // Continue only if MC truth information is available
  if(trueClustersAreStored) {

  // Create collections to store:
  // - the true clusters with calibrated energies added
  LCCollectionVec* calibratedTrueClusterVec = new LCCollectionVec(LCIO::CLUSTER);
  // - the relation between the calibrated and the uncalibrated true cluster
  LCCollectionVec* mCParticleRelVec = new LCCollectionVec(LCIO::LCRELATION);

  // Set the relation from and to types for the true clusters
  mCParticleRelVec->parameters().setValue( "RelationFromType",LCIO::CLUSTER);
  mCParticleRelVec->parameters().setValue( "RelationToType",LCIO::CLUSTER);

  // Set some parameters for the true clusters collection
  StringVec subdetNames;
  subdetNames.resize(2);
  subdetNames[0]="Ecal";
  subdetNames[1]="Hcal";
  calibratedTrueClusterVec->parameters().setValues("CalorimeterSubdetectorNames",subdetNames);

  // Retrieve these collections
  LCCollection* trueClusterVec=evt->getCollection("CalorimeterTrueClusters");
  LCCollection* hitVec=evt->getCollection("CalorimeterHits");
  LCCollection* mCParticleRel1Vec=evt->getCollection("CalorimeterTrueClusterRelationsToMCParticles");
  LCRelationNavigator mCParticleRel1(mCParticleRel1Vec); 

  int i, j;
  float w=0.;
  float calibratedHitEnergy=0.;

  // Get the MIP energy values used in creating the above-threshold hits
  StringVec floatKeys;
  FloatVec floatVec;
  hitVec->getParameters().getFloatKeys(floatKeys);
  float ecalMip=hitVec->getParameters().getFloatVals("CalorimeterMipEnergyValues",floatVec)[0]; 
  float hcalMip=hitVec->getParameters().getFloatVals("CalorimeterMipEnergyValues",floatVec)[1];   

  // Loop over true clusters and create a new true cluster for each to which the calibrated energy 
  // can be added and add this to the collection; also add a pointer from this calibrated true 
  // cluster to the MC particle responsible for it
  for(i=0;i<trueClusterVec->getNumberOfElements();i++) {
    Cluster* trueCluster = dynamic_cast<Cluster*>(trueClusterVec->getElementAt(i));
    ClusterImpl* calibratedTrueCluster = new ClusterImpl;
    MCParticle* mCParticle = dynamic_cast<MCParticle*>(mCParticleRel1.getRelatedToObjects(trueCluster)[0]);
    mCParticleRelVec->addElement(new LCRelationImpl(calibratedTrueCluster,mCParticle));
    calibratedTrueClusterVec->push_back(calibratedTrueCluster);
    // Copy the cluster-fragments contributing to the original true cluster
    for(j=0;j<int(trueCluster->getClusters().size());j++) {
      calibratedTrueCluster->addCluster(trueCluster->getClusters()[j]);
    }  
    // Initialise the calibrated true cluster energy and the separate Ecal and Hcal contributions to zero
    calibratedTrueCluster->setEnergy(0.);
    calibratedTrueCluster->subdetectorEnergies().resize(2);
    calibratedTrueCluster->subdetectorEnergies()[0]=0.;
    calibratedTrueCluster->subdetectorEnergies()[1]=0.;
    // Loop over the original true cluster's hits
    for(j=0;j<int(trueCluster->getCalorimeterHits().size());j++) {
      CalorimeterHit* hit = dynamic_cast<CalorimeterHit*>(trueCluster->getCalorimeterHits()[j]);
      float contribution=trueCluster->getHitContributions()[j];
      // If detector operates with an Ecal
      if(hit->getType()==0) {
	int layer=1+hit->getCellID0()/16777216;
	// - in analogue mode
	if(mode=="a/a" || mode=="a/d") {
	  w=contribution/(ecalMip*normalisation);
	}
	// - in digital mode
	else if(mode=="d/a" || mode=="d/d") {
	  w=contribution/(hit->getEnergy()*normalisation);
	}
	// Calibrate hit energy in Ecal layer-range [1,ecalLayerRange1]...
	if(layer<=ecalLayerRange1) {
	  calibratedHitEnergy=w*c_ecal1;
	}
	// Calibrate hit energy if in Ecal layer-range [1+ecalLayerRange1,ecalLayerRange2]...
	else if(layer<=ecalLayerRange2) {
	  calibratedHitEnergy=w*c_ecal2;
	}
	// Calibrate hit energy if in Ecal layer-range [1+ecalLayerRange2,ecalLayerRange3]...
	else if(layer<=ecalLayerRange3) {
	  calibratedHitEnergy=w*c_ecal3;	  
	}
	calibratedTrueCluster->subdetectorEnergies()[0]+=calibratedHitEnergy;
      }
      // ...and with an Hcal
      else {
	// - in analogue mode
	if(mode=="a/a" || mode=="d/a") {
	  w=contribution/(hcalMip*normalisation);
	}
	// - in digital mode
	else if(mode=="a/d" || mode=="d/d") {
	  w=contribution/(hit->getEnergy()*normalisation);
	}
	// Calibrate hit energy if in Hcal
	calibratedHitEnergy=w*c_hcal;
	calibratedTrueCluster->subdetectorEnergies()[1]+=calibratedHitEnergy;
      }
      // Copy the hit and its energy to the calibrated true cluster and set the calibrated 
      // true cluster energy
      calibratedTrueCluster->addHit(hit,calibratedHitEnergy);
      calibratedTrueCluster->setEnergy(calibratedTrueCluster->getEnergy()+calibratedHitEnergy);
    }
  }

  // Save the calibrated true cluster hits when the clusters collection is written to the LCIO 
  // output file
  LCFlagImpl chflag(0);
  chflag.setBit(LCIO::CLBIT_HITS);
  calibratedTrueClusterVec->setFlag(chflag.getFlag());

  // Store the collections
  evt->addCollection(calibratedTrueClusterVec,"CalorimeterCalibratedTrueClusters");
  evt->addCollection(mCParticleRelVec,"CalorimeterCalibratedTrueClusterRelationsToMCParticles");

  if(printAction) cout << "    --> OK" << endl;
  }
  else if(printAction) cout << "    --> no true clusters in input file!" << endl;
  }

  _nEvt ++;
}


void CalorimeterTrueClusterCalibrator::check( LCEvent * evt ) { 
  // nothing to check here - could be used to fill checkplots in reconstruction processor
}


void CalorimeterTrueClusterCalibrator::end(){ 
  
  std::cout << "CalorimeterTrueClusterCalibrator::end()  " << name() 
	    << " processed " << _nEvt << " events in " << _nRun << " runs "
	    << std::endl;

}

