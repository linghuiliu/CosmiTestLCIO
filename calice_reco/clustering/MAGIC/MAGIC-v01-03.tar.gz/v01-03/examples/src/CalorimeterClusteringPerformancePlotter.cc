#include "CalorimeterClusteringPerformancePlotter.h"
#include "marlin/Global.h"

#include "TROOT.h"
#include "TCanvas.h"
#include "TH2F.h"
#include "TLatex.h"

#include "IMPL/LCCollectionVec.h"
#include "EVENT/LCFloatVec.h"

using namespace lcio;
using namespace marlin;
using namespace std;


CalorimeterClusteringPerformancePlotter aCalorimeterClusteringPerformancePlotter;


CalorimeterClusteringPerformancePlotter::CalorimeterClusteringPerformancePlotter() : Processor("CalorimeterClusteringPerformancePlotter") {
  
  // Processor description
  _description = "CalorimeterClusteringPerformancePlotter creates a plot of the clustering performance in the designated ROOTOutputFile (N.B. this processor has no effect if ROOT is not installed)";

}


void CalorimeterClusteringPerformancePlotter::init() { 

  // Set number of runs and events to 0
  _nRun = 0;
  _nEvt = 0;

  // Get parameters from steering file
  firstRun = Global::parameters->getIntVal("firstRun");
  lastRun = Global::parameters->getIntVal("lastRun");
  firstEventInFirstRun = Global::parameters->getIntVal("firstEventInFirstRun");
  lastEventInLastRun = Global::parameters->getIntVal("lastEventInLastRun");
  printAction = Global::parameters->getIntVal("printAction");
  ROOTOutputFile = Global::parameters->getStringVal("ROOTOutputFile");

  hfile = new TFile(ROOTOutputFile.c_str(),"RECREATE","clusters");

}

void CalorimeterClusteringPerformancePlotter::processRunHeader( LCRunHeader* run) { 

  _nRun++;
} 

void CalorimeterClusteringPerformancePlotter::processEvent( LCEvent * evt ) { 

  // Process events in this range
  if(!((evt->getRunNumber()<firstRun && evt->getRunNumber()>lastRun) ||
       (evt->getRunNumber()==firstRun && evt->getEventNumber()<firstEventInFirstRun) ||
       (evt->getRunNumber()==lastRun && evt->getEventNumber()>lastEventInLastRun))) {

  typedef const std::vector<std::string> NameVec;
  NameVec* strVec = evt->getCollectionNames();

  bool trueClustersAreStored=false;
  for(NameVec::const_iterator name=strVec->begin(); name!=strVec->end(); name++){
    string sss=name->c_str();
    if(sss=="CalorimeterEnergyOrderedTrueClusters") {
      trueClustersAreStored=true;
    }
  }

  // Plot the grid showing the distribution of energy between true and reconstructed clusterd
  // if MC truth information is available
  
  if(trueClustersAreStored) {
    
    if(printAction) cout << "  - plotting energy distribution...." << endl;
    
    // Retrieve these collections
    LCCollection* orderedClusterVec=evt->getCollection("CalorimeterEnergyOrderedClusters");
    LCCollection* orderedTrueClusterVec=evt->getCollection("CalorimeterEnergyOrderedTrueClusters");
    LCCollection* trueVRecVec=evt->getCollection("CalorimeterEnergyDistribution");
    
    int i, j;
    int total_cluster_count=orderedClusterVec->getNumberOfElements();
    int total_truecluster_count=orderedTrueClusterVec->getNumberOfElements();
    gROOT->SetStyle("Plain");
    TCanvas *Performance = new TCanvas("Performance","",0,600,600,600);
    Performance->Divide(1,1);
    Performance->cd(1);
    
    // Declare the histogram...
    TH2F *TruvRec = new TH2F("TruvRec","",total_truecluster_count,1,1+total_truecluster_count,total_cluster_count,1,1+total_cluster_count);
    // ...and fill the grid with the entries determined above
    for(i=0;i<total_truecluster_count;i++) {
      LCFloatVec* trueVRec = dynamic_cast<LCFloatVec*>(trueVRecVec->getElementAt(i));
      for(j=0;j<total_cluster_count;j++) {
	TruvRec->Fill(i+1,j+1,100.*(*(trueVRec->begin()+j)));
      }
    }
    
    // Set axis titles
    TruvRec->GetXaxis()->SetTitle("True cluster ID");
    TruvRec->GetYaxis()->SetTitle("Reconstructed cluster ID");
    
    // Set some attributes
    TruvRec->SetStats(kFALSE);
    TruvRec->GetXaxis()->SetNdivisions(-total_truecluster_count);
    TruvRec->GetXaxis()->CenterLabels();
    TruvRec->GetXaxis()->CenterTitle();
    TruvRec->GetYaxis()->SetNdivisions(-total_cluster_count);
    TruvRec->GetYaxis()->CenterLabels();
    TruvRec->GetYaxis()->CenterTitle();
    TruvRec->GetXaxis()->SetLabelSize(0.03);
    TruvRec->GetXaxis()->SetTitleSize(0.03);
    TruvRec->GetYaxis()->SetLabelSize(0.03);
    TruvRec->GetYaxis()->SetTitleSize(0.03);
    TruvRec->GetXaxis()->SetTitleOffset(1.5);
    TruvRec->GetYaxis()->SetTitleOffset(1.5);
    TruvRec->GetXaxis()->SetLabelOffset(0.01);
    TruvRec->GetYaxis()->SetLabelOffset(0.01); 
    gPad->SetGrid();
    TruvRec->SetMarkerSize(1.3);
    TruvRec->Draw("text");
    TLatex l;
    l.SetTextAlign(21);
    l.SetNDC();
    l.SetTextSize(0.03);
    l.DrawLatex(0.5,0.94,"Distribution of event energy (%)");
    
    // Save the canvas to the ROOT output file and delete the histogram from memory
    Performance->Write();
    delete TruvRec;

    if(printAction) cout << "    --> OK" << endl;   
  }
  }

  _nEvt ++;
}



void CalorimeterClusteringPerformancePlotter::check( LCEvent * evt ) { 
  // nothing to check here - could be used to fill checkplots in reconstruction processor
}


void CalorimeterClusteringPerformancePlotter::end(){ 
  
  std::cout << "CalorimeterClusteringPerformancePlotter::end()  " << name() 
	    << " processed " << _nEvt << " events in " << _nRun << " runs "
	    << std::endl;

  hfile->Close();

}

