#include "CalorimeterClusteringPerformanceAnalyser.h"
#include "marlin/Global.h"
#include <iomanip>

#include "IMPL/LCCollectionVec.h"
#include "EVENT/Cluster.h"
#include "EVENT/LCFloatVec.h"
#include "UTIL/LCRelationNavigator.h"

using namespace lcio;
using namespace marlin;
using namespace std;


CalorimeterClusteringPerformanceAnalyser aCalorimeterClusteringPerformanceAnalyser;


CalorimeterClusteringPerformanceAnalyser::CalorimeterClusteringPerformanceAnalyser() : Processor("CalorimeterClusteringPerformanceAnalyser") {
  
  // Processor description
  _description = "CalorimeterClusteringPerformanceAnalyser calculates the quality of the cluster reconstruction, prints it to the screen if printAction is set to 1, and (optionally) writes this to the designated QualityFile";


  // Register steering parameters: name, description, class-variable, default value 
  registerProcessorParameter("QualityFile", 
			     "output file for quality",
			     _QualityFile,
			     std::string("./performance/MyQuality.out"));
  registerProcessorParameter("writeQuality", 
			     "write quality to file (0 = off; 1 = on)",
			     _writeQuality,
			     std::string("0"));

}


void CalorimeterClusteringPerformanceAnalyser::init() { 

  // Print processor parameters
  printParameters();

  // Set number of runs and events to 0
  _nRun = 0;
  _nEvt = 0;

  // Get parameters from steering file
  firstRun = Global::parameters->getIntVal("firstRun");
  lastRun = Global::parameters->getIntVal("lastRun");
  firstEventInFirstRun = Global::parameters->getIntVal("firstEventInFirstRun");
  lastEventInLastRun = Global::parameters->getIntVal("lastEventInLastRun");
  printAction = Global::parameters->getIntVal("printAction");
  QualityFile = parameters()->getStringVal("QualityFile");
  writeQuality = parameters()->getIntVal("writeQuality");

  out = fopen(QualityFile.c_str(),"a");
}

void CalorimeterClusteringPerformanceAnalyser::processRunHeader( LCRunHeader* run) { 

  _nRun++;
} 

void CalorimeterClusteringPerformanceAnalyser::processEvent( LCEvent * evt ) { 

  // Process events in this range
  if(!((evt->getRunNumber()<firstRun && evt->getRunNumber()>lastRun) ||
       (evt->getRunNumber()==firstRun && evt->getEventNumber()<firstEventInFirstRun) ||
       (evt->getRunNumber()==lastRun && evt->getEventNumber()>lastEventInLastRun))) {

  typedef const std::vector<std::string> NameVec;
  NameVec* strVec = evt->getCollectionNames();

  bool trueClustersAreStored=false;
  for(NameVec::const_iterator name=strVec->begin(); name!=strVec->end(); name++){
    string sss=name->c_str();
    if(sss=="CalorimeterEnergyOrderedTrueClusters") {
      trueClustersAreStored=true;
    }
  }
  
  // Evaluate the performance quality of the reconstruction if MC truth information is available

  if(trueClustersAreStored) {

    if(printAction) cout << "  - calculating performance...." << endl;

    // Create collections to store:
    // - the distribution of event energy between true and reconstructed clusters
    LCCollectionVec* trueVRecVec = new LCCollectionVec(LCIO::LCFLOATVEC);

    // Retrieve these collections
    LCCollection* orderedClusterVec=evt->getCollection("CalorimeterEnergyOrderedClusters");
    LCCollection* calibratedClusterRelVec=evt->getCollection("CalorimeterEnergyOrderedClusterRelationsToCalibratedClusters");
    LCCollection* orderedTrueClusterVec=evt->getCollection("CalorimeterEnergyOrderedTrueClusters");
    LCCollection* calibratedTrueClusterRelVec=evt->getCollection("CalorimeterEnergyOrderedTrueClusterRelationsToCalibratedTrueClusters");

    // Make the relations navigable
    LCRelationNavigator calibratedClusterRel(calibratedClusterRelVec);
    LCRelationNavigator calibratedTrueClusterRel(calibratedTrueClusterRelVec);

    int i, j, p, q;  
    int total_cluster_count=orderedClusterVec->getNumberOfElements(); 
    int total_truecluster_count=orderedTrueClusterVec->getNumberOfElements(); 
    float total_energy=0.;
    float energy_fraction[1+total_truecluster_count][1+total_cluster_count];
    float energy_fraction_max=0.;
    float energy_fraction_correct=0.;
    int cluster_usage[1+total_cluster_count];
    int truecluster_usage[1+total_truecluster_count];
    for(j=0;j<=total_cluster_count;j++) {
      cluster_usage[j]=0;
      for(i=0;i<=total_truecluster_count;i++) {
	truecluster_usage[i]=0;
	energy_fraction[i][j]=0.;
      }
    } 
    // Loop over energy-calibrated true clusters in order of energy (highest first, by construction)
    for(i=0;i<orderedTrueClusterVec->getNumberOfElements();i++) {
      Cluster* orderedTrueCluster = dynamic_cast<Cluster*>(orderedTrueClusterVec->getElementAt(i));
      Cluster* calibratedTrueCluster = dynamic_cast<Cluster*>(calibratedTrueClusterRel.getRelatedToObjects(orderedTrueCluster)[0]);
      // Loop over energy-calibrated reconstructed clusters in order of energy (highest first, by construction)
      for(j=0;j<orderedClusterVec->getNumberOfElements();j++) {
	Cluster* orderedCluster = dynamic_cast<Cluster*>(orderedClusterVec->getElementAt(j));
	Cluster* calibratedCluster = dynamic_cast<Cluster*>(calibratedClusterRel.getRelatedToObjects(orderedCluster)[0]);
	// Loop over this true cluster's hits
	for(p=0;p<int(calibratedTrueCluster->getCalorimeterHits().size());p++) {
	  CalorimeterHit* trueHit = calibratedTrueCluster->getCalorimeterHits()[p];
	  float energy=calibratedTrueCluster->getHitContributions()[p];
	  // Loop over this reconstructed cluster's hits
	  for(q=0;q<int(calibratedCluster->getCalorimeterHits().size());q++) {
	    CalorimeterHit* recoHit = calibratedCluster->getCalorimeterHits()[q];
	    // If this hit is common to both this true cluster and this reconstructed cluster, add the hit's 
	    // energy contribution to the true cluster to the appropriate point on the grid charting the 
	    // distribution of event energy between true and reconstructed clusters
	    if(recoHit==trueHit) {
	      energy_fraction[i+1][j+1]+=energy;
	      total_energy+=energy;
	    }
	  }
	}
      }
    }
    // Normalise the entries in the grid to the total event energy and add them to the collection
    for(i=0;i<orderedTrueClusterVec->getNumberOfElements();i++) {
      LCFloatVec* trueVRec = new LCFloatVec;
      for(j=0;j<orderedClusterVec->getNumberOfElements();j++) {
	energy_fraction[i+1][j+1]/=total_energy;
	trueVRec->push_back(energy_fraction[i+1][j+1]);
      }
      trueVRecVec->push_back(trueVRec);
    }
    // If there are no calorimeter hits registered, the performance is perfect!
    if(orderedTrueClusterVec->getNumberOfElements()==0) {
      energy_fraction_correct=1.0;
    }
    // Otherwise (more usually) find out the fraction of event energy correctly assigned
    else {
      // Loop over the columns and rows of the energy-distribution grid
      for(p=1;p<=orderedTrueClusterVec->getNumberOfElements() && p<=orderedClusterVec->getNumberOfElements();p++) {
	// Initialise the correctly assigned event energy fraction to zero
	energy_fraction_max=0.;
	// Loop over reconstructed clusters ids 
	for(j=1;j<=orderedClusterVec->getNumberOfElements();j++) {
	  // Loop over true cluster ids
	  for(i=1;i<=orderedTrueClusterVec->getNumberOfElements();i++) {
	    // Find the highest remaining entry in the grid which does not lie in a column nor row from which
	    // an entry has already been extracted (in order to pick out the degree of 1:1 correspondence between 
	    // this true-reconstructed cluster pair)
	    if(truecluster_usage[i]==0 && cluster_usage[j]==0 && energy_fraction[i][j] > energy_fraction_max) {
	      energy_fraction_max=energy_fraction[i][j];
	    }
	  }
	}
	// Loop over reconstructed clusters ids 
	for(j=1;j<=orderedClusterVec->getNumberOfElements();j++) {
	  // Loop over true cluster ids
	  for(i=1;i<=orderedTrueClusterVec->getNumberOfElements();i++) {
	    // Assume this entry in the grid gives the energy that is correctly assigned between this
	    // true-reconstructed cluster pair; add this to the fraction of correctly assigned event energy 
	    if(energy_fraction[i][j]==energy_fraction_max && truecluster_usage[i]==0 && cluster_usage[j]==0) {
	      energy_fraction_correct+=energy_fraction_max;
	      // Remove this column and row of the grid from further consideration
	      truecluster_usage[i]=1;
	      cluster_usage[j]=1;
	    }
	  }
	}
      }
    }

    // Append the quality (= total fraction of event energy assigned in 1:1 correspondence between 
    // true and reconstructed clusters) for this event to the designated file, if required (useful 
    // when accumulating statistics over many events in a MC sample)
    if(writeQuality) {
      fprintf(out,"%10i %10i %10.4f\n",evt->getRunNumber(),evt->getEventNumber(),energy_fraction_correct);
    } 
    if(printAction) cout << "    --> quality = " 
			 << setiosflags(ios::fixed) << setprecision(2) << 100.*energy_fraction_correct 
			 << "%" << endl;
 
    // Store the collections
    evt->addCollection(trueVRecVec,"CalorimeterEnergyDistribution");

    // Don't write these to the LCIO output file
    trueVRecVec->setTransient();

    if(printAction) cout << "    --> OK" << endl;
  }
  }

  _nEvt ++;
}



void CalorimeterClusteringPerformanceAnalyser::check( LCEvent * evt ) { 
  // nothing to check here - could be used to fill checkplots in reconstruction processor
}


void CalorimeterClusteringPerformanceAnalyser::end(){ 
  
  std::cout << "CalorimeterClusteringPerformanceAnalyser::end()  " << name() 
	    << " processed " << _nEvt << " events in " << _nRun << " runs "
	    << std::endl;

  fclose(out);
}

