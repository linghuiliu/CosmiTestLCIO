#include "CalorimeterClusterCalibrator.h"
#include "marlin/Global.h"

#include "IMPL/LCCollectionVec.h"
#include "IMPL/ClusterImpl.h"
#include "IMPL/LCFlagImpl.h"

using namespace lcio;
using namespace marlin;
using namespace std;


CalorimeterClusterCalibrator aCalorimeterClusterCalibrator;


CalorimeterClusterCalibrator::CalorimeterClusterCalibrator() : Processor("CalorimeterClusterCalibrator") {
  
  // Processor description
  _description = "CalorimeterClusterCalibrator adds calibrated energies to the clusters";
  
}


void CalorimeterClusterCalibrator::init() { 

  // Set number of runs and events to 0
  _nRun = 0;
  _nEvt = 0;
  
  // Get parameters from steering file
  firstRun = Global::parameters->getIntVal("firstRun");
  lastRun = Global::parameters->getIntVal("lastRun");
  firstEventInFirstRun = Global::parameters->getIntVal("firstEventInFirstRun");
  lastEventInLastRun = Global::parameters->getIntVal("lastEventInLastRun");
  printAction = Global::parameters->getIntVal("printAction");
  mode = Global::parameters->getStringVal("mode");
  normalisation = Global::parameters->getFloatVal("normalisation");
  ecalLayerRange1 = Global::parameters->getIntVal("ecalLayerRange1");
  ecalLayerRange2 = Global::parameters->getIntVal("ecalLayerRange2");
  ecalLayerRange3 = Global::parameters->getIntVal("ecalLayerRange3");
  c_ecal1 = Global::parameters->getFloatVal("c_ecal1");
  c_ecal2 = Global::parameters->getFloatVal("c_ecal2");
  c_ecal3 = Global::parameters->getFloatVal("c_ecal3");
  c_hcal = Global::parameters->getFloatVal("c_hcal");

}

void CalorimeterClusterCalibrator::processRunHeader( LCRunHeader* run) { 

  _nRun++;
} 

void CalorimeterClusterCalibrator::processEvent( LCEvent * evt ) { 

  // Process events in this range
  if(!((evt->getRunNumber()<firstRun && evt->getRunNumber()>lastRun) ||
       (evt->getRunNumber()==firstRun && evt->getEventNumber()<firstEventInFirstRun) ||
       (evt->getRunNumber()==lastRun && evt->getEventNumber()>lastEventInLastRun))) {

  if(printAction) cout << "  - adding calibrated energies to clusters...." << endl;

  // Create collections to store:
  // - the stage 4 clusters with calibrated energies added
  LCCollectionVec* calibratedClusterVec = new LCCollectionVec(LCIO::CLUSTER);

  // Set some parameters for the clusters collection
  StringVec subdetNames;
  subdetNames.resize(2);
  subdetNames[0]="Ecal";
  subdetNames[1]="Hcal";
  calibratedClusterVec->parameters().setValues("CalorimeterSubdetectorNames",subdetNames);

  // Retrieve these collections
  LCCollection* clusterVec=evt->getCollection("CalorimeterStage4Clusters");
  LCCollection* hitVec=evt->getCollection("CalorimeterHits");

  int i, j;
  float w=0.;
  float calibratedHitEnergy=0.;

  // Get the MIP energy values used in creating the above-threshold hits
  StringVec floatKeys;
  FloatVec floatVec;
  hitVec->getParameters().getFloatKeys(floatKeys);
  float ecalMip=hitVec->getParameters().getFloatVals("CalorimeterMipEnergyValues",floatVec)[0]; 
  float hcalMip=hitVec->getParameters().getFloatVals("CalorimeterMipEnergyValues",floatVec)[1]; 

  // Loop over clusters and create a new cluster for each to which the calibrated energy can be added
  // and add this to the collection
  for(i=0;i<clusterVec->getNumberOfElements();i++) {
    Cluster* cluster = dynamic_cast<Cluster*>(clusterVec->getElementAt(i));
    ClusterImpl* calibratedCluster = new ClusterImpl;
    calibratedClusterVec->push_back(calibratedCluster);
    // Copy the cluster-fragments contributing to the original cluster
    for(j=0;j<int(cluster->getClusters().size());j++) {
      calibratedCluster->addCluster(cluster->getClusters()[j]);
    }  
    // Initialise the calibrated cluster energy and the separate Ecal and Hcal contributions to zero
    calibratedCluster->setEnergy(0.);
    calibratedCluster->subdetectorEnergies().resize(2);
    calibratedCluster->subdetectorEnergies()[0]=0.;
    calibratedCluster->subdetectorEnergies()[1]=0.;
    // Loop over the original cluster's hits
    for(j=0;j<int(cluster->getCalorimeterHits().size());j++) {
      CalorimeterHit* hit = dynamic_cast<CalorimeterHit*>(cluster->getCalorimeterHits()[j]);
      float contribution=cluster->getHitContributions()[j];
      // If detector operates with an Ecal
      if(hit->getType()==0) {
	int layer=1+hit->getCellID0()/16777216;
	// - in analogue mode
	if(mode=="a/a" || mode=="a/d") {
	  w=contribution/(ecalMip*normalisation);
	}
	// - in digital mode
	else if(mode=="d/a" || mode=="d/d") {
	  w=1./normalisation;
	}
	// Calibrate hit energy if in Ecal layer-range [1,ecalLayerRange1]...
	if(layer<=ecalLayerRange1) {
	  calibratedHitEnergy=w*c_ecal1;
	}
	// Calibrate hit energy if in Ecal layer-range [1+ecalLayerRange1,ecalLayerRange2]...
	else if(layer<=ecalLayerRange2) {
	  calibratedHitEnergy=w*c_ecal2;
	}
	// Calibrate hit energy if in Ecal layer-range [1+ecalLayerRange2,ecalLayerRange3]...
	else if(layer<=ecalLayerRange3) {
	  calibratedHitEnergy=w*c_ecal3;
	}
	calibratedCluster->subdetectorEnergies()[0]+=calibratedHitEnergy;
      }
      // ...and with an Hcal
      else {
	// - in analogue mode
	if(mode=="a/a" || mode=="d/a") {
	  w=contribution/(hcalMip*normalisation);
	}
	// - in digital mode
	else if(mode=="a/d" || mode=="d/d") {
	  w=1./normalisation;
	}
	// Calibrate hit energy if in Hcal
	calibratedHitEnergy=w*c_hcal;
	calibratedCluster->subdetectorEnergies()[1]+=calibratedHitEnergy;
      }
      // Copy the hit and its energy to the calibrated cluster and set the calibrated cluster energy
      calibratedCluster->addHit(hit,calibratedHitEnergy);
      calibratedCluster->setEnergy(calibratedCluster->getEnergy()+calibratedHitEnergy);
    }
  }

  // Save the calibrated cluster hits when the clusters collection is written to the LCIO output file
  LCFlagImpl chflag(0);
  chflag.setBit(LCIO::CLBIT_HITS);
  calibratedClusterVec->setFlag(chflag.getFlag());

  // Store the collections
  evt->addCollection(calibratedClusterVec,"CalorimeterCalibratedClusters");

  if(printAction) cout << "    --> OK" << endl;
  }

  _nEvt ++;
}

void CalorimeterClusterCalibrator::check( LCEvent * evt ) { 
  // nothing to check here - could be used to fill checkplots in reconstruction processor
}


void CalorimeterClusterCalibrator::end(){ 
  
  std::cout << "CalorimeterClusterCalibrator::end()  " << name() 
	    << " processed " << _nEvt << " events in " << _nRun << " runs "
	    << std::endl;

}

