#include "CalorimeterClusterAnalyser.h"
#include "marlin/Global.h"
#include <iomanip>

#include "IMPL/LCCollectionVec.h"
#include "IMPL/ClusterImpl.h"
#include "IMPL/LCRelationImpl.h"
#include "EVENT/LCIntVec.h"
#include "UTIL/LCRelationNavigator.h"

using namespace lcio;
using namespace marlin;
using namespace std;


CalorimeterClusterAnalyser aCalorimeterClusterAnalyser;


CalorimeterClusterAnalyser::CalorimeterClusterAnalyser() : Processor("CalorimeterClusterAnalyser") {
  
  // Processor description
  _description = "CalorimeterClusterAnalyser orders clusters by calibrated energy and (optionally) prints them ordered by energy rank within each pseudostave";

}


void CalorimeterClusterAnalyser::init() { 

  // Set number of runs and events to 0
  _nRun = 0;
  _nEvt = 0;

  // Get parameters from steering file
  firstRun = Global::parameters->getIntVal("firstRun");
  lastRun = Global::parameters->getIntVal("lastRun");
  firstEventInFirstRun = Global::parameters->getIntVal("firstEventInFirstRun");
  lastEventInLastRun = Global::parameters->getIntVal("lastEventInLastRun");
  printAction = Global::parameters->getIntVal("printAction");

}

void CalorimeterClusterAnalyser::processRunHeader( LCRunHeader* run) { 

  _nRun++;
} 

void CalorimeterClusterAnalyser::processEvent( LCEvent * evt ) { 

  // Process events in this range
  if(!((evt->getRunNumber()<firstRun && evt->getRunNumber()>lastRun) ||
       (evt->getRunNumber()==firstRun && evt->getEventNumber()<firstEventInFirstRun) ||
       (evt->getRunNumber()==lastRun && evt->getEventNumber()>lastEventInLastRun))) {

  if(printAction) cout << "  - ordering clusters by calibrated energy...." << endl;
  
  // Create collections to store:
  // - the calibrated-energy-ordered clusters
  LCCollectionVec* orderedClusterVec = new LCCollectionVec(LCIO::CLUSTER);
  // - the pseudostave in which most of each cluster's energy lies (runs in parallel 
  //   with orderedClusterVec)
  LCCollectionVec* pseudostaveOfOrderedClusterVec = new LCCollectionVec(LCIO::LCINTVEC);
  // - the relation between the ordered cluster and the cluster (runs in parallel 
  //   with orderedClusterVec)
  LCCollectionVec* calibratedClusterRelVec = new LCCollectionVec(LCIO::LCRELATION);

  // Set the relation from and to types for the clusters
  calibratedClusterRelVec->parameters().setValue( "RelationFromType",LCIO::CLUSTER);
  calibratedClusterRelVec->parameters().setValue( "RelationToType",LCIO::CLUSTER);

  // Retrieve these collections
  LCCollection* clusterVec=evt->getCollection("CalorimeterCalibratedClusters");
  LCCollection* hitVec=evt->getCollection("CalorimeterHits");

  int barrelSymmetry=hitVec->getParameters().getIntVal("CalorimeterBarrelSymmetry");
  float phi_1=hitVec->getParameters().getFloatVal("CalorimeterPhi_1");
  std::string detectorType=hitVec->getParameters().getStringVal("CalorimeterDetectorType");
  int i, j, p, u;
  int nhits_ecal, nhits_hcal;
  bool OK;
  float emax, ecluster_pseudostave, ecluster_pseudostave_max;
  int pseudostave_max=2+barrelSymmetry;
  if(detectorType=="prototype") pseudostave_max=1;
  int pseudostave_ecluster_most;

  // Continue as long as there are hits in the calorimeter
  if(clusterVec->getNumberOfElements()>0) {
    emax=-1.;
    // Loop over clusters...
    for(i=0;i<clusterVec->getNumberOfElements();i++){
      Cluster* cluster = dynamic_cast<Cluster*>(clusterVec->getElementAt(i));
      // ...and find the energy of the cluster with the highest energy
      if(cluster->getEnergy() > emax) {
	emax=cluster->getEnergy();
      }
    }
    // Loop over clusters...
    for(i=0;i<clusterVec->getNumberOfElements();i++){
      Cluster* cluster = dynamic_cast<Cluster*>(clusterVec->getElementAt(i));
      // ...and create a new cluster and add it to the energy-ordered collection if the cluster's
      // energy is equal to the highest energy; also add a pointer from this energy-ordered 
      // cluster to the original (unordered) cluster
      if(cluster->getEnergy()==emax) {
	ClusterImpl* orderedCluster = new ClusterImpl;
	orderedClusterVec->push_back(orderedCluster);
	calibratedClusterRelVec->addElement(new LCRelationImpl(orderedCluster,cluster));
      }
    }
    // Repeat to create a collection of all clusters ranked by energy
    do {
      emax=-1.;
      Cluster* orderedCluster = dynamic_cast<Cluster*>(orderedClusterVec->getElementAt(orderedClusterVec->getNumberOfElements()-1));
      LCRelationNavigator calibratedClusterRel(calibratedClusterRelVec);
      Cluster* calibratedCluster = dynamic_cast<Cluster*>(calibratedClusterRel.getRelatedToObjects(orderedCluster)[0]);
      for(i=0;i<clusterVec->getNumberOfElements();i++){
	Cluster* cluster = dynamic_cast<Cluster*>(clusterVec->getElementAt(i));
	if(cluster->getEnergy() > emax && cluster->getEnergy() < calibratedCluster->getEnergy()) {
	  emax=cluster->getEnergy();
	}
      }
      for(i=0;i<clusterVec->getNumberOfElements();i++){
	Cluster* cluster = dynamic_cast<Cluster*>(clusterVec->getElementAt(i));
	if(cluster->getEnergy()==emax) {
	  ClusterImpl* orderedCluster = new ClusterImpl;
	  orderedClusterVec->push_back(orderedCluster);	
	  calibratedClusterRelVec->addElement(new LCRelationImpl(orderedCluster,cluster));
	}
      }
    }
    while(orderedClusterVec->getNumberOfElements()<clusterVec->getNumberOfElements());
  }
  LCRelationNavigator calibratedClusterRel(calibratedClusterRelVec); 
  
  if(printAction) cout << "    --> OK" << endl << "  - allocating clusters to pseudostaves...." << endl;

  // Loop over the energy-ordered clusters
  for(j=0;j<orderedClusterVec->getNumberOfElements();j++) {
    Cluster* orderedCluster = dynamic_cast<Cluster*>(orderedClusterVec->getElementAt(j));
    Cluster* calibratedCluster = dynamic_cast<Cluster*>(calibratedClusterRel.getRelatedToObjects(orderedCluster)[0]);
    ecluster_pseudostave_max=0.;
    // Loop over pseudostaves
    for(p=1;p<=pseudostave_max;p++) {
      ecluster_pseudostave=0.;
      // Loop over the hits in this cluster...
      for(u=0;u<int(calibratedCluster->getCalorimeterHits().size());u++) {
	int pseudostave=1+(calibratedCluster->getCalorimeterHits()[u]->getCellID1()%16777216)/8;
	float contribution=calibratedCluster->getHitContributions()[u];
	// ...and accumulate the energy of the cluster deposited in the current pseudostave
	if(pseudostave==p) {
	  ecluster_pseudostave+=contribution;
	}
      }
      // Determine the pseudostave in which most of the cluster's energy is deposited
      if(ecluster_pseudostave>ecluster_pseudostave_max) {
	ecluster_pseudostave_max=ecluster_pseudostave;
	pseudostave_ecluster_most=p;
      }
    }
    // Add this pseudostave id to the collection
    LCIntVec* pseudostaveOfOrderedCluster = new LCIntVec; 
    pseudostaveOfOrderedCluster->push_back(pseudostave_ecluster_most);
    pseudostaveOfOrderedClusterVec->push_back(pseudostaveOfOrderedCluster);
  }

  if(printAction) cout << "    --> OK" << endl 
		       << "  - printing reconstructed clusters whose major energy deposit is in...." 
		       << endl;

  // Evaluate the results of clustering

  if(printAction) { 
    // Loop over pseudostaves
    for(p=1;p<=2+barrelSymmetry;p++) {
      OK=true;
      // Loop over energy-calibrated clusters in order of energy (highest first, by construction)... 
      for(i=0;i<orderedClusterVec->getNumberOfElements();i++) {
	LCIntVec* pseudostaveOfOrderedCluster = dynamic_cast<LCIntVec*>(pseudostaveOfOrderedClusterVec->getElementAt(i));
	Cluster* orderedCluster = dynamic_cast<Cluster*>(orderedClusterVec->getElementAt(i));
	Cluster* calibratedCluster = dynamic_cast<Cluster*>(calibratedClusterRel.getRelatedToObjects(orderedCluster)[0]);
	// ...and select those whose major energy deposit is in the current pseudostave
	if(*pseudostaveOfOrderedCluster->begin()==p) {
	  nhits_ecal=0;
	  // Count the number Ecal hits and the number of Hcal hits in each such cluster 
	  for(j=0;j<int(calibratedCluster->getCalorimeterHits().size());j++) {
	    if(calibratedCluster->getCalorimeterHits()[j]->getType()==0) {
	      nhits_ecal++;
	    }
	  }
	  nhits_hcal=calibratedCluster->getCalorimeterHits().size() - nhits_ecal;
	  // Print attributes for the cluster
	  if(OK) {
	    cout << endl << "    --> pseudostave " << p;
	    if(p<=barrelSymmetry) {
	      cout << " (pseudobarrel pseudostave centred at ";
	      phi_1+360.*(p-1)/barrelSymmetry < 360 ? 
		cout << setiosflags(ios::fixed) << setprecision(1) << phi_1+360.*(p-1)/barrelSymmetry :
		cout << setiosflags(ios::fixed) << setprecision(1) << phi_1-360.+360.*(p-1)/barrelSymmetry;
	      cout << " deg from x-axis):-" << endl;
	    }
	    else if(p==barrelSymmetry+1) cout << " (left-hand (z<0) pseudoendcap):-" << endl;
	    else if(p==barrelSymmetry+2) cout << " (right-hand (z>0) pseudoendcap):-" << endl;
	    OK=false;
	  }
	  cout << "                   cluster " << setw(3) << i+1
	       << setw(8) << setiosflags(ios::fixed) 
	       << setprecision(3) << calibratedCluster->getEnergy() << " MeV "; 
	  calibratedCluster->getCalorimeterHits().size()==1 ? cout << "   1 hit " : 
	    cout << setw(4) << calibratedCluster->getCalorimeterHits().size() << " hits";
	  cout << "  [ Ecal" << setw(8) << setiosflags(ios::fixed) 
	       << setprecision(3) << calibratedCluster->getSubdetectorEnergies()[0] << " MeV ";
	  nhits_ecal==1 ? cout << "   1 hit " : cout << setw(4) << nhits_ecal << " hits";
	  cout << ";  Hcal" << setw(8) << setiosflags(ios::fixed) 
	       << setprecision(3) << calibratedCluster->getSubdetectorEnergies()[1] << " MeV ";
	  nhits_hcal==1 ? cout << "   1 hit  ]" : cout << setw(4) << nhits_hcal << " hits ]";
	  cout << endl; 
	}
      }
    }
  }

  // Store the collections
  evt->addCollection(orderedClusterVec,"CalorimeterEnergyOrderedClusters");
  evt->addCollection(pseudostaveOfOrderedClusterVec,"CalorimeterEnergyOrderedClusterPseudostaves");
  evt->addCollection(calibratedClusterRelVec,"CalorimeterEnergyOrderedClusterRelationsToCalibratedClusters");

  // Don't write these to the LCIO output file
  orderedClusterVec->setTransient();
  pseudostaveOfOrderedClusterVec->setTransient();
  calibratedClusterRelVec->setTransient();

  if(printAction) cout << "    --> OK" << endl;
  }
  
  _nEvt ++;
}



void CalorimeterClusterAnalyser::check( LCEvent * evt ) { 
  // nothing to check here - could be used to fill checkplots in reconstruction processor
}


void CalorimeterClusterAnalyser::end(){ 
  
  std::cout << "CalorimeterClusterAnalyser::end()  " << name() 
	    << " processed " << _nEvt << " events in " << _nRun << " runs "
	    << std::endl;

}

