#include "CalorimeterClusterPlotter.h"
#include "marlin/Global.h"

#include <TStyle.h>
#include <TROOT.h>
#include <TCanvas.h>
#include <TH2F.h>
#include <TH3F.h>
#include <TMarker.h>
#include <TPolyMarker3D.h>
#include <TLatex.h>

#include "IMPL/LCCollectionVec.h"
#include "EVENT/Cluster.h"
#include "EVENT/LCIntVec.h"
#include "UTIL/LCRelationNavigator.h"

using namespace lcio;
using namespace marlin;
using namespace std;


CalorimeterClusterPlotter aCalorimeterClusterPlotter;


CalorimeterClusterPlotter::CalorimeterClusterPlotter() : Processor("CalorimeterClusterPlotter") {
  
  // Processor description
  _description = "CalorimeterClusterPlotter creates a plot of the clusters colour-coded by calibrated energy rank within each pseudostave in the designated ROOTOutputFile (N.B. this processor has no effect if ROOT is not installed)";

}


void CalorimeterClusterPlotter::init() { 

  // Set number of runs and events to 0
  _nRun = 0;
  _nEvt = 0;

  // Get parameters from steering file
  firstRun = Global::parameters->getIntVal("firstRun");
  lastRun = Global::parameters->getIntVal("lastRun");
  firstEventInFirstRun = Global::parameters->getIntVal("firstEventInFirstRun");
  lastEventInLastRun = Global::parameters->getIntVal("lastEventInLastRun");
  printAction = Global::parameters->getIntVal("printAction");
  plotPseudostave = Global::parameters->getIntVal("plotPseudostave");
  xmin = Global::parameters->getFloatVal("xmin");
  xmax = Global::parameters->getFloatVal("xmax");
  ymin = Global::parameters->getFloatVal("ymin");
  ymax = Global::parameters->getFloatVal("ymax");
  zmin = Global::parameters->getFloatVal("zmin");
  zmax = Global::parameters->getFloatVal("zmax");
  ROOTOutputFile = Global::parameters->getStringVal("ROOTOutputFile");

  hfile = new TFile(ROOTOutputFile.c_str(),"RECREATE","clusters");

}

void CalorimeterClusterPlotter::processRunHeader( LCRunHeader* run) { 

  _nRun++;
} 

void CalorimeterClusterPlotter::processEvent( LCEvent * evt ) { 

  // Process events in this range
  if(!((evt->getRunNumber()<firstRun && evt->getRunNumber()>lastRun) ||
       (evt->getRunNumber()==firstRun && evt->getEventNumber()<firstEventInFirstRun) ||
       (evt->getRunNumber()==lastRun && evt->getEventNumber()>lastEventInLastRun))) {

  if(printAction) cout << "  - plotting clusters (only one hit per cell allowed)...." << endl; 
  
  // Create collections to store:
  // - the rank of each cluster within its pseudostave (runs in parallel  with orderedClusterVec) 
  LCCollectionVec* rankInPseudostaveOfOrderedClusterVec = new LCCollectionVec(LCIO::LCINTVEC);

  // Retrieve these collections
  LCCollection* orderedClusterVec=evt->getCollection("CalorimeterEnergyOrderedClusters");
  LCCollection* calibratedClusterRelVec=evt->getCollection("CalorimeterEnergyOrderedClusterRelationsToCalibratedClusters");
  LCCollection* pseudostaveOfOrderedClusterVec=evt->getCollection("CalorimeterEnergyOrderedClusterPseudostaves");
  LCCollection* hitVec=evt->getCollection("CalorimeterHits");

  // Make the relation navigable
  LCRelationNavigator calibratedClusterRel(calibratedClusterRelVec);

  int barrelSymmetry=hitVec->getParameters().getIntVal("CalorimeterBarrelSymmetry");
  std::string detectorType=hitVec->getParameters().getStringVal("CalorimeterDetectorType");
  int i, j, p, u;
  int pseudostave_max=2+barrelSymmetry;
  if(detectorType=="prototype") pseudostave_max=1;
  int rank[1+pseudostave_max];
  int plot_cluster_stores[1+pseudostave_max];
  for(p=1;p<=pseudostave_max;p++) {
    rank[p]=0;
    plot_cluster_stores[p]=0;
  }
  int marker;
  float markerSize;

  // Loop over the energy-ordered clusters
  for(i=0;i<orderedClusterVec->getNumberOfElements();i++) {
    LCIntVec* pseudostaveOfOrderedCluster = dynamic_cast<LCIntVec*>(pseudostaveOfOrderedClusterVec->getElementAt(i)); 
    LCIntVec* rankInPseudostaveOfOrderedCluster = new LCIntVec;
    // Loop over pseudostaves
    for(p=1;p<=pseudostave_max;p++) {
      // Determine the rank of this cluster among clusters that deposit most of their energy in the 
      // current pseudostave
      if(*pseudostaveOfOrderedCluster->begin()==p) {
	rankInPseudostaveOfOrderedCluster->push_back(++rank[p]);
      }
    }
    // Add this rank to the collection
    rankInPseudostaveOfOrderedClusterVec->push_back(rankInPseudostaveOfOrderedCluster);
  }

  // Plot reconstructed clusters in different colours, correlating colour with
  // descending cluster energy within a pseudostave for clusters whose major 
  // energy deposit is in that pseudostave

  gROOT->SetStyle("Plain");
  TCanvas *Reconstruction = new TCanvas("Reconstruction","Reconstruction",0,600,600,600);
  gStyle->SetTitleBorderSize(1);
  gStyle->SetTitleFillColor(0);

  // Divide the canvas in four
  Reconstruction->Divide(2,2);
 
  // Declare the histograms
  TH3F *XYZcls = new TH3F("x-y-z (reconstruction)","x-y-z",5,xmin,xmax,5,ymin,ymax,5,zmin,zmax);    
  TH2F *XZcls = new TH2F("x-z (reconstruction)","x-z",5,xmin,xmax,5,zmin,zmax);
  TH2F *ZYcls = new TH2F("z-y (reconstruction)","z-y",5,zmin,zmax,5,ymin,ymax);
  TH2F *XYcls = new TH2F("x-y (reconstruction)","x-y",5,xmin,xmax,5,ymin,ymax);
 
  // Set axis titles
  XYZcls->GetXaxis()->SetTitle("x /m");
  XYZcls->GetYaxis()->SetTitle("y /m");
  XYZcls->GetZaxis()->SetTitle("z /m");
  XZcls->GetXaxis()->SetTitle("x /m");
  XZcls->GetYaxis()->SetTitle("z /m");
  ZYcls->GetXaxis()->SetTitle("z /m");
  ZYcls->GetYaxis()->SetTitle("y /m");
  XYcls->GetXaxis()->SetTitle("x /m");
  XYcls->GetYaxis()->SetTitle("y /m");

  float labelSize=0.05;
  float titleSize=0.05;

  // Set some attributes
  XYZcls->GetXaxis()->SetLabelSize(labelSize);
  XYZcls->GetXaxis()->SetTitleSize(titleSize);
  XYZcls->GetYaxis()->SetLabelSize(labelSize);
  XYZcls->GetYaxis()->SetTitleSize(titleSize);
  XYZcls->GetZaxis()->SetLabelSize(labelSize);
  XYZcls->GetZaxis()->SetTitleSize(titleSize);
  XYZcls->GetXaxis()->SetTitleOffset(1.75);
  XYZcls->GetYaxis()->SetTitleOffset(1.75);
  XYZcls->GetZaxis()->SetTitleOffset(1.15);
  XYZcls->SetStats(kFALSE);      
 
  XZcls->GetXaxis()->SetLabelSize(labelSize);
  XZcls->GetXaxis()->SetTitleSize(titleSize);
  XZcls->GetYaxis()->SetLabelSize(labelSize);
  XZcls->GetYaxis()->SetTitleSize(titleSize);
  XZcls->GetZaxis()->SetLabelSize(labelSize);
  XZcls->GetZaxis()->SetTitleSize(titleSize);
  XZcls->GetXaxis()->SetTitleOffset(1.00);
  XZcls->GetYaxis()->SetTitleOffset(1.10);
  XZcls->SetStats(kFALSE);
 
  ZYcls->GetXaxis()->SetLabelSize(labelSize);
  ZYcls->GetXaxis()->SetTitleSize(titleSize);
  ZYcls->GetYaxis()->SetLabelSize(labelSize);
  ZYcls->GetYaxis()->SetTitleSize(titleSize);
  ZYcls->GetZaxis()->SetLabelSize(labelSize);
  ZYcls->GetZaxis()->SetTitleSize(titleSize);
  ZYcls->GetXaxis()->SetTitleOffset(1.00);
  ZYcls->GetYaxis()->SetTitleOffset(1.10);
  ZYcls->SetStats(kFALSE);
  
  XYcls->GetXaxis()->SetLabelSize(labelSize);
  XYcls->GetXaxis()->SetTitleSize(titleSize);
  XYcls->GetYaxis()->SetLabelSize(labelSize);
  XYcls->GetYaxis()->SetTitleSize(titleSize);
  XYcls->GetZaxis()->SetLabelSize(labelSize);
  XYcls->GetZaxis()->SetTitleSize(titleSize);
  XYcls->GetXaxis()->SetTitleOffset(1.00);
  XYcls->GetYaxis()->SetTitleOffset(1.10);
  XYcls->SetStats(kFALSE);

  // Draw the (empty) histograms
  Reconstruction->cd(1);
  XYZcls->Draw( );
  Reconstruction->cd(2);
  XZcls->Draw( );
  Reconstruction->cd(3);
  ZYcls->Draw( );
  Reconstruction->cd(4);
  XYcls->Draw( );

  // Loop over pseudostaves
  for(p=1;p<=pseudostave_max;p++) {
    // Plot only the hits in the chosen pseudostave
    if(plotPseudostave==p || plotPseudostave==0) {
      // Loop over the energy-ordered clusters
      for(i=0;i<orderedClusterVec->getNumberOfElements();i++) {
	Cluster* orderedCluster = dynamic_cast<Cluster*>(orderedClusterVec->getElementAt(i));
	Cluster* calibratedCluster = dynamic_cast<Cluster*>(calibratedClusterRel.getRelatedToObjects(orderedCluster)[0]);
	LCIntVec* pseudostaveOfOrderedCluster = dynamic_cast<LCIntVec*>(pseudostaveOfOrderedClusterVec->getElementAt(i));
	LCIntVec* rankInPseudostaveOfOrderedCluster = dynamic_cast<LCIntVec*>(rankInPseudostaveOfOrderedClusterVec->getElementAt(i));
	int pseudostaveOfCluster=*pseudostaveOfOrderedCluster->begin();
	// Loop over this cluster's hits
	for(u=0;u<int(calibratedCluster->getCalorimeterHits().size());u++) {
	  CalorimeterHit* hit = dynamic_cast<CalorimeterHit*>(calibratedCluster->getCalorimeterHits()[u]);
	  int pseudostaveOfHit=1+(hit->getCellID1()%16777216)/8;
	  // If the hit is in the current pseudostave:
	  if(pseudostaveOfHit==p) {
	    plot_cluster_stores[p]++;
	    int rank=*rankInPseudostaveOfOrderedCluster->begin();
	    float pos[3];
	    for(j=0;j<3;j++) {
	      pos[j]=hit->getPosition()[j]/1000.;
	    }
	    // - use a dot to mark the position if the cluster's main energy deposit is in this pseudostave
	    if(pseudostaveOfCluster==p) { 
	      marker=20;
	      markerSize=0.25;
	    }
	    // - use a cross to mark the position if the cluster's main energy deposit is in another pseudostave
	    else {
	      marker=5;
	      markerSize=0.5;
	    }
	    TPolyMarker3D *mxyz = new TPolyMarker3D(1,marker);
	    TMarker *mxz = new TMarker(pos[0],pos[2],marker);
	    TMarker *mzy = new TMarker(pos[2],pos[1],marker);
	    TMarker *mxy = new TMarker(pos[0],pos[1],marker);
	    mxyz->SetMarkerSize(markerSize);
	    mxz->SetMarkerSize(markerSize);
	    mzy->SetMarkerSize(markerSize);
	    mxy->SetMarkerSize(markerSize);
	    mxyz->SetPoint(0,pos[0],pos[1],pos[2]);
	    if(rank<10) {
	      mxyz->SetMarkerColor(rank);
	      mxz->SetMarkerColor(rank);
	      mzy->SetMarkerColor(rank);
	      mxy->SetMarkerColor(rank);
	    }
	    else {  // skip white in the colour palette
	      mxyz->SetMarkerColor(rank+1);
	      mxz->SetMarkerColor(rank+1);
	      mzy->SetMarkerColor(rank+1);
	      mxy->SetMarkerColor(rank+1);
	    }
	    /*
	    if(i==1) {
	      rank=2;
	      mxyz->SetMarkerColor(rank);
	      mxz->SetMarkerColor(rank);
	      mzy->SetMarkerColor(rank);
	      mxy->SetMarkerColor(rank);
	    }
	    if(i==2) {
	      rank=3;
	      mxyz->SetMarkerColor(rank);
	      mxz->SetMarkerColor(rank);
	      mzy->SetMarkerColor(rank);
	      mxy->SetMarkerColor(rank);
	    }
	    if(i==3) {
	      rank=4;
	      mxyz->SetMarkerColor(rank);
	      mxz->SetMarkerColor(rank);
	      mzy->SetMarkerColor(rank);
	      mxy->SetMarkerColor(rank);
	    }
	    if(i==4) {
	      rank=6;
	      mxyz->SetMarkerColor(rank);
	      mxz->SetMarkerColor(rank);
	      mzy->SetMarkerColor(rank);
	      mxy->SetMarkerColor(rank);
	    }
	    */
	    // Plot the marker on all four histograms
	    Reconstruction->cd(1);
	    mxyz->Draw( );
	    Reconstruction->cd(2);
	    mxz->Draw( );
	    Reconstruction->cd(3);
	    mzy->Draw( );
	    Reconstruction->cd(4);
	    mxy->Draw( );
	  }
	}
      }
    }
    if(printAction) {
      cout << "    --> pseudostave " << p 
	   << ", " << plot_cluster_stores[p];
      plot_cluster_stores[p]==1 ? cout << " hit" : cout << " hits";
      cout << endl;
    }
  }
  
  // Save the canvas to the ROOT output file and delete the histograms from memory
  Reconstruction->Write();
  delete XYZcls;
  delete XZcls;
  delete ZYcls;
  delete XYcls;

  if(printAction) cout << "    --> OK" << endl;
  }
  
  _nEvt ++;
}



void CalorimeterClusterPlotter::check( LCEvent * evt ) { 
  // nothing to check here - could be used to fill checkplots in reconstruction processor
}


void CalorimeterClusterPlotter::end(){ 
  
  std::cout << "CalorimeterClusterPlotter::end()  " << name() 
	    << " processed " << _nEvt << " events in " << _nRun << " runs "
	    << std::endl;

  hfile->Close();

}

