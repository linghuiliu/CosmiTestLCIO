#include "CalorimeterTrueClusterPlotter.h"
#include "marlin/Global.h"

#include "TStyle.h"
#include "TROOT.h"
#include "TCanvas.h"
#include "TH2F.h"
#include "TH3F.h"
#include "TMarker.h"
#include "TPolyMarker3D.h"
#include "TLatex.h"

#include "IMPL/LCCollectionVec.h"
#include "EVENT/Cluster.h"
#include "EVENT/LCIntVec.h"
#include "UTIL/LCRelationNavigator.h"

using namespace lcio;
using namespace marlin;
using namespace std;


CalorimeterTrueClusterPlotter aCalorimeterTrueClusterPlotter;


CalorimeterTrueClusterPlotter::CalorimeterTrueClusterPlotter() : Processor("CalorimeterTrueClusterPlotter") {
  
  // Processor description
  _description = "CalorimeterTrueClusterPlotter creates a plot of the true clusters colour-coded by energy rank within each pseudostave in the designated ROOTOutputFile (N.B. this processor has no effect if ROOT is not installed)";

}


void CalorimeterTrueClusterPlotter::init() { 

  // Set number of runs and events to 0
  _nRun = 0;
  _nEvt = 0;

  // Get parameters from steering file
  firstRun = Global::parameters->getIntVal("firstRun");
  lastRun = Global::parameters->getIntVal("lastRun");
  firstEventInFirstRun = Global::parameters->getIntVal("firstEventInFirstRun");
  lastEventInLastRun = Global::parameters->getIntVal("lastEventInLastRun");
  printAction = Global::parameters->getIntVal("printAction");
  plotPseudostave = Global::parameters->getIntVal("plotPseudostave");
  xmin = Global::parameters->getFloatVal("xmin");
  xmax = Global::parameters->getFloatVal("xmax");
  ymin = Global::parameters->getFloatVal("ymin");
  ymax = Global::parameters->getFloatVal("ymax");
  zmin = Global::parameters->getFloatVal("zmin");
  zmax = Global::parameters->getFloatVal("zmax");
  ROOTOutputFile = Global::parameters->getStringVal("ROOTOutputFile");

  hfile = new TFile(ROOTOutputFile.c_str(),"RECREATE","clusters");

}

void CalorimeterTrueClusterPlotter::processRunHeader( LCRunHeader* run) { 

  _nRun++;
} 

void CalorimeterTrueClusterPlotter::processEvent( LCEvent * evt ) { 

  // Process events in this range
  if(!((evt->getRunNumber()<firstRun && evt->getRunNumber()>lastRun) ||
       (evt->getRunNumber()==firstRun && evt->getEventNumber()<firstEventInFirstRun) ||
       (evt->getRunNumber()==lastRun && evt->getEventNumber()>lastEventInLastRun))) {

  typedef const std::vector<std::string> NameVec;
  NameVec* strVec = evt->getCollectionNames();

  bool trueClustersAreStored=false;
  for(NameVec::const_iterator name=strVec->begin(); name!=strVec->end(); name++){
    string sss=name->c_str();
    if(sss=="CalorimeterCalibratedTrueClusters") {
      trueClustersAreStored=true;
    }
  }
  // Continue only if MC truth information is available 
  if(trueClustersAreStored) {

  if(printAction) cout << "  - plotting true clusters (multiple hits per cell possible if true clusters overlap)...." << endl;

  // Create collections to store:
  // - the rank of each true cluster within its pseudostave (runs in parallel  with 
  //   orderedTrueClusterVec) 
  LCCollectionVec* rankInPseudostaveOfOrderedTrueClusterVec = new LCCollectionVec(LCIO::LCINTVEC);

  // Retrieve these collections
  LCCollection* orderedTrueClusterVec=evt->getCollection("CalorimeterEnergyOrderedTrueClusters");
  LCCollection* calibratedTrueClusterRelVec=evt->getCollection("CalorimeterEnergyOrderedTrueClusterRelationsToCalibratedTrueClusters");
  LCCollection* pseudostaveOfOrderedTrueClusterVec=evt->getCollection("CalorimeterEnergyOrderedTrueClusterPseudostaves");
  LCCollection* hitVec=evt->getCollection("CalorimeterHits");

  // Make the relation navigable
  LCRelationNavigator calibratedTrueClusterRel(calibratedTrueClusterRelVec);

  int barrelSymmetry=hitVec->getParameters().getIntVal("CalorimeterBarrelSymmetry");
  std::string detectorType=hitVec->getParameters().getStringVal("CalorimeterDetectorType");
  int i, j, p, u;
  int pseudostave_max=2+barrelSymmetry;
  if(detectorType=="prototype") pseudostave_max=1;
  int rank[1+pseudostave_max];
  int plot_truecluster_stores[1+pseudostave_max];
  for(p=1;p<=pseudostave_max;p++) {
    rank[p]=0;
    plot_truecluster_stores[p]=0;
  }
  int marker;
  float markerSize;

  // Loop over the energy-ordered true clusters
  for(i=0;i<orderedTrueClusterVec->getNumberOfElements();i++) {
    LCIntVec* pseudostaveOfOrderedTrueCluster = dynamic_cast<LCIntVec*>(pseudostaveOfOrderedTrueClusterVec->getElementAt(i)); 
    LCIntVec* rankInPseudostaveOfOrderedTrueCluster = new LCIntVec;
    // Loop over pseudostaves
    for(p=1;p<=pseudostave_max;p++) {
      // Determine the rank of this true cluster among true clusters that deposit most of their 
      // energy in the current pseudostave
      if(*pseudostaveOfOrderedTrueCluster->begin()==p) {
	rankInPseudostaveOfOrderedTrueCluster->push_back(++rank[p]);
      }
    }
    // Add this rank to the collection
    rankInPseudostaveOfOrderedTrueClusterVec->push_back(rankInPseudostaveOfOrderedTrueCluster);
  }

// Plot true clusters in different colours, correlating colour with
// descending true cluster energy within a pseudostave for true clusters 
// whose major energy deposit is in that pseudostave

  gROOT->SetStyle("Plain");
  TCanvas *Truth = new TCanvas("Truth","Truth",0,600,600,600);
  gStyle->SetTitleBorderSize(1);
  gStyle->SetTitleFillColor(0);

   // Divide the canvas in four
  Truth->Divide(2,2);
 
  // Declare the histograms
  TH3F *XYZcls = new TH3F("x-y-z (truth)","x-y-z",5,xmin,xmax,5,ymin,ymax,5,zmin,zmax);    
  TH2F *XZcls = new TH2F("x-z (truth)","x-z",5,xmin,xmax,5,zmin,zmax);
  TH2F *ZYcls = new TH2F("z-y (truth)","z-y",5,zmin,zmax,5,ymin,ymax);
  TH2F *XYcls = new TH2F("x-y (truth)","x-y",5,xmin,xmax,5,ymin,ymax);
  
  // Set axis titles
  XYZcls->GetXaxis()->SetTitle("x /m");
  XYZcls->GetYaxis()->SetTitle("y /m");
  XYZcls->GetZaxis()->SetTitle("z /m");
  XZcls->GetXaxis()->SetTitle("x /m");
  XZcls->GetYaxis()->SetTitle("z /m");
  ZYcls->GetXaxis()->SetTitle("z /m");
  ZYcls->GetYaxis()->SetTitle("y /m");
  XYcls->GetXaxis()->SetTitle("x /m");
  XYcls->GetYaxis()->SetTitle("y /m");

  float labelSize=0.05;
  float titleSize=0.05;

  // Set some attributes
  XYZcls->GetXaxis()->SetLabelSize(labelSize);
  XYZcls->GetXaxis()->SetTitleSize(titleSize);
  XYZcls->GetYaxis()->SetLabelSize(labelSize);
  XYZcls->GetYaxis()->SetTitleSize(titleSize);
  XYZcls->GetZaxis()->SetLabelSize(labelSize);
  XYZcls->GetZaxis()->SetTitleSize(titleSize);
  XYZcls->GetXaxis()->SetTitleOffset(1.75);
  XYZcls->GetYaxis()->SetTitleOffset(1.75);
  XYZcls->GetZaxis()->SetTitleOffset(1.15);
  XYZcls->SetStats(kFALSE);
      
  XZcls->GetXaxis()->SetLabelSize(labelSize);
  XZcls->GetXaxis()->SetTitleSize(titleSize);
  XZcls->GetYaxis()->SetLabelSize(labelSize);
  XZcls->GetYaxis()->SetTitleSize(titleSize);
  XZcls->GetZaxis()->SetLabelSize(labelSize);
  XZcls->GetZaxis()->SetTitleSize(titleSize);
  XZcls->GetXaxis()->SetTitleOffset(1.00);
  XZcls->GetYaxis()->SetTitleOffset(1.10);
  XZcls->SetStats(kFALSE);
  
  ZYcls->GetXaxis()->SetLabelSize(labelSize);
  ZYcls->GetXaxis()->SetTitleSize(titleSize);
  ZYcls->GetYaxis()->SetLabelSize(labelSize);
  ZYcls->GetYaxis()->SetTitleSize(titleSize);
  ZYcls->GetZaxis()->SetLabelSize(labelSize);
  ZYcls->GetZaxis()->SetTitleSize(titleSize);
  ZYcls->GetXaxis()->SetTitleOffset(1.00);
  ZYcls->GetYaxis()->SetTitleOffset(1.10);
  ZYcls->SetStats(kFALSE);
  
  XYcls->GetXaxis()->SetLabelSize(labelSize);
  XYcls->GetXaxis()->SetTitleSize(titleSize);
  XYcls->GetYaxis()->SetLabelSize(labelSize);
  XYcls->GetYaxis()->SetTitleSize(titleSize);
  XYcls->GetZaxis()->SetLabelSize(labelSize);
  XYcls->GetZaxis()->SetTitleSize(titleSize);
  XYcls->GetXaxis()->SetTitleOffset(1.00);
  XYcls->GetYaxis()->SetTitleOffset(1.10);
  XYcls->SetStats(kFALSE);

  // Draw the (empty) histograms
  Truth->cd(1);
  XYZcls->Draw( );
  Truth->cd(2);
  XZcls->Draw( );
  Truth->cd(3);
  ZYcls->Draw( );
  Truth->cd(4);
  XYcls->Draw( );

  // Loop over pseudostaves
  for(p=1;p<=pseudostave_max;p++) {
    // Plot only the hits in the chosen pseudostave
    if(plotPseudostave==p || plotPseudostave==0) {
      // Loop over the energy-ordered true clusters
      for(i=0;i<orderedTrueClusterVec->getNumberOfElements();i++) {
	Cluster* orderedTrueCluster = dynamic_cast<Cluster*>(orderedTrueClusterVec->getElementAt(i));
	Cluster* calibratedTrueCluster = dynamic_cast<Cluster*>(calibratedTrueClusterRel.getRelatedToObjects(orderedTrueCluster)[0]);
	LCIntVec* pseudostaveOfOrderedTrueCluster = dynamic_cast<LCIntVec*>(pseudostaveOfOrderedTrueClusterVec->getElementAt(i));
	LCIntVec* rankInPseudostaveOfOrderedTrueCluster = dynamic_cast<LCIntVec*>(rankInPseudostaveOfOrderedTrueClusterVec->getElementAt(i));	
	int pseudostaveOfTrueCluster=*pseudostaveOfOrderedTrueCluster->begin();
	// Loop over this true cluster's hits
	for(u=0;u<int(calibratedTrueCluster->getCalorimeterHits().size());u++) {
	  CalorimeterHit* hit = dynamic_cast<CalorimeterHit*>(calibratedTrueCluster->getCalorimeterHits()[u]);
	  int pseudostaveOfHit=1+(hit->getCellID1()%16777216)/8;
	  // If the hit is in the current pseudostave:
	  if(pseudostaveOfHit==p) {
	    plot_truecluster_stores[p]++;
	    int rank=*rankInPseudostaveOfOrderedTrueCluster->begin();
	    float pos[3];
	    for(j=0;j<3;j++) {
	      pos[j]=hit->getPosition()[j]/1000.;
	    }
	    // - use a dot to mark the position if the true cluster's main energy deposit is in this 
	    //   pseudostave
	    if(pseudostaveOfTrueCluster==p) { 
	      marker=20;
	      markerSize=0.25;
	    }
	    // - use a cross to mark the position if the cluster's main energy deposit is in another 
	    //   pseudostave
	    else {
	      marker=5;
	      markerSize=0.5;
	    }
	    TPolyMarker3D *mxyz = new TPolyMarker3D(1,marker);
	    TMarker *mxz = new TMarker(pos[0],pos[2],marker);
	    TMarker *mzy = new TMarker(pos[2],pos[1],marker);
	    TMarker *mxy = new TMarker(pos[0],pos[1],marker);
	    mxyz->SetMarkerSize(markerSize);
	    mxz->SetMarkerSize(markerSize);
	    mzy->SetMarkerSize(markerSize);
	    mxy->SetMarkerSize(markerSize);
	    mxyz->SetPoint(0,pos[0],pos[1],pos[2]);
	    if(rank<10) {
	      mxyz->SetMarkerColor(rank);
	      mxz->SetMarkerColor(rank);
	      mzy->SetMarkerColor(rank);
	      mxy->SetMarkerColor(rank);
	    }
	    else {  // skip white in the colour palette
	      mxyz->SetMarkerColor(rank+1);
	      mxz->SetMarkerColor(rank+1);
	      mzy->SetMarkerColor(rank+1);
	      mxy->SetMarkerColor(rank+1);
	    }
	    // Plot the marker on all four histograms
	    Truth->cd(1);
	    mxyz->Draw( );
	    Truth->cd(2);
	    mxz->Draw( );
	    Truth->cd(3);
	    mzy->Draw( );
	    Truth->cd(4);
	    mxy->Draw( );
	  }
	}
      }
    }
    if(printAction) {
      cout << "    --> pseudostave " << p 
	   << ", " << plot_truecluster_stores[p];
      plot_truecluster_stores[p]==1 ? cout << " hit" : cout << " hits";  
      cout << endl;
    }
  }
  // Save the canvas to the ROOT output file and delete the histograms from memory
  Truth->Write();
  delete XYZcls;
  delete XZcls;
  delete ZYcls;
  delete XYcls;

  if(printAction) cout << "    --> OK" << endl;
  }
  }
  
  _nEvt ++;
}



void CalorimeterTrueClusterPlotter::check( LCEvent * evt ) { 
  // nothing to check here - could be used to fill checkplots in reconstruction processor
}


void CalorimeterTrueClusterPlotter::end(){ 
  
  std::cout << "CalorimeterTrueClusterPlotter::end()  " << name() 
	    << " processed " << _nEvt << " events in " << _nRun << " runs "
	    << std::endl;

  hfile->Close();

}

